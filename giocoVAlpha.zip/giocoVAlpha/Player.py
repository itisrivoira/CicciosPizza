import Camminata
import pygame
import time


class Player():

	def __init__(self, surfBase, x, y):
		self.lvl = 1  
		self.PEP = 20 #stats fisse da aumentare al salire di livello
		self.fisso = 50
		self.PP = 50 #stats fisse da aumentare al salire di livello
		self.exp = 0
		self.surf_player = pygame.image.load(surfBase)
		self.rect_player = self.surf_player.get_rect()
		self.rect_player.move_ip(x, y)
		self.HP  = self.PP #self.PP
		self.energy = self.PEP
		self.pizzaBar = [pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/pizzaBar/healthBarFullPizza.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/pizzaBar/PizzaBarFull90.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/pizzaBar/pizzaBar80.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/pizzaBar/pizzaBar70.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/pizzaBar/pizzaBar60.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/pizzaBar/pizzaBar50.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/pizzaBar/pizzaBar40.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/pizzaBar/pizzaBar30.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/pizzaBar/pizzaBar20.png") , pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/pizzaBar/pizzaBar10.png") ]
		self.pizzaEnergy = [pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/energyBar/barraEnergy.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/energyBar/90En.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/energyBar/80En.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/energyBar/70En.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/energyBar/60En.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/energyBar/50En.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/energyBar/40En.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/energyBar/30En.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/energyBar/20En.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/energyBar/10En.png") ]
		self.colpi = ["Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpi/conPadella/colpoPad.png", "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpi/conPadella/colpo2Pad.png", "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpi/conPadella/colpo3Padd.png", "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpi/conPadella/colpo4Padd.png", "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpi/conPadella/colpo5Pad.png"]
		self.colpiFiamma = ["Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpi/conFiamma/colpoFiamma1.png", "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpi/conFiamma/colpoFiamma2.png", "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpi/conFiamma/colpoFiamma3.png", "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpi/conFiamma/colpoFiamma4.png" ,"Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpi/conFiamma/colpoFiamma5.png"]
		self.colpiLunga = ["Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpi/conPalona/colpoPalona1.png", "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpi/conPalona/colpoPalona2.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpi/conPalona/colpoPalona3.png", "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpi/conPalona/colpoPalona4.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpi/conPalona/colpoPalona5.png" ]
		self.colpiPala = ["Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpi/conPala/colpoPalina1.png", "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpi/conPala/colpoPalina2.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpi/conPala/colpoPalina3.png", "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpi/conPala/colpoPalina4.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpi/conPala/colpoPalina5.png"]
		self.clock = pygame.time.Clock() #VARIABILE PER SETTARE L'IMMORTALITA DOPO ESSERE STATI COLPITI
		self.tempo = 0
		self.first = True
		self.colpito_player = False
		self.app = 0
		#self.surfColpiti = [pygame.image.load("Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/colpito1.png"), pygame.image.load("Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/colpitoUP.png"), pygame.image.load("Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/colpitoSx.png"), pygame.image.load("Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/colpitoDx.png")]
		self.colpito2 = 0
		self.lastPath = ""
		self.padella = "base"
		self.livello1 = False
		self.livello2 = False
		self.livello3 = False
		self.livello4 = False
		self.livello5 = False
		self.oca1 = False
		self.oca2 = False
		self.oca3 = False
		self.havePadBase = True
		self.havePadFuoco = False
		self.havePadLunga = False
		self.havePadPala =  False
		self.havePadOssa =  False # False
		self.flagNoDanno = False
		self.raddoppiaDanno = False
		self.ricominciaDopoSconfitta = False
		self.attaccoFinale = 0
		
		
	
	def setRect(self, x, y):
		self.rect_player.move_ip(x, y)
		
	def getRectPlayer(self):
		return self.rect_player
		
	def getSurfPlayer(self):
		print(self.app)
		#if(self.colpito_player == True):
		#	return self.surfColpiti[0]
		#else:
		return self.surf_player
		
	
	def diminuisciHP(self, tempo):
		#if(self.colpito_player and self.attendi() >= 2000):
			#self.HP = self.HP - 10
			#print(self.HP)
			#self.app = 0
			
		
			#self.app = 0
		#	self.colpito_player = False 
		#if ( self.first == True):
		#	self.first = False
			#self.colpito_player = False
		#	self.HP = self.HP - 10
		#	print(self.HP)
			#self.first = False	
		print("aa")
	
		
	def colpito(self, valore):
		if(self.colpito_player == True):
			self.HP = self.HP - valore
			#self.diminuisciHP(self.app)
			print(self.HP)			
		#self.colpito_player = True
	#	if(self.colpito_player):
	#		self.colpito_player = False
	#		self.tempo = self.clock.tick() 
			#print("ciao")
		#	self.app = 0
		#self.diminuisciHP(self.app)
			
	def attendi(self):
		self.tempo = self.clock.tick() 
		self.app = self.app + self.tempo
		#print(self.app)
		return self.app
		
	def ritornaHP(self):
		return self.HP
		
	def ritornaPizzaBar(self):
		if (self.HP <= (self.PP / 100) * 90 and self.HP > (self.PP / 100) * 80):
			return self.pizzaBar[1]
		elif (self.HP <= (self.PP / 100) * 80 and self.HP > (self.PP / 100) * 70):
			return self.pizzaBar[2]		
		elif (self.HP <= (self.PP / 100) * 70 and self.HP > (self.PP / 100) * 60):
			return self.pizzaBar[3]
		elif (self.HP <= (self.PP / 100) * 60 and self.HP > (self.PP / 100) * 50):
			return self.pizzaBar[4]
		elif (self.HP <= (self.PP / 100) * 50 and self.HP > (self.PP / 100) * 40):
			return self.pizzaBar[5]
		elif (self.HP <= (self.PP / 100) * 40 and self.HP > (self.PP / 100) * 30):
			return self.pizzaBar[6]			
		elif (self.HP <= (self.PP / 100) * 30 and self.HP > (self.PP / 100) * 20):
			return self.pizzaBar[7]	
		elif (self.HP <= (self.PP / 100) * 20 and self.HP > (self.PP / 100) * 10):
			return self.pizzaBar[8]	
		elif (self.HP <= (self.PP / 100) * 10):
			return self.pizzaBar[9]
		else:
			return self.pizzaBar[0]
			
	def ritornaPizzaEnergy(self):
		if (self.energy <= (self.PEP / 100) * 90 and self.energy > (self.PEP  / 100) * 80):
			return self.pizzaEnergy[1]
		elif (self.energy <= (self.PEP / 100) * 80 and self.energy > (self.PEP  / 100) * 70):
			return self.pizzaEnergy[2]		
		elif (self.energy <= (self.PEP  / 100) * 70 and self.energy > (self.PEP  / 100) * 60):
			return self.pizzaEnergy[3]
		elif (self.energy <= (self.PEP  / 100) * 60 and self.energy > (self.PEP  / 100) * 50):
			return self.pizzaEnergy[4]
		elif (self.energy <= (self.PEP  / 100) * 50 and self.energy > (self.PEP  / 100) * 40):
			return self.pizzaEnergy[5]
		elif (self.energy <= (self.PEP  / 100) * 40 and self.energy > (self.PEP  / 100) * 30):
			return self.pizzaEnergy[6]			
		elif (self.energy <= (self.PEP  / 100) * 30 and self.energy > (self.PEP / 100) * 20):
			return self.pizzaEnergy[7]	
		elif (self.energy <= (self.PEP  / 100) * 20 and self.energy > (self.PEP / 100) * 10):
			return self.pizzaEnergy[8]	
		elif (self.energy <= (self.PEP  / 100) * 10):
			return self.pizzaEnergy[9]
		else:
			return self.pizzaEnergy[0]			
			
	def checkColpito(self):
		#print(self.colpito_player)
		return self.colpito_player
		
	def setColpito(self):
		self.colpito_player = True	
		
	def setLast(self, camminata):
		self.lastPath= camminata.stand()
		
		
	def stampa(self, world):
		world.blit(self.surfColpiti[0], (self.rect_player.x, self.rect_player.y))
		pygame.display.flip()	
		
	def getColpito(self):
		return self.surfColpiti[0]
		
	def settaPoz(self,world, x,y):
		self.rect_player.x = x
		self.rect_player.y = y
		#world.blit(self.surf_player, (self.rect_player.x, self.rect_player.y))
		
	def dimEnergy(self, val):
		if( (self.energy - val) >= 0):
			self.energy = self.energy - val
			return True
		else:
			return False
		
	def recuperaEnergy(self, val):
		if( (self.energy + val) <= self.PEP):
			self.energy = self.energy + val
		else:
			self.energy = self.PEP
		return True
		
	def recuperaHP(self, val):
		if( (self.HP + val) <= self.PP):
			self.HP = self.HP+ val
		else:
			self.HP = self.PP
		return True

			
	def aumentaExp(self, val):
		self.exp = self.exp + val
		self.controllaLivello()
		
	def controllaLivello(self):
		if (self.exp <= 150):
			self.lvl = 1
		elif (self.exp > 150 and self.exp <= 400):
			self.lvl = 2
			self.PP = 75
			self.HP = 75
			self.PEP = 30
			self.energy = self.PEP
		elif (self.exp > 400 and self.exp <= 800):
			self.lvl = 3
			self.PP = 90
			self.HP = 90
			self.PEP = 35
			self.energy = self.PEP		
		
		elif (self.exp > 800 and self.exp <= 1600):
			self.lvl = 4
			self.PP = 120
			self.HP = 120
			self.PEP = 45
			self.energy = self.PEP		
		elif (self.exp > 1600 and self.exp <= 2500):
			self.lvl = 5
			self.PP = 150
			self.HP = 150
			self.PEP = 60
			self.energy = self.PEP							
			
		
			
