import pygame, sys
import pygame_menu #libreria di pygame che permette una facile creazione del main menu di gioco
from pygame_menu import sound
from pygame.locals import *
import mappaLivelli
import time
import Camminata
import Player
import dialoghiVito
import colonnaSonora
import inventario
import dialoghiNPC_secondari

'''
Variables

'''
camminiamo = Camminata.Camminata()
player = Player.Player(camminiamo.getUpPath(), 550, 780)
dialogo = dialoghiNPC_secondari.Dialogo()
colonnaHUB = colonnaSonora.Colonna("Suoni/hubOst.wav")
inventario = inventario.Inventario()





def ristampaMovi(world, x, y):
	
	path_stampa = camminiamo.ristampaMovi()
	surf_posizione= pygame.image.load(path_stampa)
	world.blit(surf_posizione, (x,y))
	return path_stampa

		
	
					
def ristampa(world, x, y, PATH):

	surf_background = pygame.image.load("Immagini_Gioco/HUB/pavimentociccio.png").convert()
	world.blit(surf_background, (0, 0))
	
	surf_livelli=pygame.image.load("Immagini_Gioco/HUB/mappaLivelli.png")
	rect_livelli = surf_livelli.get_rect()
	xLvl=1000 
	yLvl=80 
	rect_livelli.move_ip(xLvl, yLvl) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_livelli, (xLvl,yLvl))
	
	
	surf_bancone=pygame.image.load("Immagini_Gioco/HUB/banconeVito.png")
	rect_bancone = surf_bancone.get_rect()
	xVito=300  
	yVito=50  
	rect_bancone.move_ip(xVito, yVito) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_bancone, (xVito,yVito))
	
	surf_tavoli=pygame.image.load("Immagini_Gioco/HUB/tavoloConPizza.png")
	rect_tavoli = surf_tavoli.get_rect()
	xTav=100
	yTav=700  
	rect_tavoli.move_ip(xTav, yTav) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_tavoli, (xTav,yTav))
	
	surf_tavoli2=pygame.image.load("Immagini_Gioco/HUB/tavoloConPizza.png")
	rect_tavoli2 = surf_tavoli2.get_rect()
	xTav2=320
	yTav2=700  
	rect_tavoli2.move_ip(xTav, yTav) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_tavoli2, (xTav2,yTav2))
	
	surf_tavoli3=pygame.image.load("Immagini_Gioco/HUB/tavoloConPizza.png")
	rect_tavoli3 = surf_tavoli3.get_rect()
	xTav3=100
	yTav3=500  
	rect_tavoli3.move_ip(xTav3, yTav3) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_tavoli3, (xTav3,yTav3))

	surf_tavoli4=pygame.image.load("Immagini_Gioco/HUB/tavoloConPizza.png")
	rect_tavoli4 = surf_tavoli4.get_rect()
	xTav4=320
	yTav4=500  
	rect_tavoli4.move_ip(xTav4, yTav4) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_tavoli4, (xTav4,yTav4))
	
	surf_forno=pygame.image.load("Immagini_Gioco/HUB/forno3.png")
	rect_forno = surf_forno.get_rect()
	xFor=25
	yFor=0  
	rect_forno.move_ip(xFor, yFor) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_forno, (xFor,yFor))	

	#pygame.draw.rect(world, (255,0,0), rect_chef) 
	surf_Player=pygame.image.load(PATH)
	world.blit(surf_Player, (x,y))
	rect_vito = pygame.Rect((560, 220), (100, 100))
	#pygame.draw.rect(world, (1,0,0), rect_vito ) 
	
	sans = pygame.image.load("Immagini_Gioco/SANS/down/SANS_DOWN.png")
	rect_sans = sans.get_rect()
	rect_sans.move_ip((840, 380))
	world.blit(sans, (840, 390))
	
	#pygame.draw.rect(world, (1,0,0), rect_sans ) 
	
	
		
def main():	
	global walkCount, left, right
	#pygame.init()
	worldx = 1280
	worldy = 920
	fps = 40
	ani = 4
	world = pygame.display.set_mode((worldx, worldy))
	#backdrop = pygame.image.load("Immagini_Gioco/background_menu/rossa2.jpg").convert()
	clock = pygame.time.Clock()
	#backdropbox = world.get_rect()
	main = True
	muovix = 0

	#player = Player()  # spawn player
	#player.rect.x = 0  # go to x
	#player.rect.y = 0  # go to y
	steps = 10
	proviamo = 0

	surf_background = pygame.image.load("Immagini_Gioco/HUB/pavimentociccio.png").convert()
	world.blit(surf_background, (0, 0))

	surf_bancone=pygame.image.load("Immagini_Gioco/HUB/banconeVito.png")
	rect_bancone = surf_bancone.get_rect()
	xVito=300 
	yVito=50  
	rect_bancone.move_ip(xVito, yVito) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_bancone, (xVito,yVito))

	surf_livelli=pygame.image.load("Immagini_Gioco/HUB/mappaLivelli.png")
	rect_livelli = surf_livelli.get_rect()
	xLvl=1000 
	yLvl=80  
	rect_livelli.move_ip(xLvl, yLvl) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_livelli, (xLvl,yLvl))

	surf_tavoli=pygame.image.load("Immagini_Gioco/HUB/tavoloConPizza.png")
	rect_tavoli = surf_tavoli.get_rect()
	xTav=100
	yTav=700  
	rect_tavoli.move_ip(xTav, yTav) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_tavoli, (xTav,yTav))

	surf_tavoli2=pygame.image.load("Immagini_Gioco/HUB/tavoloConPizza.png")
	rect_tavoli2 = surf_tavoli2.get_rect()
	xTav2=320
	yTav2=700  
	rect_tavoli2.move_ip(xTav2, yTav2) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_tavoli2, (xTav2,yTav2))
		
	surf_tavoli3=pygame.image.load("Immagini_Gioco/HUB/tavoloConPizza.png")
	rect_tavoli3 = surf_tavoli3.get_rect()
	xTav3=100
	yTav3=500  
	rect_tavoli3.move_ip(xTav3, yTav3) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_tavoli3, (xTav3,yTav3))

	surf_tavoli4=pygame.image.load("Immagini_Gioco/HUB/tavoloConPizza.png")
	rect_tavoli4 = surf_tavoli4.get_rect()
	xTav4=320
	yTav4=500  
	rect_tavoli4.move_ip(xTav4, yTav4) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_tavoli4, (xTav4,yTav4))

	surf_forno=pygame.image.load("Immagini_Gioco/HUB/forno3.png")
	rect_forno = surf_forno.get_rect()
	xFor=25
	yFor=0  
	rect_forno.move_ip(xFor, yFor) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_forno, (xFor,yFor))	

	nuovaPoz = camminiamo.getUpPath()
	world.blit(player.getSurfPlayer(), (player.getRectPlayer().x , player.getRectPlayer().y))
	
	
	sans = pygame.image.load("Immagini_Gioco/SANS/down/SANS_DOWN.png")
	rect_sans = sans.get_rect()
	rect_sans.move_ip((840, 380))
	world.blit(sans, (840, 390))
	
	


	pygame.display.flip()
	pygame.key.set_repeat(27,27)  #serve per lo spostamento
	
	clock1 = pygame.time.Clock()
	rect_vito = pygame.Rect((560, 220), (100, 100))
	#pygame.draw.rect(world, (1,0,0), rect_vito ) 
	'''
	Main Loop
	
	'''

	while main:
		clock1.tick(27)
		#print(volume)
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				sys.exit()
				

		       
			if event.type == pygame.KEYDOWN:
				print(event.key)
				if event.key == pygame.K_LEFT:
					x2 = player.getRectPlayer().x - steps
					y2 = player.getRectPlayer().y
					prova = x2 - player.getRectPlayer().x
					prova2 = y2 - player.getRectPlayer().y
					rect_prova = player.getRectPlayer().move(prova, prova2)
					if rect_prova.colliderect(rect_bancone) or rect_prova.colliderect(rect_livelli) or rect_prova.colliderect(rect_tavoli) or rect_prova.colliderect(rect_tavoli2) or rect_prova.colliderect(rect_tavoli3) or rect_prova.colliderect(rect_tavoli4) or rect_prova.colliderect(rect_forno)  or rect_prova.colliderect(rect_sans):
						print("non ti muovi")
					else:
						if(rect_prova.x > 10):
							player.setRect(prova, prova2)
							camminiamo.settaLeft()
							nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
							ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz)		
						
				if event.key == pygame.K_RIGHT:
					x2 = player.getRectPlayer().x + steps
					y2 = player.getRectPlayer().y
					prova = x2 - player.getRectPlayer().x
					prova2 = y2 - player.getRectPlayer().y
					rect_prova = player.getRectPlayer().move(prova, prova2)
					if rect_prova.colliderect(rect_bancone) or rect_prova.colliderect(rect_livelli) or rect_prova.colliderect(rect_tavoli) or rect_prova.colliderect(rect_tavoli2) or rect_prova.colliderect(rect_tavoli3) or rect_prova.colliderect(rect_tavoli4) or rect_prova.colliderect(rect_forno)  or rect_prova.colliderect(rect_sans):
						print("non ti muovi")
					else:
						if(rect_prova.x < 1180):
							player.setRect(prova, prova2)
							camminiamo.settaRight()
							nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
							ristampa(world, player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz)
					
				if event.key == pygame.K_UP:
					x2 = player.getRectPlayer().x
					y2 = player.getRectPlayer().y - steps
					prova = x2 - player.getRectPlayer().x
					prova2 = y2 - player.getRectPlayer().y
					rect_prova = player.getRectPlayer().move(prova, prova2)
					if rect_prova.colliderect(rect_bancone) or rect_prova.colliderect(rect_livelli) or rect_prova.colliderect(rect_tavoli) or rect_prova.colliderect(rect_tavoli2) or rect_prova.colliderect(rect_tavoli3) or rect_prova.colliderect(rect_tavoli4) or rect_prova.colliderect(rect_forno)  or rect_prova.colliderect(rect_sans):
						print("non ti muovi")
					else:
						player.setRect(prova, prova2)
						camminiamo.settaUP()
						nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
						ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz)	
							
								
				if event.key == pygame.K_DOWN:
					x2 = player.getRectPlayer().x
					y2 = player.getRectPlayer().y + steps
					prova = x2 - player.getRectPlayer().x
					prova2 = y2 - player.getRectPlayer().y
					rect_prova = player.getRectPlayer().move(prova, prova2)
					if rect_prova.colliderect(rect_bancone) or rect_prova.colliderect(rect_livelli) or rect_prova.colliderect(rect_tavoli) or rect_prova.colliderect(rect_tavoli2) or rect_prova.colliderect(rect_tavoli3) or rect_prova.colliderect(rect_tavoli4) or rect_prova.colliderect(rect_forno) or rect_prova.colliderect(rect_sans):
						print("non ti muovi")
					else:
						if(rect_prova.y < 800):
							player.setRect(prova, prova2)
							camminiamo.settaDOWN()
							nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
							ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz)


				if event.key  == pygame.K_RETURN:
					if (rect_prova.colliderect(rect_sans)):
						print("dialogo sans")
						dialogo.stampaDialoghi(world, 3, "Immagini_Gioco/DialoghiNPC/npc_secondari/sans_face.png")
						ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz)
					if (rect_prova.colliderect(rect_forno)):
						main = False
							#ristampa(world, rect_chef.x, rect_chef.y, -steps, 0, PATH_FERMOSX)
				if event.key == pygame.K_ESCAPE:
					main = False
	
			
			
		pygame.display.flip()

