

class Personaggio():


	def __init__(self):
		self.setTimer = 100
		self.primaBattaglia = 0
		self.text = "100"
		
	def diminuisci(self):
		if(self.setTimer != 0):
			self.setTimer = self.setTimer - 1
		
	def getTimer(self):
		return self.setTimer
		
	def attaccoOca(self, colpo):
		if(self.setTimer - colpo >= 0):
			self.setTimer = self.setTimer - colpo
		else:
			self.setTimer = 0
		
	def getPrimaBat(self):
		return self.primaBattaglia
		
	def vinto1(self):
		self.primaBattaglia = 1
		
	def settingTimer(self):
		self.setTimer = 100
		
	def setStringa(self, x):
		self.text = str(x)
		
	def getStringa(self):
		return self.text


