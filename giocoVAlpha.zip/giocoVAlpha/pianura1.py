import pygame, sys
import pygame_menu #libreria di pygame che permette una facile creazione del main menu di gioco
from pygame_menu import sound
from pygame.locals import *
import mappaLivelli
import time, datetime
import crazyPalace
import classPG
import Camminata
import Player
import gestioneCitta
import dialoghiNPC_secondari
import cittaLocaleTombolone
import foresta1
import stradaPerTempio


miaArea = gestioneCitta.areaCiccios("Immagini_Gioco/provaASSETT_mappa/pianura1.jpg")
camminiamo = Camminata.Camminata()
#player = Player.Player(camminiamo.getUpPath(), 550, 780)
#player = Player.Player(camminiamo.getUpPath(), 550, 780)
flagColl = 0
dialogo = dialoghiNPC_secondari.Dialogo()


def ristampaMovi(world, x, y):
	
	path_stampa = camminiamo.ristampaMovi()
	surf_posizione= pygame.image.load(path_stampa)
	world.blit(surf_posizione, (x,y))
	return path_stampa
	
def settaCollsioni():
	miaArea.settaCollisione(pygame.Rect((870, 265), (80, 420))) #rectBosco sopra
	miaArea.settaCollisione(pygame.Rect((500, 650), (380, 50)))	#rect Albero in basso destra
	miaArea.settaCollisione(pygame.Rect((500, 290), (40, 400))) # rect albero in basso sinistra
	miaArea.settaCollisione(pygame.Rect((430, 370), (100, 210))) # rect albero vicino casa
	miaArea.settaCollisione(pygame.Rect((550, 258), (300, 110))) # rect tronchetto
	miaArea.settaCollisione(pygame.Rect((680, 158), (160, 110))) # rect pietra alto sinistra
	miaArea.settaCollisione(pygame.Rect((125, 198), (120, 120))) # pietra vicino casa
	miaArea.settaCollisione(pygame.Rect((175, 728), (110, 110))) # palo casa sinistra
	miaArea.settaCollisione(pygame.Rect((1250, 430), (50, 50)))
	
	
	#CAMBIO AREA#
	miaArea.settaCollisione(pygame.Rect((710, 885), (50, 45)))
	miaArea.settaCollisione( pygame.Rect((0, 405), (40, 40)))
	miaArea.settaCollisione(pygame.Rect((720, 0), (40, 5)))
	
def ristampa(world, x, y, PATH, player, flagUltimo = ""):
	world.blit(miaArea.getSurfArea(), (0, 0))	
	
	if(flagUltimo != "ananas"):
		surf_area=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/cambiaArea.jpg")
		xA=1230
		yA=410
		world.blit(surf_area, (xA,yA))
		surf_area2=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/cambiaAreaPiccola.jpg")
		xA2=700
		yA2=850
		world.blit(surf_area2, (xA2,yA2))
		
		
		surf_area3=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/cambiaAreaPiccola.jpg")
		xA2=0
		yA2=405
		world.blit(surf_area3, (xA2,yA2))
	
	surf_area4=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/cambiaAreaPiccola.jpg")
	xA2=700
	yA2=0
	world.blit(surf_area4, (xA2,yA2))
	
	surf_Player=pygame.image.load(PATH)
	world.blit(surf_Player, (x,y))	
	#rect1= pygame.Rect((720, 0), (40, 5))
	#pygame.draw.rect(world, (1,0,0), rect1 ) 
	#pygame.draw.rect(world, (0,0,255), player.rect_player ) 
	#rect2= pygame.Rect((500, 650), (380, 50))
	#pygame.draw.rect(world, (1,0,0), rect2 )
	#rect3= pygame.Rect((500, 290), (40, 400))
	#pygame.draw.rect(world, (1,0,0), rect3 )	
	#rect4= pygame.Rect((430, 370), (100, 210))
	#pygame.draw.rect(world, (1,0,0), rect4 )
	#rect5= pygame.Rect((550, 258), (300, 110))
	#pygame.draw.rect(world, (1,0,0), rect5 )
	#rect6= pygame.Rect((680, 158), (160, 110))
	#pygame.draw.rect(world, (1,255,0), rect6 )
	#rect7= pygame.Rect((125, 198), (120, 120))
	#pygame.draw.rect(world, (1,255,0), rect7 )
	#rect8= pygame.Rect((175, 728), (110, 110))
	#pygame.draw.rect(world, (1,255,0), rect8 )
	#rect1= pygame.Rect((710, 885), (50, 45))
	#pygame.draw.rect(world, (1,0,0), rect1 ) 


def main(player, inventario, flagUltimo = ""):
	global flagColl
	
	pygame.init()
	worldx = 1280
	worldy = 920
	fps = 40
	ani = 4
	world = pygame.display.set_mode((worldx, worldy))
	#backdrop = pygame.image.load("Immagini_Gioco/background_menu/rossa2.jpg").convert()
	clock = pygame.time.Clock()
	#backdropbox = world.get_rect()
	main = True
	muovix = 0

	#player = Player()  # spawn player
	#player.rect.x = 0  # go to x
	#player.rect.y = 0  # go to y
	steps = 10

	world.blit(miaArea.getSurfArea(), (0, 0))

	
	nuovaPoz = camminiamo.getLeftPath()	
	player.settaPoz(world, 1150, 400)
	world.blit(pygame.image.load(nuovaPoz), (player.getRectPlayer().x , player.getRectPlayer().y))
	surf_area=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/cambiaArea.jpg")
	xA=1230
	yA=410
	world.blit(surf_area, (xA,yA))
	
	if(flagUltimo != "ananas"):
		surf_area2=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/cambiaAreaPiccola.jpg")
		xA2=700
		yA2=0
		world.blit(surf_area2, (xA2,yA2))
		
		surf_area3=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/cambiaAreaPiccola.jpg")
		xA2=0
		yA2=405
		world.blit(surf_area3, (xA2,yA2))
		
		surf_area2=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/cambiaAreaPiccola.jpg")
		xA2=700
		yA2=850
		world.blit(surf_area2, (xA2,yA2))

	surf_area4=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/cambiaAreaPiccola.jpg")
	xA2=700
	yA2=0
	world.blit(surf_area4, (xA2,yA2))
	
	
	pygame.key.set_repeat(32,32)
	if(flagColl == 0):
		settaCollsioni()
	pygame.display.flip()
	
	while main:
		if (player.oca1 == True and player.oca2 == True and player.oca3 == True):
			main = False
		print(player.rect_player.x)
		clock.tick(27)
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				sys.exit()
			elif event.type == pygame.MOUSEBUTTONDOWN:
				click = event.pos
				print(click)
				
			if event.type == pygame.KEYDOWN:
				if event.key == pygame.K_LEFT:
					x2 = player.getRectPlayer().x - steps
					y2 = player.getRectPlayer().y
					prova = x2 - player.getRectPlayer().x
					prova2 = y2 - player.getRectPlayer().y
					rect_prova = player.getRectPlayer().move(prova, prova2)
					if(miaArea.verificaCollisione2(rect_prova) == False):
						if(rect_prova.x < 0):
							print("m")
						else:
							player.setRect(prova, prova2)
							camminiamo.settaLeft()
							nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
							ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player, flagUltimo)
							
								
						
				if (event.key == pygame.K_RIGHT):
					x2 = player.getRectPlayer().x + steps
					y2 = player.getRectPlayer().y
					prova = x2 - player.getRectPlayer().x
					prova2 = y2 - player.getRectPlayer().y
					rect_prova = player.getRectPlayer().move(prova, prova2)
					if(miaArea.verificaCollisione2(rect_prova) == False):
						if(rect_prova.x < 1210):
							player.setRect(prova, prova2)
							camminiamo.settaRight()
							nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
							ristampa(world, player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player, flagUltimo)
					
					
				if event.key == pygame.K_UP :
					x2 = player.getRectPlayer().x
					y2 = player.getRectPlayer().y - steps
					prova = x2 - player.getRectPlayer().x
					prova2 = y2 - player.getRectPlayer().y
					rect_prova = player.getRectPlayer().move(prova, prova2)
					if(miaArea.verificaCollisione2(rect_prova) == False):
						if(rect_prova.y > 0):
							player.setRect(prova, prova2)
							camminiamo.settaUP()
							nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
							ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player, flagUltimo)	
							

													
					
							
								
				if event.key == pygame.K_DOWN:
					x2 = player.getRectPlayer().x
					y2 = player.getRectPlayer().y + steps
					prova = x2 - player.getRectPlayer().x
					prova2 = y2 - player.getRectPlayer().y
					rect_prova = player.getRectPlayer().move(prova, prova2)
					if(miaArea.verificaCollisione2(rect_prova) == False):
						if(rect_prova.y < 790):
							player.setRect(prova, prova2)
							camminiamo.settaDOWN()
							nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
							ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player, flagUltimo)
							
				if event.key == pygame.K_DOWN or event.key == pygame.K_UP  or event.key == pygame.K_RIGHT or event.key == pygame.K_LEFT:
					if (miaArea.rectCollisioni[8].colliderect(rect_prova)):
						flagColl = 1
						main = False
					elif (miaArea.rectCollisioni[9].colliderect(rect_prova) and flagUltimo != "ananas"):
						cittaLocaleTombolone.main(player, inventario)
						if(player.ricominciaDopoSconfitta == True):
							main = False
						player.settaPoz(world, 700, 750)
						camminiamo.settaUP()
						nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
						ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player, flagUltimo)
					elif (miaArea.rectCollisioni[11].colliderect(rect_prova)):
						stradaPerTempio.main(player, inventario, flagUltimo)
						player.settaPoz(world, 700, 10)
						camminiamo.settaDOWN()
						nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
						ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player, flagUltimo)
					elif (miaArea.rectCollisioni[10].colliderect(rect_prova) and flagUltimo != "ananas"):
						foresta1.main(player, inventario)
						player.settaPoz(world, 70, 380)
						camminiamo.settaRight()
						nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
						ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player, flagUltimo)
				if event.key  == pygame.K_RETURN:
					if (miaArea.rectCollisioni[6].colliderect(rect_prova)):
						print("parlo con doggo ")
						dialogo.stampaDialoghi(world, 1, "Immagini_Gioco/DialoghiNPC/npc_secondari/doggoArmor.png")
						ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player, flagUltimo)
					elif (miaArea.rectCollisioni[7].colliderect(rect_prova)):
						dialogo.stampaDialoghi(world, 2, "Immagini_Gioco/DialoghiNPC/npc_secondari/osvaldo.png")
						ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player, flagUltimo)
						print("parlo con omino ")
				if event.key == 105:
					inventario.stampaInventario(player, world)
					ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player, flagUltimo)
					
						
						
					
			pygame.display.flip()

