import pygame, sys


class Colonna():

	def __init__(self, PATH_COLONNA):
		self.pathColonna = PATH_COLONNA
		self.volume = 0
		self.FLAGPAUSE = False
		
	
	def setColonnaSonora(self):
		if(self.FLAGPAUSE == True):
			pygame.mixer.music.load(self.pathColonna)
			pygame.mixer.music.play(-1)   #play della colonna sonora -1 ---> indica per tempo infinito
			pygame.mixer.music.set_volume(self.volume)
			pygame.mixer.music.pause()
		else:
			pygame.mixer.music.load(self.pathColonna)
			pygame.mixer.music.play(-1)   #play della colonna sonora -1 ---> indica per tempo infinito
			pygame.mixer.music.set_volume(self.volume)
			
	def settingVol(self):
		pygame.mixer.music.set_volume(self.volume)
			
	def setVolume(self, val):
		self.volume = val
		
	def setFLAG(self, flag):
		self.FLAGPAUSE = flag
		
	def getFLAG(self):
		return self.FLAGPAUSE

	def getVolume(self):
		return self.volume
		
	def unload(self):
		pygame.mixer.music.unload()
