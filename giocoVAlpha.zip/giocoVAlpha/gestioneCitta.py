import pygame
from pygame.locals import *


class areaCiccios():

	def __init__(self, PATH):
		self.rectCollisioni = []
		self.rectDialoghi = []
		self.surfArea = pygame.image.load(PATH)
		
		
	def settaCollisione(self, collisione):
		self.rectCollisioni.append(collisione)
		
	def getSurfArea(self):
		return self.surfArea
	
	
#PER MAPPA CICCIO
	def verificaCollisione(self, poz):
		flag = 0
		collisione = False
		for i in range(len(self.rectCollisioni)):
		
			if poz.colliderect(self.rectCollisioni[i]):
				if i != 9 and i!= 10:
					collisione = True
					flag = 1
					i = len(self.rectCollisioni) + 1
				
		return collisione
		
		
	def verificaEntrata(self, poz):
		
		if self.rectCollisioni[9].colliderect(poz):
			return True
		else:
			return False
	
	def cambiaArea(self, poz):
		if self.rectCollisioni[10].colliderect(poz):
			return True
		else:
			return False
			
########################################

#PER MAPPA GALLINE	
	def verificaCollisione2(self, poz):
		flag = 0
		collisione = False
		for i in range(len(self.rectCollisioni)):
		
			if poz.colliderect(self.rectCollisioni[i]):
				collisione = True
				i = len(self.rectCollisioni) + 1
				
		return collisione


#CITTAAA  		
	def verificaCollisione3(self, poz):
		flag = 0
		collisione = False
		for i in range(len(self.rectCollisioni)):
		
			if poz.colliderect(self.rectCollisioni[i]):
				collisione = True
				i = len(self.rectCollisioni) + 1
				
		return collisione
		
##### TOMBOLONE

	def verificaCollisione4(self, poz):
		flag = 0
		collisione = False
		for i in range(len(self.rectCollisioni)):
		
			if poz.colliderect(self.rectCollisioni[i]):
				collisione = True
				i = len(self.rectCollisioni) + 1
				
		return collisione
		
								
