import pygame, sys
import pygame_menu #libreria di pygame che permette una facile creazione del main menu di gioco
from pygame_menu import sound
from pygame.locals import *
#import mappaLivelli
import time, datetime
#import crazyPalace
import classPG
import PiumaAttacco
import attaccoOrizzontale
import random
import Camminata
import Player
import attaccoVerti
import attaccoObliquo

pygame.font.init()
font = pygame.font.Font('Immagini_Gioco/DialoghiNPC/fontDialoghi/vito/Crashnumberinggothic-MAjp.ttf', 40, bold=True)

arrayPiume = attaccoOrizzontale.AttaccoOri()
arrayPiumeV = attaccoVerti.AttaccoVerti()
arrayPiumeObli = attaccoObliquo.AttaccoObli()
camminiamo = Camminata.Camminata()
#player = Player.Player(camminiamo.getUpPath(), 600, 400)

#PIUME VERDI 
ver = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/piumaLancio.png")
verV =  pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/piumaLancioV.png")
verOb =  pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/piumaLancioObli.png")
verOb2 = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/piumaLancioSx.png")
verOb3 = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/piumaLancioUP.png")
verOb4 =  pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/piumaLanciodOWN.png")

#PIUME ROSSE

ros = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/piumaLancioRossa.png")
rosV =  pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/piumaLancioVRossa.png")
rosOb =  pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/piumaLancioObliRossa.png")
rosOb2 = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/piumaLancioSxRossa.png")
rosOb3 = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/piumaLancioUPRossa.png")
rosOb4 =  pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/piumaLanciodOWNRossa.png")


#PIUME VIOLA
vio = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/piumaLancioViola.png")
vioV =  pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/piumaLancioVViola.png")
vioOb =  pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/piumaLancioObliViola.png")
vioOb2 = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/piumaLancioSxViola.png")
vioOb3 = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/piumaLancioUPViola.png")
vioOb4 =  pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/piumaLanciodOWNViola.png")

#PIZZA ANANAS

pizzaAtt = pygame.image.load("Immagini_Gioco/ULTIMO_LIVELLO/attaccoPizzaP.png")

surf_laserOrizontale = pygame.image.load("Immagini_Gioco/ULTIMO_LIVELLO/laseroneOrizontale.png")
rectLaserOr = surf_laserOrizontale.get_rect()
rectLaserOr.x = -10000
rectLaserOr.y = -10000

surf_laserVerticale = pygame.image.load("Immagini_Gioco/ULTIMO_LIVELLO/laseroneAttack.png")
rectLaserVr = surf_laserVerticale.get_rect()
rectLaserVr.x = -10000
rectLaserVr.y = -10000

arrayPosizioniPizzaLaser = [(1000, 400), (1000, 500), (1000, 600), (1000, 300), (1000, 200)]
arrayPosizioniPizzaLaserV = [(150, -90), (350, -90), (550, -90), (750, -90), (950, -90) ]
arrayPosizioneLaserOr = [ (180, 445), (180, 545), (180, 645), (180, 335), (180, 225)]
arrayPosizioneLaserV =	[(195, 120), (395, 120), (595, 120), (795, 120), (995, 120) ]

startBattle = 'Suoni/startBattle.wav'
suonoColpo = 'Suoni/colpo.wav'
suonoLaser  = 'Suoni/laser.ogg'
 # nostro oggetto piuma
 
ripeti = 0
 

def effettoSonoro(volume, suono):
	effect = pygame.mixer.Sound(suono)
	effect.play()	
	
	

def ristampaMovi(world, x, y):
	
	path_stampa = camminiamo.ristampaMovi()
	surf_posizione= pygame.image.load(path_stampa)
	world.blit(surf_posizione, (x,y))
	return path_stampa

#def colonnaSonora(volume,FLAGPAUSE):
#	if(FLAGPAUSE == True):
#		pygame.mixer.music.load("Suoni/bonetrousle.wav")
#		pygame.mixer.music.play(-1)   #play della colonna sonora -1 ---> indica per tempo infinito
#		pygame.mixer.music.set_volume(volume)
#		pygame.mixer.music.pause()
#	else:
#		pygame.mixer.music.load("Suoni/bonetrousle.wav")
#		pygame.mixer.music.play(-1)   #play della colonna sonora -1 ---> indica per tempo infinito
#		pygame.mixer.music.set_volume(volume)
		
def ristampaOnlyPlayer(world, x, y):
	world.blit(player.getSurfPlayer(), (x,y))
		
def ristampa(world, x, y,  PATH, rect, check,  player, oca):

	world.fill((0,0,0))

	if oca == "verde":
		surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/pavimentocrazy.jpg").convert()
		world.blit(surf_background, (180, 175))
	elif oca == "rossa" or oca == "viola":
		surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/pavimentoOcaR.jpg").convert()
		world.blit(surf_background, (180, 175))	
	elif oca == "pizza":
		surf_background = pygame.image.load("Immagini_Gioco/ULTIMO_LIVELLO/sfondoAtt.jpg").convert()
		world.blit(surf_background, (180, 175))		
	
	if (oca != "pizza"):
		surf_enemy = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/enemyBox.jpg")
		world.blit(surf_enemy, (415, 15))
	

	surf_Player=pygame.image.load(PATH)
	#pygame.draw.rect(world, (255,0,0), rect) 
	
	surf_vita=  pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/PuntiPizzaSegnale.png")
	xV = 150
	yV= 840
	world.blit(surf_vita, (xV,yV))
	
	xB = 220
	yB= 845
	world.blit(surf_vita, (xV,yV))
	world.blit(player.ritornaPizzaBar(), (xB, yB))
	world.blit(font.render(str(player.HP), False, (255, 255, 255)) ,(350, 860))
	if (check == False):
		world.blit(surf_Player, (x,y))
	else:
		if(camminiamo.inDX()):
			world.blit(pygame.image.load(camminiamo.getRightColpito()[camminiamo.lastPos]), (x,y))
		elif(camminiamo.inSX()):
			world.blit(pygame.image.load(camminiamo.getLeftColpito()[camminiamo.lastPos]), (x,y))
		elif(camminiamo.inUP()):
			world.blit(pygame.image.load(camminiamo.getUpColpito()[camminiamo.lastPos]), (x,y))
		elif(camminiamo.inDOWN()):
			world.blit(pygame.image.load(camminiamo.getDownColpito()[camminiamo.lastPos]), (x,y))
			
	if(oca == "verde"):
		surf_oca =  pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/ocaUnder.png")
		world.blit(surf_oca, (485, 20))
	elif(oca == "rossa"):
		surf_oca =  pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/robaOcaRossa/ocaRossaTurno.png")
		world.blit(surf_oca, (485, 35))		
	elif(oca == "viola"):	
		surf_oca =  pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/robaOcaViola/ocaViolaTurno.png")
		world.blit(surf_oca, (485, 35))				

	#pygame.draw.rect(world, (0,0,0), rectLaserOr) 
	

	
def caricaPiumeOrizzontali(P1, P2, verti, oca):


	if oca == "verde":
		arrayPiume.arrayPiume = []
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2, 1, ver))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 3, 2, ver))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 5, 3 , ver))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 7 , 4, ver))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 9, 5, ver))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 11,6 ,ver))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 13, 7, ver))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 15, 8, ver))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 17, 9, ver))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 19, 10, ver ))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 21, 11, ver))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 23, 12, ver))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 25, 13, ver))
	elif oca == "rossa":
		arrayPiume.arrayPiume = []
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2, 1, ros))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 3, 2, ros))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 5, 3 , ros))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 7 , 4, ros))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 9, 5, ros))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 11,6 ,ros))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 13, 7, ros))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 15, 8, ros))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 17, 9, ros))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 19, 10, ros))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 21, 11, ros))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 23, 12, ros))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 25, 13, ros))
	elif oca == "viola":
		arrayPiume.arrayPiume = []
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2, 1, vio))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 3, 2, vio))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 5, 3 , vio))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 7 , 4, vio))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 9, 5, vio))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 11,6 ,vio))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 13, 7, vio))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 15, 8, vio))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 17, 9, vio))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 19, 10, vio))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 21, 11, vio))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 23, 12, vio))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 25, 13, vio))	
	elif oca == "pizza":
		arrayPiume.arrayPiume = []
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2, 1, pizzaAtt))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 3, 2, pizzaAtt))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 5, 3 , pizzaAtt))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 7 , 4, pizzaAtt))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 9, 5, pizzaAtt))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 11,6 ,pizzaAtt))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 13, 7, pizzaAtt))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 15, 8, pizzaAtt))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 17, 9, pizzaAtt))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 19, 10, pizzaAtt))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 23, 12, pizzaAtt))
		arrayPiume.pushPiuma(PiumaAttacco.PiumaAtt(P1, P2 + verti * 25, 13, pizzaAtt))					


def caricaPiumeVerticali(P1, P2, verti, oca):

	if oca == "verde":
		arrayPiumeV.arrayPiume = []
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1, P2, 1, verV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 3, P2, 2, verV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 5, P2 ,3 , verV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 7, P2  , 4 , verV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 9, P2 , 5 , verV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 11, P2 , 6, verV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 13, P2,7  , verV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 15, P2, 8 , verV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 17, P2 , 9, verV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 19, P2, 10, verV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 21, P2, 11, verV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 23, P2, 12, verV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 25, P2, 13, verV))	
	elif oca == "rossa":
		arrayPiumeV.arrayPiume = []
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1, P2, 1, rosV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 3, P2, 2, rosV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 5, P2 ,3 , rosV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 7, P2  , 4 , rosV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 9, P2 , 5 , rosV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 11, P2 , 6, rosV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 13, P2,7  , rosV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 15, P2, 8 , rosV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 17, P2 , 9, rosV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 19, P2, 10, rosV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 21, P2, 11, rosV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 23, P2, 12, rosV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 25, P2, 13, rosV))	
	elif oca == "viola":
		arrayPiumeV.arrayPiume = []
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1, P2, 1, vioV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 3, P2, 2, vioV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 5, P2 ,3 , vioV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 7, P2  , 4 , vioV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 9, P2 , 5 , vioV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 11, P2 , 6, vioV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 13, P2,7  , vioV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 15, P2, 8 , vioV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 17, P2 , 9, vioV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 19, P2, 10, vioV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 21, P2, 11, vioV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 23, P2, 12, vioV))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 25, P2, 13, vioV))	
	elif oca == "pizza":
		arrayPiumeV.arrayPiume = []
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1, P2, 1, pizzaAtt))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 3, P2, 2, pizzaAtt))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 5, P2 ,3 , pizzaAtt))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 7, P2  , 4 , pizzaAtt))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 9, P2 , 5 , pizzaAtt))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 11, P2 , 6, pizzaAtt))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 13, P2,7  , pizzaAtt))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 15, P2, 8 ,pizzaAtt))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 17, P2 , 9, pizzaAtt))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 19, P2, 10, pizzaAtt))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 21, P2, 11, pizzaAtt))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 23, P2, 12, pizzaAtt))
		arrayPiumeV.pushPiuma(PiumaAttacco.PiumaAttV(P1 + verti * 25, P2, 13, pizzaAtt))	
			
def caricaPiumeObli(P1, P2, verti, oca):

	if oca == "verde":
	
		arrayPiumeObli.arrayPiume = []
		
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2, 1, verOb))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 2, 2, verOb))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 4, 3 , verOb))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 6, 4, verOb))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 8, 5, verOb))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 10,6 , verOb))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1  , P2 + verti * 12, 7, verOb))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 14 , 8, verOb))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 16 , 8, verOb))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 18 , 8, verOb))
		#arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAtt(P1 + verti * 3, P2 + verti * 3, 9))
		#arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAtt(P1 + verti * 3 , P2 + verti * 3, 10))
		#arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAtt(P1 + verti * 3, P2+ verti * 3 , 11))
		#arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAtt(P1 + verti * 3, P2 + verti * 3, 12))
		#arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAtt(P1+ verti * 3 , P2 + verti * 3 , 13))
	elif oca == "rossa":
		arrayPiumeObli.arrayPiume = []
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2, 1, rosOb))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 2, 2, rosOb))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 4, 3 , rosOb))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 6, 4, rosOb))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 8, 5, rosOb))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 10,6 , rosOb))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1  , P2 + verti * 12, 7, rosOb))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 14 , 8, rosOb))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 16 , 8, rosOb))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 18 , 8, rosOb))
	elif oca == "viola":
		arrayPiumeObli.arrayPiume = []
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2, 1, vioOb))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 2, 2,  vioOb))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 4, 3 ,  vioOb))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 6, 4,  vioOb))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 8, 5,  vioOb))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 10,6 ,  vioOb))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1  , P2 + verti * 12, 7,  vioOb))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 14 , 8, vioOb))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 16 , 8,  vioOb))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 18 , 8,  vioOb))
	elif oca == "pizza":
		arrayPiumeObli.arrayPiume = []
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2, 1,pizzaAtt))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 2, 2,  pizzaAtt))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 4, 3 , pizzaAtt))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 6, 4,  pizzaAtt))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 8, 5,  pizzaAtt))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 10,6 ,  pizzaAtt))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1  , P2 + verti * 12, 7,  pizzaAtt))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 14 , 8, pizzaAtt))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 16 , 8,  pizzaAtt))
		arrayPiumeObli.pushPiuma(PiumaAttacco.PiumaAttObli(P1 , P2 + verti * 18 , 8,  pizzaAtt))		
			
def caricaPiumeObliSx(P1, P2, verti, oca):

	if oca == "verde":
		arrayPiumeObli.arrayPiumeSx = []
		
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2, 1, verOb2))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 2, 2, verOb2))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 4, 3, verOb2))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 6, 4, verOb2))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 8, 5, verOb2))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 10,6 , verOb2))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1  , P2 + verti * 12, 7, verOb2))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 14 , 8, verOb2))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 16 , 8, verOb2))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 18 , 8, verOb2))	
	elif oca == "rossa":
		arrayPiumeObli.arrayPiumeSx = []
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2, 1, rosOb2))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 2, 2, rosOb2))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 4, 3, rosOb2))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 6, 4, rosOb2))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 8, 5, rosOb2))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 10,6 , rosOb2))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1  , P2 + verti * 12, 7, rosOb2))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 14 , 8, rosOb2))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 16 , 8, rosOb2))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 18 , 8, rosOb2))
	elif oca == "viola":
		arrayPiumeObli.arrayPiumeSx = []
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2, 1, vioOb2))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 2, 2, vioOb2))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 4, 3, vioOb2))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 6, 4, vioOb2))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 8, 5,vioOb2))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 10,6 , vioOb2))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1  , P2 + verti * 12, 7, vioOb2))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 14 , 8, vioOb2))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 16 , 8, vioOb2))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 18 , 8, vioOb2))
	elif oca == "pizza":
		arrayPiumeObli.arrayPiumeSx = []
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2, 1, pizzaAtt))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 2, 2, pizzaAtt))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 4, 3, pizzaAtt))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 6, 4, pizzaAtt))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 8, 5,pizzaAtt))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 10,6 , pizzaAtt))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1  , P2 + verti * 12, 7, pizzaAtt))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 14 , 8, pizzaAtt))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 16 , 8, pizzaAtt))
		arrayPiumeObli.pushPiumaSx(PiumaAttacco.PiumaAttObliSx(P1 , P2 + verti * 18 , 8, pizzaAtt))


def caricaPiumeObliUP(P1, P2, verti, oca):

	if oca == "verde":
		arrayPiumeObli.arrayPiumeUP = []
		
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2, 1, verOb3))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 2, 2, verOb3))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 4, 3 , verOb3))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 6, 4, verOb3))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 8, 5, verOb3))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 10,6, verOb3 ))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1  , P2 + verti * 12, 7, verOb3))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 14 , 8, verOb3))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 16 , 8, verOb3))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 18 , 8, verOb3))
	elif oca == "rossa":
		arrayPiumeObli.arrayPiumeUP = []
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2, 1, rosOb3))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 2, 2, rosOb3))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 4, 3 , rosOb3))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 6, 4, rosOb3))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 8, 5, rosOb3))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 10,6, rosOb3))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1  , P2 + verti * 12, 7, rosOb3))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 14 , 8, rosOb3))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 16 , 8,rosOb3))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 18 , 8, rosOb3))	
	elif oca == "viola":
		arrayPiumeObli.arrayPiumeUP = []
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2, 1, vioOb3))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 2, 2, vioOb3))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 4, 3 , vioOb3))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 6, 4, vioOb3))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 8, 5, vioOb3))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 10,6, vioOb3))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1  , P2 + verti * 12, 7, vioOb3))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 14 , 8, vioOb3))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 16 , 8,vioOb3))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 18 , 8, vioOb3))
	elif oca == "pizza":
		arrayPiumeObli.arrayPiumeUP = []
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2, 1, pizzaAtt))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 2, 2, pizzaAtt))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 4, 3 , pizzaAtt))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 6, 4, pizzaAtt))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 8, 5, pizzaAtt))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 10,6, pizzaAtt))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1  , P2 + verti * 12, 7, pizzaAtt))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 14 , 8, pizzaAtt))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 16 , 8,pizzaAtt))
		arrayPiumeObli.pushPiumaUP(PiumaAttacco.PiumaAttObliUP(P1 , P2 + verti * 18 , 8,pizzaAtt))			
	
def caricaPiumeObliDOWN(P1, P2, verti, oca):

	if oca == "verde":

		arrayPiumeObli.arrayPiumeDOWN = []
		
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2, 1, verOb4))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 2, 2, verOb4))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 4, 3, verOb4))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 6, 4, verOb4))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 8, 5, verOb4))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 10,6 , verOb4))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1  , P2 + verti * 12, 7, verOb4))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 14 , 8, verOb4))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 16 , 8, verOb4))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 18 , 8, verOb4))
	elif oca == "rossa":
		arrayPiumeObli.arrayPiumeDOWN = []
		
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2, 1, rosOb4))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 2, 2, rosOb4))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 4, 3, rosOb4))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 6, 4, rosOb4))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 8, 5, rosOb4))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 10,6 , rosOb4))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1  , P2 + verti * 12, 7, rosOb4))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 14 , 8, rosOb4))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 16 , 8, rosOb4))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 18 , 8, rosOb4))

	elif oca == "viola":
		arrayPiumeObli.arrayPiumeDOWN = []
		
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2, 1, vioOb4))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 2, 2, vioOb4))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 4, 3, vioOb4))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 6, 4, vioOb4))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 8, 5, vioOb4))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 10,6 , vioOb4))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1  , P2 + verti * 12, 7, vioOb4))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 14 , 8, vioOb4))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 16 , 8,vioOb4))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 18 , 8, vioOb4))
	elif oca == "pizza":
		arrayPiumeObli.arrayPiumeDOWN = []
		
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2, 1, pizzaAtt))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 2, 2, pizzaAtt))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 4, 3, pizzaAtt))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 6, 4, pizzaAtt))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 8, 5, pizzaAtt))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 10,6 , pizzaAtt))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1  , P2 + verti * 12, 7, pizzaAtt))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 14 , 8, pizzaAtt))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 16 , 8,pizzaAtt))
		arrayPiumeObli.pushPiumaDOWN(PiumaAttacco.PiumaAttObliDOWN(P1 , P2 + verti * 18 , 8,pizzaAtt))		
	
		
def main(turnoO, turnoVer, player, attaccoDaFare, turnoObli, oca, laser):
	pygame.init()
	worldx = 1280
	worldy = 920
	attaccoOca = 0
	fps = 40
	ani = 4
	if( oca == "verde"):
		velocita = 12
	elif(oca == "rossa"):
		velocita = 18
	elif(oca == "viola"):
		velocita = 18
	elif(oca == "pizza"):
		if ( attaccoDaFare == 2):
			velocita = 14
		else:
			velocita = 17
	world = pygame.display.set_mode((worldx, worldy))
	world.fill((0,0,0))
	#colonnaSonora(1 , False)
	steps = 20
	player.colpito_player = False
	
	P1 = 1163 # valori per attacchi orizzontali
	P2 = 276  # valori per attacchi orizzontali
	
	P3 = 190 # valori per attacchi verticali
	P4 = 890 # valori per attacchi verticali
	
	pOB = 1100
	pvOB = 810
	
	pOB_sx = 100
	pvOB_sx = 810
	
	pOB_up = 120
	pvOB_up = 100
	
	pOB_sx = 100
	pvOB_sx = 810	
	
	pOB_down = 1100
	pvOB_down = 100
	
	volume = 1
	ripeti = True
	verti = 20
	if oca == "verde":
		surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/pavimentoCrazy.png").convert()
		world.blit(surf_background, (180, 175))
	elif oca == "rossa":
		surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/pavimentoOcaR.jpg").convert()
		world.blit(surf_background, (180, 175))		
		
	elif oca == "pizza":
		surf_background = pygame.image.load("Immagini_Gioco/ULTIMO_LIVELLO/sfondoAtt.jpg").convert()
		world.blit(surf_background, (180, 175))			
	PP = True
	PV = True
	
	if oca != "pizza":
		surf_enemy = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/enemyBox.jpg")
		world.blit(surf_enemy, (415, 15))
	
	if(oca == "verde"):
		surf_oca =  pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/ocaUnder.png")
		world.blit(surf_oca, (485, 20))
	elif(oca == "rossa"):
		surf_oca =  pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/robaOcaRossa/ocaRossaTurno.png")
		world.blit(surf_oca, (485, 35))		
	elif(oca == "viola"):	
		surf_oca =  pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/robaOcaViola/ocaViolaTurno.png")
		world.blit(surf_oca, (485, 35))				
	
	nuovaPoz = camminiamo.getUpPath()
	player.settaPoz(world, 700, 400)
	#surf_chef=pygame.image.load(camminiamo.getUpPath())
	#rect_chef = surf_chef.get_rect()
	#x=550  
	#y=780  
	#pygame.draw.rect(world, (255,0,0), player.getRectPlayer()) 
	world.blit(player.getSurfPlayer(), (player.getRectPlayer().x , player.getRectPlayer().y))
	#pygame.draw.rect(world, (255,0,0), rect_omo) 
	
	surf_vita=  pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/PuntiPizzaSegnale.png")
	x = 450
	y= 850
	world.blit(surf_vita, (x,y))
	
	xB = 220
	yB = 845
	world.blit(player.ritornaPizzaBar(), (xB, yB))
	world.blit(font.render(str(player.HP), False, (255, 255, 255)) ,(350, 860))
	pygame.display.flip()	
	
	
	caricaPiumeOrizzontali(P1, P2, verti, oca)
	caricaPiumeVerticali(P3, P4, verti, oca)
	caricaPiumeObli(pOB,pvOB, verti, oca)
	caricaPiumeObliSx(pOB_sx,pvOB_sx, verti, oca)
	caricaPiumeObliUP(pOB_up,pvOB_up, verti, oca)
	caricaPiumeObliDOWN(pOB_down,pvOB_down, verti, oca)
	
	clock1 = pygame.time.Clock()
	clock2 = pygame.time.Clock()
	clock3 = pygame.time.Clock()
	clock4 = pygame.time.Clock()
	
	
	pygame.key.set_repeat(30,30)
	
	turno = 0
	turnoV = 0
	turnoOb = 0
	
	muoviz = 0
	app = 0
	cont = 0
	cont2 = 0
	proa = 2
	obliquo = 0
	direzione = 1
	tempoLaser = 0
	turnoDopoRaggio = 0
	raggioFatto = 0
	turnoLas = 0
	
	faiR = random.randint(0, 4)
	vecchiaPosOr = faiR
	
	
	if (attaccoDaFare == 2):
		o = random.randint(-7, 7)
		o2 = random.randint(-8, 8)	
	else:	
		o = random.randint(-10, 10)
		o2 = random.randint(-10, 10)
	while ripeti:
		print(camminiamo.getLast())
		attackOca = clock2.tick()
		waitForLaser = clock3.tick()
		raggioDopo = clock4.tick()
		#attaccoOca = attackOca + attaccoOca
		#print(muoviz)
		print(turnoO)
		if(player.ritornaHP() <= 0):
			ripeti = False
		if o == 0:
			o = random.randint(-10, 10)
		if o2 == 0:
			o2 = random.randint(-10, 10)
		clock1.tick(27)
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				sys.exit()
			elif event.type == pygame.MOUSEBUTTONDOWN:
				click = event.pos
				print(click)
			if event.type == pygame.KEYDOWN:
				if(muoviz != 1):
					if event.key == pygame.K_LEFT:
						x2 = player.getRectPlayer().x - steps
						y2 = player.getRectPlayer().y
						prova = x2 - player.getRectPlayer().x
						prova2 = y2 - player.getRectPlayer().y
						rect_prova = player.getRectPlayer().move(prova, prova2)
						if( rect_prova.x >= 170):
							player.setRect(prova, prova2)
							camminiamo.settaLeft()
							nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
							ristampa(world, player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player.getRectPlayer(), player.checkColpito(), player, oca)
							
								
						
				if (event.key == pygame.K_RIGHT):
					x2 = player.getRectPlayer().x + steps
					y2 = player.getRectPlayer().y
					prova = x2 - player.getRectPlayer().x
					prova2 = y2 - player.getRectPlayer().y
					rect_prova = player.getRectPlayer().move(prova, prova2)
					if( rect_prova.x <= 1020):
						player.setRect(prova, prova2)
						camminiamo.settaRight()
						nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
						ristampa(world, player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player.getRectPlayer(), player.checkColpito(), player,oca)
					
					
				if event.key == pygame.K_UP :
					if(muoviz != 1):
						x2 = player.getRectPlayer().x
						y2 = player.getRectPlayer().y - steps
						prova = x2 - player.getRectPlayer().x
						prova2 = y2 - player.getRectPlayer().y
						rect_prova = player.getRectPlayer().move(prova, prova2)
						if(rect_prova.x > 320 and rect_prova.x < 825):
							if  rect_prova.y >= 280:
								player.setRect(prova, prova2)
								camminiamo.settaUP()
								nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
								ristampa(world, player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player.getRectPlayer(), player.checkColpito(), player, oca)
						elif rect_prova.y >= 150:
							player.setRect(prova, prova2)
							camminiamo.settaUP()
							nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
							ristampa(world, player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player.getRectPlayer(), player.checkColpito(), player, oca)							
					
							
								
				if event.key == pygame.K_DOWN:
					if(muoviz != 1):
						x2 = player.getRectPlayer().x
						y2 = player.getRectPlayer().y + steps
						prova = x2 - player.getRectPlayer().x
						prova2 = y2 - player.getRectPlayer().y
						rect_prova = player.getRectPlayer().move(prova, prova2)
						if( rect_prova.y <= 700):
							player.setRect(prova, prova2)
							camminiamo.settaDOWN()
							nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
							ristampa(world, player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player.getRectPlayer(), player.checkColpito(), player, oca)
			
					
		ristampa(world, player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player.getRectPlayer(), player.checkColpito(), player, oca)
		if (attaccoDaFare == 0):
			if(player.colpito_player == True):
				if(player.flagNoDanno == True):
					player.flagNoDanno = False
				ristampa(world, player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player.getRectPlayer(), player.checkColpito(), player, oca)
				steps = 5
				attaccoOca = attackOca + attaccoOca
				print(attaccoOca)
				if (attaccoOca >= 2000):
					steps = 20
					app = 0
					print("fatto")
					player.colpito_player = False
					attaccoOca = 0
			#pygame.display.flip()
			#player.setLast(camminiamo)
			print(app)
			if(turnoV < turnoVer):
				if(P4 <= 325):
					print("ou")
					if(cont2 == 1):
						cont2 = 0
					turnoV = turnoV + 1
					P4 = 890
					#ristampa(world, player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player.getRectPlayer(), player.checkColpito())
					o2 = random.randint(-10, 10)
					if o2 == 0 or (abs(o2) < 4):
						o2 = random.randint(-10, 10)

				else:
					arrayPiumeV.settingAttacco(o2)
					PV = arrayPiumeV.attaccoVerticale(world, P4, player)
					pygame.display.flip()
					P4 = P4 - (velocita - 7)
					if (PV == False and cont2 == 0):
						if(player.checkColpito() == False):
							effettoSonoro(volume, suonoColpo)
							cont2 = 1
							player.setColpito()
							if(player.flagNoDanno == False):
								if(oca == "verde"):
									player.colpito(10)
								elif (oca == "rossa"):
									player.colpito(15)
								elif (oca == "viola"):
									player.colpito(20)
								elif (oca == "pizza"):
									player.colpito(50)
					
			if(turno < turnoO):
				if(P1 > 100):
					arrayPiume.settingAttacco(o)
					PP = arrayPiume.attaccoOrizzontale(world, P1, player)
					pygame.display.flip()
					P1 = P1 - velocita
					if (PP == False and cont == 0):
						if(player.checkColpito() == False):
							effettoSonoro(volume, suonoColpo)
							cont = 1
							player.setColpito()
							if(player.flagNoDanno == False):
								if(oca == "verde"):
									player.colpito(10)
								elif (oca == "rossa"):
									player.colpito(15)
								elif (oca == "viola"):
									player.colpito(20)
								elif (oca == "pizza"):
									player.colpito(50)
				else:
					#ristampa(world, player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player.getRectPlayer(), player.checkColpito())
					if(cont == 1):
						cont = 0
					turno = turno + 1
					P1 = 1163
					o = random.randint(-10, 10)
					if o == 0 or (abs(o) < 4):
						o = random.randint(-10, 10)


				print(turno , turnoV)
			if(turno  == turnoO and turnoV == turnoVer  and player.checkColpito() == False):
				print(turnoO, turnoVer, turno, turnoV)
				time.sleep(1)
				ripeti = 1
				ripeti = False
		if(attaccoDaFare == 1):
			#world.blit(arrayPiumeObli.returnArrayPiuma()[0].getSurfPiuma(), (pOB,pvOB))
			if(player.colpito_player == True):
				if(player.flagNoDanno == True):
					player.flagNoDanno = False
				ristampa(world, player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player.getRectPlayer(), player.checkColpito(), player, oca)
				steps = 5
				attaccoOca = attackOca + attaccoOca
				print(attaccoOca)
				if (attaccoOca >= 2000):
					steps = 20
					app = 0
					print("fatto")
					player.colpito_player = False
					attaccoOca = 0
					
			if(turno < turnoObli):
				print(arrayPiumeObli.arrayPiume[0].getRectPiuma().x)
				
				
				if(cont == 1):
					cont = 0
				
				if( direzione == 1):
					if(arrayPiumeObli.arrayPiume[0].getRectPiuma().x < 100):
						arrayPiumeObli.arrayPiume[0].risettaPosizioneIniziale(pOB, pvOB)
						arrayPiumeObli.arrayPiume[1].risettaPosizioneIniziale(pOB, pvOB + verti *2)
						arrayPiumeObli.arrayPiume[2].risettaPosizioneIniziale(pOB, pvOB + verti *4)
						arrayPiumeObli.arrayPiume[3].risettaPosizioneIniziale(pOB, pvOB + verti *6)
						arrayPiumeObli.arrayPiume[4].risettaPosizioneIniziale(pOB, pvOB + verti *8)
						arrayPiumeObli.arrayPiume[5].risettaPosizioneIniziale(pOB, pvOB + verti *10)
						arrayPiumeObli.arrayPiume[6].risettaPosizioneIniziale(pOB, pvOB + verti *12)
						arrayPiumeObli.arrayPiume[7].risettaPosizioneIniziale(pOB, pvOB + verti *14)
						arrayPiumeObli.arrayPiume[8].risettaPosizioneIniziale(pOB, pvOB + verti *16)
						arrayPiumeObli.arrayPiume[9].risettaPosizioneIniziale(pOB, pvOB + verti *18)
						turno = turno +1
						direzione = random.randint(1, 4)
						
					else:
						print("Ou")
						PPOB = arrayPiumeObli.attaccoObliquo(world, pOB, pvOB, player, velocita)
						if (PPOB == False and cont == 0):
							if(player.checkColpito() == False):
								effettoSonoro(volume, suonoColpo)
								cont = 1
								player.setColpito()
								if(player.flagNoDanno == False):
									if(oca == "verde"):
										player.colpito(10)
									elif (oca == "rossa"):
										player.colpito(15)
									elif (oca == "viola"):
										player.colpito(20)
									elif (oca == "pizza"):
										player.colpito(50)
								
				elif(direzione == 2):
					if(arrayPiumeObli.arrayPiumeSx[0].getRectPiuma().x > 1100):
						arrayPiumeObli.arrayPiumeSx[0].risettaPosizioneIniziale(pOB_sx, pvOB_sx)
						arrayPiumeObli.arrayPiumeSx[1].risettaPosizioneIniziale(pOB_sx, pvOB_sx + verti *2)
						arrayPiumeObli.arrayPiumeSx[2].risettaPosizioneIniziale(pOB_sx, pvOB_sx + verti *4)
						arrayPiumeObli.arrayPiumeSx[3].risettaPosizioneIniziale(pOB_sx, pvOB_sx + verti *6)
						arrayPiumeObli.arrayPiumeSx[4].risettaPosizioneIniziale(pOB_sx, pvOB_sx + verti *8)
						arrayPiumeObli.arrayPiumeSx[5].risettaPosizioneIniziale(pOB_sx, pvOB_sx + verti *10)
						arrayPiumeObli.arrayPiumeSx[6].risettaPosizioneIniziale(pOB_sx, pvOB_sx + verti *12)
						arrayPiumeObli.arrayPiumeSx[7].risettaPosizioneIniziale(pOB_sx, pvOB_sx + verti *14)
						arrayPiumeObli.arrayPiumeSx[8].risettaPosizioneIniziale(pOB_sx, pvOB_sx + verti *16)
						arrayPiumeObli.arrayPiumeSx[9].risettaPosizioneIniziale(pOB_sx, pvOB_sx + verti *18)
						turno = turno +1
						direzione = random.randint(1, 4)
					else:
						print("Ou")
						PPOB = arrayPiumeObli.attaccoObliquoSx(world, pOB, pvOB, player, velocita)
						if (PPOB == False and cont == 0):
							if(player.checkColpito() == False):
								effettoSonoro(volume, suonoColpo)
								cont = 1
								player.setColpito()
								if(player.flagNoDanno == False):
									if(oca == "verde"):
										player.colpito(10)
									elif (oca == "rossa"):
										player.colpito(15)
									elif (oca == "viola"):
										player.colpito(20)	
									elif (oca == "pizza"):
										player.colpito(50)
				elif(direzione == 3):
					if(arrayPiumeObli.arrayPiumeUP[0].getRectPiuma().x > 1100):
						arrayPiumeObli.arrayPiumeUP[0].risettaPosizioneIniziale(pOB_up, pvOB_up)
						arrayPiumeObli.arrayPiumeUP[1].risettaPosizioneIniziale(pOB_up, pvOB_up + verti *3)
						arrayPiumeObli.arrayPiumeUP[2].risettaPosizioneIniziale(pOB_up, pvOB_up + verti *5)
						arrayPiumeObli.arrayPiumeUP[3].risettaPosizioneIniziale(pOB_up, pvOB_up + verti *7)
						arrayPiumeObli.arrayPiumeUP[4].risettaPosizioneIniziale(pOB_up, pvOB_up + verti *9)
						arrayPiumeObli.arrayPiumeUP[5].risettaPosizioneIniziale(pOB_up, pvOB_up + verti *11)
						arrayPiumeObli.arrayPiumeUP[6].risettaPosizioneIniziale(pOB_up, pvOB_up + verti *13)
						arrayPiumeObli.arrayPiumeUP[7].risettaPosizioneIniziale(pOB_up, pvOB_up + verti *15)
						arrayPiumeObli.arrayPiumeUP[8].risettaPosizioneIniziale(pOB_up, pvOB_up + verti *16)
						arrayPiumeObli.arrayPiumeUP[9].risettaPosizioneIniziale(pOB_up, pvOB_up + verti *18)
						turno = turno +1
						direzione = random.randint(1, 4)
					else:
						print("Ou")
						PPOB = arrayPiumeObli.attaccoObliquoUP(world, pOB, pvOB, player, velocita)
						if (PPOB == False and cont == 0):
							if(player.checkColpito() == False):
								effettoSonoro(volume, suonoColpo)
								cont = 1
								player.setColpito()
								if(player.flagNoDanno == False):
									if(oca == "verde"):
										player.colpito(10)
									elif (oca == "rossa"):
										player.colpito(15)
									elif (oca == "viola"):
										player.colpito(20)	
									elif (oca == "pizza"):
										player.colpito(30)
				elif (direzione == 4):
					if(arrayPiumeObli.arrayPiumeDOWN[0].getRectPiuma().x < 100):
						arrayPiumeObli.arrayPiumeDOWN[0].risettaPosizioneIniziale(pOB_down, pvOB_down)
						arrayPiumeObli.arrayPiumeDOWN[1].risettaPosizioneIniziale(pOB_down, pvOB_down + verti *3)
						arrayPiumeObli.arrayPiumeDOWN[2].risettaPosizioneIniziale(pOB_down, pvOB_down + verti *5)
						arrayPiumeObli.arrayPiumeDOWN[3].risettaPosizioneIniziale(pOB_down, pvOB_down + verti *7)
						arrayPiumeObli.arrayPiumeDOWN[4].risettaPosizioneIniziale(pOB_down, pvOB_down + verti *9)
						arrayPiumeObli.arrayPiumeDOWN[5].risettaPosizioneIniziale(pOB_down, pvOB_down + verti *11)
						arrayPiumeObli.arrayPiumeDOWN[6].risettaPosizioneIniziale(pOB_down, pvOB_down + verti *13)
						arrayPiumeObli.arrayPiumeDOWN[7].risettaPosizioneIniziale(pOB_down, pvOB_down + verti *15)
						arrayPiumeObli.arrayPiumeDOWN[8].risettaPosizioneIniziale(pOB_down, pvOB_down + verti *16)
						arrayPiumeObli.arrayPiumeDOWN[9].risettaPosizioneIniziale(pOB_down, pvOB_down + verti *18)
						turno = turno +1
						direzione = random.randint(1, 4)
					else:
						print("Ou")
						PPOB = arrayPiumeObli.attaccoObliquoDOWN(world, pOB, pvOB, player, velocita)
						if (PPOB == False and cont == 0):
							if(player.checkColpito() == False):
								effettoSonoro(volume, suonoColpo)
								cont = 1
								player.setColpito()
								if(player.flagNoDanno == False):
									if(oca == "verde"):
										player.colpito(10)
									elif (oca == "rossa"):
										player.colpito(15)
									elif (oca == "viola"):
										player.colpito(20)
									elif (oca == "pizza"):
										player.colpito(30)
			if(turno  == turnoObli and player.checkColpito() == False):
				print(turnoO, turnoVer, turno, turnoV)
				time.sleep(1)
				ripeti = 1
				ripeti = False	
										
		if(attaccoDaFare == 2):
			if(player.colpito_player == True):
				if(player.flagNoDanno == True):
					player.flagNoDanno = False
				ristampa(world, player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player.getRectPlayer(), player.checkColpito(), player, oca)
				steps = 5
				attaccoOca = attackOca + attaccoOca
				print(attaccoOca)
				if (attaccoOca >= 2000):
					steps = 20
					app = 0
					print("fatto")
					player.colpito_player = False
					attaccoOca = 0
			#pygame.display.flip()
			#player.setLast(camminiamo)
			print(app)
			if(turnoV < turnoVer):
				if(P4 <= 325):
					print("ou")
					if(cont2 == 1):
						cont2 = 0
					turnoV = turnoV + 1
					P4 = 890
					#ristampa(world, player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player.getRectPlayer(), player.checkColpito())
					o2 = random.randint(-8, 8)
					if o2 == 0 or (abs(o2) < 4):
						o2 = random.randint(-8, 8)

				else:
					arrayPiumeV.settingAttacco(o2)
					PV = arrayPiumeV.attaccoVerticale(world, P4, player)
				#	pygame.display.flip()
					P4 = P4 - (velocita - 7)
					if (PV == False and cont2 == 0):
						if(player.checkColpito() == False):
							effettoSonoro(volume, suonoColpo)
							cont2 = 1
							player.setColpito()
							if(player.flagNoDanno == False):
								if(oca == "verde"):
									player.colpito(10)
								elif (oca == "rossa"):
									player.colpito(15)
								elif (oca == "viola"):
									player.colpito(20)
								elif (oca == "pizza"):
									player.colpito(30)
					
			if(turno < turnoO):
				if(P1 > 100):
					arrayPiume.settingAttacco(o)
					PP = arrayPiume.attaccoOrizzontale(world, P1, player)
					#pygame.display.flip()
					P1 = P1 - velocita
					if (PP == False and cont == 0):
						if(player.checkColpito() == False):
							effettoSonoro(volume, suonoColpo)
							cont = 1
							player.setColpito()
							if(player.flagNoDanno == False):
								if(oca == "verde"):
									player.colpito(10)
								elif (oca == "rossa"):
									player.colpito(15)
								elif (oca == "viola"):
									player.colpito(20)
								elif (oca == "pizza"):
									player.colpito(30)
				else:
					#ristampa(world, player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player.getRectPlayer(), player.checkColpito())
					if(cont == 1):
						cont = 0
					turno = turno + 1
					P1 = 1163
					o = random.randint(-7, 7)
					if o == 0 or (abs(o) < 4):
						o = random.randint(-7, 7)


		
			#world.blit(arrayPiumeObli.returnArrayPiuma()[0].getSurfPiuma(), (pOB,pvOB))

					
			if(turnoOb < turnoObli):
				print(arrayPiumeObli.arrayPiume[0].getRectPiuma().x)
				
				
				if(cont == 1):
					cont = 0
				
				if( direzione == 1):
					if(arrayPiumeObli.arrayPiume[0].getRectPiuma().x < 100):
						arrayPiumeObli.arrayPiume[0].risettaPosizioneIniziale(pOB, pvOB)
						arrayPiumeObli.arrayPiume[1].risettaPosizioneIniziale(pOB, pvOB + verti *2)
						arrayPiumeObli.arrayPiume[2].risettaPosizioneIniziale(pOB, pvOB + verti *4)
						arrayPiumeObli.arrayPiume[3].risettaPosizioneIniziale(pOB, pvOB + verti *6)
						arrayPiumeObli.arrayPiume[4].risettaPosizioneIniziale(pOB, pvOB + verti *8)
						arrayPiumeObli.arrayPiume[5].risettaPosizioneIniziale(pOB, pvOB + verti *10)
						#arrayPiumeObli.arrayPiume[6].risettaPosizioneIniziale(pOB, pvOB + verti *12)
						#arrayPiumeObli.arrayPiume[7].risettaPosizioneIniziale(pOB, pvOB + verti *14)
						#arrayPiumeObli.arrayPiume[8].risettaPosizioneIniziale(pOB, pvOB + verti *16)
						#arrayPiumeObli.arrayPiume[9].risettaPosizioneIniziale(pOB, pvOB + verti *18)
						turnoO = turnoO +1
						direzione = random.randint(1, 4)
						
					else:
						print("Ou")
						PPOB = arrayPiumeObli.attaccoObliquo(world, pOB, pvOB, player, velocita - 4)
						if (PPOB == False and cont == 0):
							if(player.checkColpito() == False):
								effettoSonoro(volume, suonoColpo)
								cont = 1
								player.setColpito()
								if(player.flagNoDanno == False):
									if(oca == "verde"):
										player.colpito(10)
									elif (oca == "rossa"):
										player.colpito(15)
									elif (oca == "viola"):
										player.colpito(20)
									elif (oca == "pizza"):
										player.colpito(30)
								
				elif(direzione == 2):
					if(arrayPiumeObli.arrayPiumeSx[0].getRectPiuma().x > 1100):
						arrayPiumeObli.arrayPiumeSx[0].risettaPosizioneIniziale(pOB_sx, pvOB_sx)
						arrayPiumeObli.arrayPiumeSx[1].risettaPosizioneIniziale(pOB_sx, pvOB_sx + verti *2)
						arrayPiumeObli.arrayPiumeSx[2].risettaPosizioneIniziale(pOB_sx, pvOB_sx + verti *4)
						arrayPiumeObli.arrayPiumeSx[3].risettaPosizioneIniziale(pOB_sx, pvOB_sx + verti *6)
						arrayPiumeObli.arrayPiumeSx[4].risettaPosizioneIniziale(pOB_sx, pvOB_sx + verti *8)
						arrayPiumeObli.arrayPiumeSx[5].risettaPosizioneIniziale(pOB_sx, pvOB_sx + verti *10)
						#arrayPiumeObli.arrayPiumeSx[6].risettaPosizioneIniziale(pOB_sx, pvOB_sx + verti *12)
						#arrayPiumeObli.arrayPiumeSx[7].risettaPosizioneIniziale(pOB_sx, pvOB_sx + verti *14)
						#arrayPiumeObli.arrayPiumeSx[8].risettaPosizioneIniziale(pOB_sx, pvOB_sx + verti *16)
					#	arrayPiumeObli.arrayPiumeSx[9].risettaPosizioneIniziale(pOB_sx, pvOB_sx + verti *18)
						turnoOb = turnoOb +1
						direzione = random.randint(1, 4)
					else:
						print("Ou")
						PPOB = arrayPiumeObli.attaccoObliquoSx(world, pOB, pvOB, player, velocita - 4)
						if (PPOB == False and cont == 0):
							if(player.checkColpito() == False):
								effettoSonoro(volume, suonoColpo)
								cont = 1
								player.setColpito()
								if(player.flagNoDanno == False):
									if(oca == "verde"):
										player.colpito(10)
									elif (oca == "rossa"):
										player.colpito(15)
									elif (oca == "viola"):
										player.colpito(20)	
									elif (oca == "pizza"):
										player.colpito(30)
				elif(direzione == 3):
					if(arrayPiumeObli.arrayPiumeUP[0].getRectPiuma().x > 1100):
						arrayPiumeObli.arrayPiumeUP[0].risettaPosizioneIniziale(pOB_up, pvOB_up)
						arrayPiumeObli.arrayPiumeUP[1].risettaPosizioneIniziale(pOB_up, pvOB_up + verti *3)
						arrayPiumeObli.arrayPiumeUP[2].risettaPosizioneIniziale(pOB_up, pvOB_up + verti *5)
						arrayPiumeObli.arrayPiumeUP[3].risettaPosizioneIniziale(pOB_up, pvOB_up + verti *7)
						arrayPiumeObli.arrayPiumeUP[4].risettaPosizioneIniziale(pOB_up, pvOB_up + verti *9)
						arrayPiumeObli.arrayPiumeUP[5].risettaPosizioneIniziale(pOB_up, pvOB_up + verti *11)
						#arrayPiumeObli.arrayPiumeUP[6].risettaPosizioneIniziale(pOB_up, pvOB_up + verti *13)
						#arrayPiumeObli.arrayPiumeUP[7].risettaPosizioneIniziale(pOB_up, pvOB_up + verti *15)
						#arrayPiumeObli.arrayPiumeUP[8].risettaPosizioneIniziale(pOB_up, pvOB_up + verti *16)
						#arrayPiumeObli.arrayPiumeUP[9].risettaPosizioneIniziale(pOB_up, pvOB_up + verti *18)
						turnoOb = turnoOb +1
						direzione = random.randint(1, 4)
					else:
						print("Ou")
						PPOB = arrayPiumeObli.attaccoObliquoUP(world, pOB, pvOB, player, velocita -4)
						if (PPOB == False and cont == 0):
							if(player.checkColpito() == False):
								effettoSonoro(volume, suonoColpo)
								cont = 1
								player.setColpito()
								if(player.flagNoDanno == False):
									if(oca == "verde"):
										player.colpito(10)
									elif (oca == "rossa"):
										player.colpito(15)
									elif (oca == "viola"):
										player.colpito(20)	
									elif (oca == "pizza"):
										player.colpito(30)
				elif (direzione == 4):
					if(arrayPiumeObli.arrayPiumeDOWN[0].getRectPiuma().x < 100):
						arrayPiumeObli.arrayPiumeDOWN[0].risettaPosizioneIniziale(pOB_down, pvOB_down)
						arrayPiumeObli.arrayPiumeDOWN[1].risettaPosizioneIniziale(pOB_down, pvOB_down + verti *3)
						arrayPiumeObli.arrayPiumeDOWN[2].risettaPosizioneIniziale(pOB_down, pvOB_down + verti *5)
						arrayPiumeObli.arrayPiumeDOWN[3].risettaPosizioneIniziale(pOB_down, pvOB_down + verti *7)
						arrayPiumeObli.arrayPiumeDOWN[4].risettaPosizioneIniziale(pOB_down, pvOB_down + verti *9)
						arrayPiumeObli.arrayPiumeDOWN[5].risettaPosizioneIniziale(pOB_down, pvOB_down + verti *11)
					#	arrayPiumeObli.arrayPiumeDOWN[6].risettaPosizioneIniziale(pOB_down, pvOB_down + verti *13)
					#	arrayPiumeObli.arrayPiumeDOWN[7].risettaPosizioneIniziale(pOB_down, pvOB_down + verti *15)
					#	arrayPiumeObli.arrayPiumeDOWN[8].risettaPosizioneIniziale(pOB_down, pvOB_down + verti *16)
					#	arrayPiumeObli.arrayPiumeDOWN[9].risettaPosizioneIniziale(pOB_down, pvOB_down + verti *18)
						turnoOb = turnoOb +1
						direzione = random.randint(1, 4)
					else:
						print("Ou")
						PPOB = arrayPiumeObli.attaccoObliquoDOWN(world, pOB, pvOB, player, velocita - 4)
						if (PPOB == False and cont == 0):
							if(player.checkColpito() == False):
								effettoSonoro(volume, suonoColpo)
								cont = 1
								player.setColpito()
								if(player.flagNoDanno == False):
									if(oca == "verde"):
										player.colpito(10)
									elif (oca == "rossa"):
										player.colpito(15)
									elif (oca == "viola"):
										player.colpito(20)
									elif (oca == "pizza"):
										player.colpito(30)
										
			if(turnoOb  == turnoObli and player.checkColpito() == False and turno  == turnoO and turnoV == turnoVer ):
				print(turnoO, turnoVer, turno, turnoV)
				time.sleep(1)
				ripeti = 1
				ripeti = False	
				
		if attaccoDaFare == 3 or attaccoDaFare == 4:		
			world.blit(pygame.image.load("Immagini_Gioco/ULTIMO_LIVELLO/facciaGrossa.png"), arrayPosizioniPizzaLaser[faiR])
			world.blit(pygame.image.load("Immagini_Gioco/ULTIMO_LIVELLO/facciaGrossa.png"), arrayPosizioniPizzaLaserV[faiR])
			tempoLaser = waitForLaser + tempoLaser
			if(tempoLaser >= 1000):
				world.blit(pygame.image.load("Immagini_Gioco/ULTIMO_LIVELLO/laseroneOrizontale.png"), (rectLaserOr.x, rectLaserOr.y))
				rectLaserOr.x = arrayPosizioneLaserOr[faiR][0]
				rectLaserOr.y = arrayPosizioneLaserOr[faiR][1]
				world.blit(pygame.image.load("Immagini_Gioco/ULTIMO_LIVELLO/laseroneAttack.png"), (rectLaserVr.x, rectLaserVr.y))
				rectLaserVr.x = arrayPosizioneLaserV[faiR][0]
				rectLaserVr.y = arrayPosizioneLaserV[faiR][1]
				raggioFatto = 1
				
			if rectLaserOr.colliderect(player.getRectPlayer()):
				player.HP = player.HP - 3
				effettoSonoro(volume, suonoColpo)
				
			if rectLaserVr.colliderect(player.getRectPlayer()):
				player.HP = player.HP - 3
				effettoSonoro(volume, suonoColpo)
			
			if raggioFatto == 1:
				turnoDopoRaggio = turnoDopoRaggio + raggioDopo
				if(turnoDopoRaggio >= 1200):
					effettoSonoro(volume, suonoLaser)
					rectLaserOr.x = -10000
					rectLaserOr.y = -10000
					rectLaserVr.x = -10000
					rectLaserVr.y = -10000
					turnoDopoRaggio = 0
					raggioFatto = 0
					tempoLaser = 0
					faiR = random.randint(0, 4)
					if faiR == vecchiaPosOr:
						riestrai = True
						while riestrai:
							faiR = random.randint(0, 4)
							if faiR != vecchiaPosOr:
								riestrai = False
					vecchiaPosOr = faiR
					turnoLas += 1
					
			if(turnoLas == laser and player.checkColpito() == False):
				print(turnoO, turnoVer, turno, turnoV)
				time.sleep(1)
				ripeti = 1
				ripeti = False
						
						
			#	if(P1 > 100 and P4 >= 325):
			#		#print("ou")
			#		print(P4)
			#		arrayPiumeObli.settingAttacco(5)
			#		PP = arrayPiumeObli.attaccoOrizzontale(world, P1, P4, player, obliquo)
			#		obliquo += 1
			#		if(obliquo % 2 == 0):
			#			pygame.display.flip()
				#	pygame.display.flip()
			#		P1 = P1 - (velocita - 7)
			#		P4 = P4 - (velocita - 7)
			#		print(str(P4) + "questo è P4 ora")
			#		
			#		if (PP == False and cont == 0):
			#			if(player.checkColpito() == False):
			#				effettoSonoro(volume, suonoColpo)
			#				cont = 1
			#				player.setColpito()
			#				player.colpito()
			#	else:
					#ristampa(world, player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player.getRectPlayer(), player.checkColpito())
			#		if(cont == 1):
			#			cont = 0
			#		turno = turno + 1
			#		P1 = 1163
			#		P4 = 890
			#		o = random.randint(-10, 10)
			#		if o == 0:
			#			o = random.randint(-10, 10)
		pygame.display.flip()
					
		
			#if(player.checkColpito()):
				#player.setLast(camminiamo)
		
			
				
			

		#print(app)
		#print(player.checkColpito())
		#ristampa(world, player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player.getRectPlayer(), player.checkColpito())	
				
				
		#pygame.display.flip()	
		#if(turno == 1):
		#	if(P1 > 100):
		#		P1 = P1 - velocita
		#	else:
		#		ristampa(world)
		#		turno = turno + 1
		#		pygame.display.flip()
		#	arrayPiume.settingAttacco(o)
		#	arrayPiume.attaccoOrizzontale(world, P1)	
				
		#pygame.display.flip()
		#attaccoOrizzontale(world, P1, P2, verti)
		#attaccoVerticale(world, P3, P4, verti)	
		#if(P4 <= 325):
			#P3 = 190
		#	P4 = 890
	#	else:
			#P3 = P3 + 15
		#	P4 = P4 - 8
		##attaccoVerticale(world, P3, P4, verti)
		#pygame.display.flip()
	
	
#main()
		


