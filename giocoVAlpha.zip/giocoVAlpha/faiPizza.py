
import pygame
import time
import random



class Pizza():
	
	def __init__(self, pathPizzaDaFare):
		self.pathPizza = pathPizzaDaFare
		self.posizioni = []
		self.giaPoz = []
		self.xPomodoro = 0
		self.xMozzarella = 0
		self.yPomodoro = 0
		self.yMozz = 0
		self.xImpasto = 475
		self.yImpasto = 510
		self.xFun = 0
		self.yFun = 0
		self.xProsc = 0
		self.yProsc = 0
		self.xSal = 0
		self.ySal = 0
		self.xcar = 0
		self.ycar = 0
		self.font = pygame.font.Font('Immagini_Gioco/DialoghiNPC/fontDialoghi/vito/vitoFont.ttf', 52, bold=True)
		
#PATH ROBA SALAME
# surf_prosciutto= pygame.image.load('Immagini_Gioco/Immagini_Livello/salame2.png') /  surf_pizzaVuota=pygame.image.load('Immagini_Gioco/pizze/pizzaSalame.png')
	#fprintf('%.2f', pi)	
		
		
	def makeAttaccoPizza(self, world):
		
		self.ristampaMake(world)
		
		if(self.pathPizza == "Immagini_Gioco/Immagini_Livello/pizzaMargherita.png"):
			
			self.posizioni = [(150, 650), (950, 700)] 
			
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/impasto.png')
			rect_pizzaVuota = surf_pizzaVuota.get_rect()
			rect_pizzaVuota.move_ip(self.xImpasto, self.yImpasto)
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
				
			surf_pomodoro=pygame.image.load('Immagini_Gioco/Immagini_Livello/pomodoro.png')
			rect_pomodoro = surf_pomodoro.get_rect()
			poz = random.randint(0, 1)
			self.giaPoz.append(poz)
			self.xPomodoro = self.posizioni[poz][0]
			self.yPomodoro = self.posizioni[poz][1]
			rect_pomodoro.move_ip(self.xPomodoro, self.yPomodoro) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
			world.blit(surf_pomodoro, (self.xPomodoro, self.yPomodoro))
			
			surf_mozzarella=pygame.image.load('Immagini_Gioco/Immagini_Livello/mozzarella.png')
			rect_mozzarella = surf_mozzarella.get_rect()
			poz = random.randint(0, 1)
			if poz in self.giaPoz:
				controllo = True
				while controllo:
					poz = random.randint(0, 1)
					if (poz in self.giaPoz):
						print("nope")
					else:
						self.giaPoz.append(poz)
						controllo = False
			else:
				self.giaPoz.append(poz)
			self.xMozz = self.posizioni[poz][0]
			self.yMozz = self.posizioni[poz][1]
			rect_mozzarella.move_ip(self.xMozz, self.yMozz)
			world.blit(surf_mozzarella, (self.xMozz,self.yMozz))
			
			pygame.display.flip()
			
			dragPomodoro = False
			dragMozzarella = False
			eliminaPomodoro = False
			eliminaMozzarella = False
			ifYouHaveDrag = False
			flagOrdineIngredienti = 0
			
			clock2 = pygame.time.Clock()
			text = ""
			tempoRimasto = 0
			
			ripeti = True
			
			while ripeti:
				tempoPizza = clock2.tick()
				for event in pygame.event.get():
					if event.type == pygame.QUIT:
						pygame.quit()
						sys.exit()
						
					if event.type == pygame.MOUSEBUTTONDOWN:
						click = event.pos
						
						if rect_pomodoro.collidepoint(click) and event.button == 1: 
							dragPomodoro = True
							mouse_xPom, mouse_yPom = event.pos
							offset_xPom = rect_pomodoro.x - mouse_xPom
							offset_yPom = rect_pomodoro.y - mouse_yPom
							
						if rect_mozzarella.collidepoint(click) and event.button == 1: 
							dragMozzarella = True
							mouse_xMoz, mouse_yMoz = event.pos
							offset_xMoz = rect_mozzarella.x - mouse_xMoz
							offset_yMoz = rect_mozzarella.y- mouse_yMoz
							
					if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
					
						if rect_pomodoro.colliderect(rect_pizzaVuota):
							eliminaPomodoro = True
							surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/marinara.png')
							world.blit(surf_pizzaVuota, (self.xImpasto,self.yImpasto))
							flagOrdineIngredienti=1
							
						if dragPomodoro:
							#print(eliminaPomodoro)
							dragPomodoro = False
							#print(xPom, yPom)
							rect_pomodoro.x = self.xPomodoro
							rect_pomodoro.y = self.yPomodoro
							#self.ristampaMargherita(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, tempoRimasto)					
							
						if rect_mozzarella.colliderect(rect_pizzaVuota):
							if(flagOrdineIngredienti == 1):
								eliminaMozzarella = True
								surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/pizzaMargherita.png')
								world.blit(surf_pizzaVuota, (self.xImpasto,self.yImpasto))
								flagOrdineIngredienti=2	
							else:
								time.sleep(1)
								return 99
							
						if dragMozzarella:
							#print(eliminaPomodoro)
							dragMozzarella = False
							#print(xPom, yPom)
							rect_mozzarella.x = self.xMozz
							rect_mozzarella.y = self.yMozz
							#self.ristampaMargherita(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, tempoRimasto)	
						pygame.display.flip()			
											
							
					if event.type == pygame.MOUSEMOTION:
						if dragPomodoro: 
							#print("ciao")
							mouse_xPom, mouse_yPom = event.pos
							rect_pomodoro.x = mouse_xPom + offset_xPom
							rect_pomodoro.y = mouse_yPom + offset_yPom
							ifYouHaveDrag = True
		                 
						if dragMozzarella:
							#print(flag)
							mouse_xMoz, mouse_yMoz = event.pos
							rect_mozzarella.x = mouse_xMoz + offset_xMoz
							rect_mozzarella.y = mouse_yMoz + offset_yMoz
							ifYouHaveDrag = True					
					
					
				print(ifYouHaveDrag)				
				#if ifYouHaveDrag:							
					#self.ristampaMargherita(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, tempoRimasto)			
													
					#print("A")	
				ifYouHaveDrag = False
				if(eliminaPomodoro == False):
					#print("dad")
					world.blit(surf_pomodoro, rect_pomodoro)
				if(eliminaMozzarella == False):
					world.blit(surf_mozzarella, rect_mozzarella)

				pygame.display.flip()		
				if(flagOrdineIngredienti == 2):
					self.posizioni = []
					self.giaPoz = []
					self.xPomodoro = 0
					self.xMozzarella = 0
					self.yPomodoro = 0
					self.yMozz = 0
					self.xImpasto = 475
					self.yImpasto = 510
					time.sleep(1)
					ripeti = False	
				tempoRimasto = tempoPizza + tempoRimasto
				if(tempoRimasto > 3000):
					time.sleep(1)
					return 99
					#if(tempoRimasto == 500 or tempoRimasto == 1000 or tempoRimasto == 1500 or tempoRimasto == 2000 or tempoRimasto == 2500 or tempoRimasto == 3000):
				#self.ristampaMake(world)
				self.ristampaMargherita(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, tempoRimasto)		
						
			
		if(self.pathPizza == 'Immagini_Gioco/pizze/pizzaProsciutto.png'):	
			self.posizioni = [(150, 550), (950, 700), (150, 700)] 
			
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/impasto.png')
			rect_pizzaVuota = surf_pizzaVuota.get_rect()
			rect_pizzaVuota.move_ip(self.xImpasto, self.yImpasto)
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
					
			surf_pomodoro=pygame.image.load('Immagini_Gioco/Immagini_Livello/pomodoro.png')
			rect_pomodoro = surf_pomodoro.get_rect()
			poz = random.randint(0, 2)
			self.giaPoz.append(poz)
			self.xPomodoro = self.posizioni[poz][0]
			self.yPomodoro = self.posizioni[poz][1]
			rect_pomodoro.move_ip(self.xPomodoro, self.yPomodoro) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
			world.blit(surf_pomodoro, (self.xPomodoro, self.yPomodoro))
			
			surf_mozzarella=pygame.image.load('Immagini_Gioco/Immagini_Livello/mozzarella.png')
			rect_mozzarella = surf_mozzarella.get_rect()
			poz = random.randint(0, 2)
			if poz in self.giaPoz:
				controllo = True
				while controllo:
					poz = random.randint(0, 2)
					if (poz in self.giaPoz):
						print("nope")
					else:
						self.giaPoz.append(poz)
						controllo = False
			else:
				self.giaPoz.append(poz)
			self.xMozz = self.posizioni[poz][0]
			self.yMozz = self.posizioni[poz][1]
			rect_mozzarella.move_ip(self.xMozz, self.yMozz)
			world.blit(surf_mozzarella, (self.xMozz,self.yMozz))
			
			self.giaPoz.append(poz)
				
			surf_prosciutto= pygame.image.load('Immagini_Gioco/ingredienti/prosciuttone.png')
			rect_prosciutto = surf_prosciutto.get_rect()
			poz = random.randint(0, 2)
			if poz in self.giaPoz:
				controllo = True
				print(poz)
				while controllo:
					poz = random.randint(0, 2)
					if (poz in self.giaPoz):
						print("nope")
					else:
						self.giaPoz.append(poz)
						controllo = False
			else:
				self.giaPoz.append(poz)
			self.xProsc = self.posizioni[poz][0]
			self.yProsc = self.posizioni[poz][1]
			rect_prosciutto.move_ip(self.xProsc, self.yProsc)
			world.blit(surf_prosciutto, (self.xProsc, self.yProsc))
				
			pygame.display.flip()
				
			dragPomodoro = False
			dragMozzarella = False
			dragProsciutto = False
			eliminaProsciutto = False
			eliminaPomodoro = False
			eliminaMozzarella = False
			ifYouHaveDrag = False
			flagOrdineIngredienti = 0
			clock2 = pygame.time.Clock()
			text = ""
			tempoRimasto = 0
				
			ripeti = True
				
			while ripeti:
				tempoPizza = clock2.tick()
				for event in pygame.event.get():
					if event.type == pygame.QUIT:
						pygame.quit()
						sys.exit()
							
					if event.type == pygame.MOUSEBUTTONDOWN:
						click = event.pos
							
						if rect_pomodoro.collidepoint(click) and event.button == 1: 
							dragPomodoro = True
							mouse_xPom, mouse_yPom = event.pos
							offset_xPom = rect_pomodoro.x - mouse_xPom
							offset_yPom = rect_pomodoro.y - mouse_yPom
								
						if rect_mozzarella.collidepoint(click) and event.button == 1: 
							dragMozzarella = True
							mouse_xMoz, mouse_yMoz = event.pos
							offset_xMoz = rect_mozzarella.x - mouse_xMoz
							offset_yMoz = rect_mozzarella.y- mouse_yMoz
								
						if rect_prosciutto.collidepoint(click) and event.button == 1: 
							dragProsciutto = True
							mouse_xPro, mouse_yPro = event.pos
							offset_xPro = rect_prosciutto.x - mouse_xPro
							offset_yPro = rect_prosciutto.y- mouse_yPro
								
					if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
						
						if rect_pomodoro.colliderect(rect_pizzaVuota):
							eliminaPomodoro = True
							surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/marinara.png')
							world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
							flagOrdineIngredienti=1
								
						if dragPomodoro:
							#print(eliminaPomodoro)
							dragPomodoro = False
							#print(xPom, yPom)
							rect_pomodoro.x = self.xPomodoro
							rect_pomodoro.y = self.yPomodoro
							#self.ristampaProsciutto(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragProsciutto, eliminaProsciutto)				
								
						if rect_mozzarella.colliderect(rect_pizzaVuota):
							if flagOrdineIngredienti == 1:
								eliminaMozzarella = True
								surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/pizzaMargherita.png')
								world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
								flagOrdineIngredienti=2	
							else:
								time.sleep(1)
								return 99
							
								
						if dragMozzarella:
						#	print(eliminaPomodoro)
							dragMozzarella = False
							#print(xPom, yPom)
							rect_mozzarella.x = self.xMozz
							rect_mozzarella.y = self.yMozz
						#	self.ristampaProsciutto(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragProsciutto, eliminaProsciutto)	
					#	pygame.display.flip()
							
						if rect_prosciutto.colliderect(rect_pizzaVuota):
							if ( flagOrdineIngredienti == 2):
								eliminaProsciutto = True
								surf_pizzaVuota=pygame.image.load('Immagini_Gioco/pizze/pizzaProsciutto.png')
								world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
								flagOrdineIngredienti=3	
							else:
								flagOrdineIngredienti = 0
								eliminaSalame = False
								eliminaMozzarella = False 
								eliminaPomodoro = False
								time.sleep(1)
								return 99
						
								
						if dragProsciutto:
							print(eliminaPomodoro)
							dragProsciutto = False
							#print(xPom, yPom)
							rect_prosciutto.x = self.xProsc
							rect_prosciutto.y = self.yProsc
						#	self.ristampaProsciutto(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragProsciutto, eliminaProsciutto)	
						pygame.display.flip()				
												
								
					if event.type == pygame.MOUSEMOTION:
						if dragPomodoro: 
							print("ciao")
							mouse_xPom, mouse_yPom = event.pos
							rect_pomodoro.x = mouse_xPom + offset_xPom
							rect_pomodoro.y = mouse_yPom + offset_yPom
							ifYouHaveDrag = True
				             
						if dragMozzarella:
								#print(flag)
							mouse_xMoz, mouse_yMoz = event.pos
							rect_mozzarella.x = mouse_xMoz + offset_xMoz
							rect_mozzarella.y = mouse_yMoz + offset_yMoz
							ifYouHaveDrag = True	
										
						if dragProsciutto:
								#print(flag)
							mouse_xPro, mouse_yPro = event.pos
							rect_prosciutto.x = mouse_xPro + offset_xPro
							rect_prosciutto.y = mouse_yPro + offset_yPro
							ifYouHaveDrag = True			
						
						
				print(ifYouHaveDrag)				
				if ifYouHaveDrag:							
					#self.ristampaProsciutto(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragProsciutto, eliminaProsciutto)			
														
					print("A")	
				ifYouHaveDrag = False
				if(eliminaPomodoro == False):
					#print("dad")
					world.blit(surf_pomodoro, rect_pomodoro)
				if(eliminaMozzarella == False):
					world.blit(surf_mozzarella, rect_mozzarella)
				if(eliminaProsciutto == False):
					world.blit(surf_prosciutto, rect_prosciutto)

				pygame.display.flip()		
				if(flagOrdineIngredienti == 3):
					time.sleep(1)
					self.posizioni = []
					self.giaPoz = []
					self.xPomodoro = 0
					self.xMozzarella = 0
					self.yPomodoro = 0
					self.yMozz = 0
					self.xProsc = 0
					self.yProsc = 0
					self.xImpasto = 475
					self.yImpasto = 510
					ripeti = False	
					
				tempoRimasto = tempoPizza + tempoRimasto
				if(tempoRimasto > 3000):
					time.sleep(1)
					return 99
				
				self.ristampaProsciutto(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragProsciutto, eliminaProsciutto, tempoRimasto)					
			
		if(self.pathPizza == 'Immagini_Gioco/pizze/pizzaSalame.png'):	
			self.posizioni = [(150, 550), (950, 700), (150, 700)] 
			
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/impasto.png')
			rect_pizzaVuota = surf_pizzaVuota.get_rect()
			rect_pizzaVuota.move_ip(self.xImpasto, self.yImpasto)
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
					
			surf_pomodoro=pygame.image.load('Immagini_Gioco/Immagini_Livello/pomodoro.png')
			rect_pomodoro = surf_pomodoro.get_rect()
			poz = random.randint(0, 2)
			self.giaPoz.append(poz)
			self.xPomodoro = self.posizioni[poz][0]
			self.yPomodoro = self.posizioni[poz][1]
			rect_pomodoro.move_ip(self.xPomodoro, self.yPomodoro) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
			world.blit(surf_pomodoro, (self.xPomodoro, self.yPomodoro))
			
			surf_mozzarella=pygame.image.load('Immagini_Gioco/Immagini_Livello/mozzarella.png')
			rect_mozzarella = surf_mozzarella.get_rect()
			poz = random.randint(0, 2)
			if poz in self.giaPoz:
				controllo = True
				while controllo:
					poz = random.randint(0, 2)
					if (poz in self.giaPoz):
						print("nope")
					else:
						self.giaPoz.append(poz)
						controllo = False
			else:
				self.giaPoz.append(poz)
			self.xMozz = self.posizioni[poz][0]
			self.yMozz = self.posizioni[poz][1]
			rect_mozzarella.move_ip(self.xMozz, self.yMozz)
			world.blit(surf_mozzarella, (self.xMozz,self.yMozz))
			
			self.giaPoz.append(poz)
				
			surf_salame= pygame.image.load('Immagini_Gioco/Immagini_Livello/salame2.png')
			rect_salame = surf_salame.get_rect()
			poz = random.randint(0, 2)
			if poz in self.giaPoz:
				controllo = True
				print(poz)
				while controllo:
					poz = random.randint(0, 2)
					if (poz in self.giaPoz):
						print("nope")
					else:
						self.giaPoz.append(poz)
						controllo = False
			else:
				self.giaPoz.append(poz)
			self.xSal = self.posizioni[poz][0]
			self.ySal = self.posizioni[poz][1]
			rect_salame.move_ip(self.xSal, self.ySal)
			world.blit(surf_salame, (self.xSal, self.ySal))
				
			pygame.display.flip()
				
			dragPomodoro = False
			dragMozzarella = False
			dragSalame = False
			eliminaSalame = False
			eliminaPomodoro = False
			eliminaMozzarella = False
			ifYouHaveDrag = False
			flagOrdineIngredienti = 0
			clock2 = pygame.time.Clock()
			text = ""
			tempoRimasto = 0
				
			ripeti = True
				
			while ripeti:
				tempoPizza = clock2.tick()
				for event in pygame.event.get():
					if event.type == pygame.QUIT:
						pygame.quit()
						sys.exit()
							
					if event.type == pygame.MOUSEBUTTONDOWN:
						click = event.pos
							
						if rect_pomodoro.collidepoint(click) and event.button == 1: 
							dragPomodoro = True
							mouse_xPom, mouse_yPom = event.pos
							offset_xPom = rect_pomodoro.x - mouse_xPom
							offset_yPom = rect_pomodoro.y - mouse_yPom
								
						if rect_mozzarella.collidepoint(click) and event.button == 1: 
							dragMozzarella = True
							mouse_xMoz, mouse_yMoz = event.pos
							offset_xMoz = rect_mozzarella.x - mouse_xMoz
							offset_yMoz = rect_mozzarella.y- mouse_yMoz
								
						if rect_salame.collidepoint(click) and event.button == 1: 
							dragSalame = True
							mouse_xSal, mouse_ySal = event.pos
							offset_xSal = rect_salame.x - mouse_xSal
							offset_ySal = rect_salame.y- mouse_ySal
								
					if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
						
						if rect_pomodoro.colliderect(rect_pizzaVuota):
							eliminaPomodoro = True
							surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/marinara.png')
							world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
							flagOrdineIngredienti=1
								
						if dragPomodoro:
							#print(eliminaPomodoro)
							dragPomodoro = False
							#print(xPom, yPom)
							rect_pomodoro.x = self.xPomodoro
							rect_pomodoro.y = self.yPomodoro
							#self.ristampaSalame(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame)				
								
						if rect_mozzarella.colliderect(rect_pizzaVuota):
							if flagOrdineIngredienti == 1:
								eliminaMozzarella = True
								surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/pizzaMargherita.png')
								world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
								flagOrdineIngredienti=2	
							else:
								time.sleep(1)
								return 99
							
								
						if dragMozzarella:
						#	print(eliminaPomodoro)
							dragMozzarella = False
							#print(xPom, yPom)
							rect_mozzarella.x = self.xMozz
							rect_mozzarella.y = self.yMozz
							#self.ristampaSalame(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame)	
					#	pygame.display.flip()
							
						if rect_salame.colliderect(rect_pizzaVuota):
							if ( flagOrdineIngredienti == 2):
								eliminaSalame = True
								surf_pizzaVuota=pygame.image.load('Immagini_Gioco/pizze/pizzaSalame.png')
								world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
								flagOrdineIngredienti=3	
							else:
								flagOrdineIngredienti = 0
								eliminaSalame = False
								eliminaMozzarella = False 
								eliminaPomodoro = False
								time.sleep(1)
								return 99
						
								
						if dragSalame:
							dragSalame = False
							#print(xPom, yPom)
							rect_salame.x = self.xSal
							rect_salame.y = self.ySal
							#self.ristampaSalame(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame)	
						pygame.display.flip()				
												
								
					if event.type == pygame.MOUSEMOTION:
						if dragPomodoro: 
							print("ciao")
							mouse_xPom, mouse_yPom = event.pos
							rect_pomodoro.x = mouse_xPom + offset_xPom
							rect_pomodoro.y = mouse_yPom + offset_yPom
							ifYouHaveDrag = True
				             
						if dragMozzarella:
								#print(flag)
							mouse_xMoz, mouse_yMoz = event.pos
							rect_mozzarella.x = mouse_xMoz + offset_xMoz
							rect_mozzarella.y = mouse_yMoz + offset_yMoz
							ifYouHaveDrag = True	
										
						if dragSalame:
								#print(flag)
							mouse_xSal, mouse_ySal = event.pos
							rect_salame.x = mouse_xSal + offset_xSal
							rect_salame.y = mouse_ySal + offset_ySal
							ifYouHaveDrag = True			
						
						
				print(ifYouHaveDrag)				
				if ifYouHaveDrag:							
					#self.ristampaSalame(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame)			
														
					print("A")	
				ifYouHaveDrag = False
				if(eliminaPomodoro == False):
					#print("dad")
					world.blit(surf_pomodoro, rect_pomodoro)
				if(eliminaMozzarella == False):
					world.blit(surf_mozzarella, rect_mozzarella)
				if(eliminaSalame == False):
					world.blit(surf_salame, rect_salame)

				pygame.display.flip()		
				if(flagOrdineIngredienti == 3):
					time.sleep(1)
					self.posizioni = []
					self.giaPoz = []
					self.xPomodoro = 0
					self.xMozzarella = 0
					self.yPomodoro = 0
					self.yMozz = 0
					self.xSal = 0
					self.ySal = 0
					self.xImpasto = 475
					self.yImpasto = 510
					ripeti = False	
					#('Immagini_Gioco/ingredienti/salsiccia.png')
					#'Immagini_Gioco/pizze/pizzaSalsiccia.png'
				tempoRimasto = tempoPizza + tempoRimasto
				if(tempoRimasto > 3000):
					time.sleep(1)
					return 99
				self.ristampaSalame(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame, tempoRimasto)		
		if(self.pathPizza == 'Immagini_Gioco/pizze/pizzaSalsiccia.png'):	
		
			self.posizioni = [(150, 550), (950, 700), (150, 700)] 
			
			
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/impasto.png')
			rect_pizzaVuota = surf_pizzaVuota.get_rect()
			rect_pizzaVuota.move_ip(self.xImpasto, self.yImpasto)
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
					
			surf_pomodoro=pygame.image.load('Immagini_Gioco/Immagini_Livello/pomodoro.png')
			rect_pomodoro = surf_pomodoro.get_rect()
			poz = random.randint(0, 2)
			self.giaPoz.append(poz)
			self.xPomodoro = self.posizioni[poz][0]
			self.yPomodoro = self.posizioni[poz][1]
			rect_pomodoro.move_ip(self.xPomodoro, self.yPomodoro) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
			world.blit(surf_pomodoro, (self.xPomodoro, self.yPomodoro))
			
			surf_mozzarella=pygame.image.load('Immagini_Gioco/Immagini_Livello/mozzarella.png')
			rect_mozzarella = surf_mozzarella.get_rect()
			poz = random.randint(0, 2)
			if poz in self.giaPoz:
				controllo = True
				while controllo:
					poz = random.randint(0, 2)
					if (poz in self.giaPoz):
						print("nope")
					else:
						self.giaPoz.append(poz)
						controllo = False
			else:
				self.giaPoz.append(poz)
			self.xMozz = self.posizioni[poz][0]
			self.yMozz = self.posizioni[poz][1]
			rect_mozzarella.move_ip(self.xMozz, self.yMozz)
			world.blit(surf_mozzarella, (self.xMozz,self.yMozz))
			
			self.giaPoz.append(poz)
				
			surf_salame= pygame.image.load('Immagini_Gioco/ingredienti/salsiccia.png')
			rect_salame = surf_salame.get_rect()
			poz = random.randint(0, 2)
			if poz in self.giaPoz:
				controllo = True
				print(poz)
				while controllo:
					poz = random.randint(0, 2)
					if (poz in self.giaPoz):
						print("nope")
					else:
						self.giaPoz.append(poz)
						controllo = False
			else:
				self.giaPoz.append(poz)
			self.xSal = self.posizioni[poz][0]
			self.ySal = self.posizioni[poz][1]
			rect_salame.move_ip(self.xSal, self.ySal)
			world.blit(surf_salame, (self.xSal, self.ySal))
				
			pygame.display.flip()
				
			dragPomodoro = False
			dragMozzarella = False
			dragSalame = False
			eliminaSalame = False
			eliminaPomodoro = False
			eliminaMozzarella = False
			ifYouHaveDrag = False
			flagOrdineIngredienti = 0
			clock2 = pygame.time.Clock()
			text = ""
			tempoRimasto = 0
				
			ripeti = True
				
			while ripeti:
				tempoPizza = clock2.tick()
				for event in pygame.event.get():
					if event.type == pygame.QUIT:
						pygame.quit()
						sys.exit()
							
					if event.type == pygame.MOUSEBUTTONDOWN:
						click = event.pos
							
						if rect_pomodoro.collidepoint(click) and event.button == 1: 
							dragPomodoro = True
							mouse_xPom, mouse_yPom = event.pos
							offset_xPom = rect_pomodoro.x - mouse_xPom
							offset_yPom = rect_pomodoro.y - mouse_yPom
								
						if rect_mozzarella.collidepoint(click) and event.button == 1: 
							dragMozzarella = True
							mouse_xMoz, mouse_yMoz = event.pos
							offset_xMoz = rect_mozzarella.x - mouse_xMoz
							offset_yMoz = rect_mozzarella.y- mouse_yMoz
								
						if rect_salame.collidepoint(click) and event.button == 1: 
							dragSalame = True
							mouse_xSal, mouse_ySal = event.pos
							offset_xSal = rect_salame.x - mouse_xSal
							offset_ySal = rect_salame.y- mouse_ySal
								
					if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
						
						if rect_pomodoro.colliderect(rect_pizzaVuota):
							eliminaPomodoro = True
							surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/marinara.png')
							world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
							flagOrdineIngredienti=1
								
						if dragPomodoro:
							#print(eliminaPomodoro)
							dragPomodoro = False
							#print(xPom, yPom)
							rect_pomodoro.x = self.xPomodoro
							rect_pomodoro.y = self.yPomodoro
							#self.ristampaSalsiccia(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame)				
								
						if rect_mozzarella.colliderect(rect_pizzaVuota):
							if flagOrdineIngredienti == 1:
								eliminaMozzarella = True
								surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/pizzaMargherita.png')
								world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
								flagOrdineIngredienti=2	
							else:
								time.sleep(1)
								return 99
							
								
						if dragMozzarella:
						#	print(eliminaPomodoro)
							dragMozzarella = False
							#print(xPom, yPom)
							rect_mozzarella.x = self.xMozz
							rect_mozzarella.y = self.yMozz
							#self.ristampaSalsiccia(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame)	
					#	pygame.display.flip()
							
						if rect_salame.colliderect(rect_pizzaVuota):
							if ( flagOrdineIngredienti == 2):
								eliminaSalame = True
								surf_pizzaVuota=pygame.image.load('Immagini_Gioco/pizze/pizzaSalsiccia.png')
								world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
								flagOrdineIngredienti=3	
							else:
								flagOrdineIngredienti = 0
								eliminaSalame = False
								eliminaMozzarella = False 
								eliminaPomodoro = False
								time.sleep(1)
								return 99
						
								
						if dragSalame:
							dragSalame = False
							#print(xPom, yPom)
							rect_salame.x = self.xSal
							rect_salame.y = self.ySal
						#	self.ristampaSalsiccia(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame)	
						pygame.display.flip()				
												
								
					if event.type == pygame.MOUSEMOTION:
						if dragPomodoro: 
							print("ciao")
							mouse_xPom, mouse_yPom = event.pos
							rect_pomodoro.x = mouse_xPom + offset_xPom
							rect_pomodoro.y = mouse_yPom + offset_yPom
							ifYouHaveDrag = True
				             
						if dragMozzarella:
								#print(flag)
							mouse_xMoz, mouse_yMoz = event.pos
							rect_mozzarella.x = mouse_xMoz + offset_xMoz
							rect_mozzarella.y = mouse_yMoz + offset_yMoz
							ifYouHaveDrag = True	
										
						if dragSalame:
								#print(flag)
							mouse_xSal, mouse_ySal = event.pos
							rect_salame.x = mouse_xSal + offset_xSal
							rect_salame.y = mouse_ySal + offset_ySal
							ifYouHaveDrag = True			
						
						
				print(ifYouHaveDrag)				
				if ifYouHaveDrag:							
					#self.ristampaSalsiccia(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame)			
														
					print("A")	
				ifYouHaveDrag = False
				if(eliminaPomodoro == False):
					#print("dad")
					world.blit(surf_pomodoro, rect_pomodoro)
				if(eliminaMozzarella == False):
					world.blit(surf_mozzarella, rect_mozzarella)
				if(eliminaSalame == False):
					world.blit(surf_salame, rect_salame)

				pygame.display.flip()		
				if(flagOrdineIngredienti == 3):
					time.sleep(1)
					self.posizioni = []
					self.giaPoz = []
					self.xPomodoro = 0
					self.xMozzarella = 0
					self.yPomodoro = 0
					self.yMozz = 0
					self.xSal = 0
					self.ySal = 0
					self.xImpasto = 475
					self.yImpasto = 510
					ripeti = False
					
				tempoRimasto = tempoPizza + tempoRimasto
				if(tempoRimasto > 3000):
					time.sleep(1)
					return 99
				self.ristampaSalsiccia(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame, tempoRimasto)	
	
		if self.pathPizza == 'Immagini_Gioco/pizze/pizzaAmericana.png':
					
			self.posizioni = [(150, 550), (950, 700), (150, 700)] 
			
			
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/impasto.png')
			rect_pizzaVuota = surf_pizzaVuota.get_rect()
			rect_pizzaVuota.move_ip(self.xImpasto, self.yImpasto)
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
					
			surf_pomodoro=pygame.image.load('Immagini_Gioco/Immagini_Livello/pomodoro.png')
			rect_pomodoro = surf_pomodoro.get_rect()
			poz = random.randint(0, 2)
			self.giaPoz.append(poz)
			self.xPomodoro = self.posizioni[poz][0]
			self.yPomodoro = self.posizioni[poz][1]
			rect_pomodoro.move_ip(self.xPomodoro, self.yPomodoro) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
			world.blit(surf_pomodoro, (self.xPomodoro, self.yPomodoro))
			
			surf_mozzarella=pygame.image.load('Immagini_Gioco/Immagini_Livello/mozzarella.png')
			rect_mozzarella = surf_mozzarella.get_rect()
			poz = random.randint(0, 2)
			if poz in self.giaPoz:
				controllo = True
				while controllo:
					poz = random.randint(0, 2)
					if (poz in self.giaPoz):
						print("nope")
					else:
						self.giaPoz.append(poz)
						controllo = False
			else:
				self.giaPoz.append(poz)
			self.xMozz = self.posizioni[poz][0]
			self.yMozz = self.posizioni[poz][1]
			rect_mozzarella.move_ip(self.xMozz, self.yMozz)
			world.blit(surf_mozzarella, (self.xMozz,self.yMozz))
			
			self.giaPoz.append(poz)
				
			surf_salame= pygame.image.load('Immagini_Gioco/ingredienti/patata.png')
			rect_salame = surf_salame.get_rect()
			poz = random.randint(0, 2)
			if poz in self.giaPoz:
				controllo = True
				print(poz)
				while controllo:
					poz = random.randint(0, 2)
					if (poz in self.giaPoz):
						print("nope")
					else:
						self.giaPoz.append(poz)
						controllo = False
			else:
				self.giaPoz.append(poz)
			self.xSal = self.posizioni[poz][0]
			self.ySal = self.posizioni[poz][1]
			rect_salame.move_ip(self.xSal, self.ySal)
			world.blit(surf_salame, (self.xSal, self.ySal))
				
			pygame.display.flip()
				
			dragPomodoro = False
			dragMozzarella = False
			dragSalame = False
			eliminaSalame = False
			eliminaPomodoro = False
			eliminaMozzarella = False
			ifYouHaveDrag = False
			flagOrdineIngredienti = 0
			clock2 = pygame.time.Clock()
			text = ""
			tempoRimasto = 0

				
			ripeti = True
				
			while ripeti:
				tempoPizza = clock2.tick()
				for event in pygame.event.get():
					if event.type == pygame.QUIT:
						pygame.quit()
						sys.exit()
							
					if event.type == pygame.MOUSEBUTTONDOWN:
						click = event.pos
							
						if rect_pomodoro.collidepoint(click) and event.button == 1: 
							dragPomodoro = True
							mouse_xPom, mouse_yPom = event.pos
							offset_xPom = rect_pomodoro.x - mouse_xPom
							offset_yPom = rect_pomodoro.y - mouse_yPom
								
						if rect_mozzarella.collidepoint(click) and event.button == 1: 
							dragMozzarella = True
							mouse_xMoz, mouse_yMoz = event.pos
							offset_xMoz = rect_mozzarella.x - mouse_xMoz
							offset_yMoz = rect_mozzarella.y- mouse_yMoz
								
						if rect_salame.collidepoint(click) and event.button == 1: 
							dragSalame = True
							mouse_xSal, mouse_ySal = event.pos
							offset_xSal = rect_salame.x - mouse_xSal
							offset_ySal = rect_salame.y- mouse_ySal
								
					if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
						
						if rect_pomodoro.colliderect(rect_pizzaVuota):
							eliminaPomodoro = True
							surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/marinara.png')
							world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
							flagOrdineIngredienti=1
								
						if dragPomodoro:
							#print(eliminaPomodoro)
							dragPomodoro = False
							#print(xPom, yPom)
							rect_pomodoro.x = self.xPomodoro
							rect_pomodoro.y = self.yPomodoro
							#self.ristampaPatata(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame)				
								
						if rect_mozzarella.colliderect(rect_pizzaVuota):
							if flagOrdineIngredienti == 1:
								eliminaMozzarella = True
								surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/pizzaMargherita.png')
								world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
								flagOrdineIngredienti=2	
							else:
								time.sleep(1)
								return 99
							
								
						if dragMozzarella:
						#	print(eliminaPomodoro)
							dragMozzarella = False
							#print(xPom, yPom)
							rect_mozzarella.x = self.xMozz
							rect_mozzarella.y = self.yMozz
							#self.ristampaPatata(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame)	
					#	pygame.display.flip()
							
						if rect_salame.colliderect(rect_pizzaVuota):
							if ( flagOrdineIngredienti == 2):
								eliminaSalame = True
								surf_pizzaVuota=pygame.image.load('Immagini_Gioco/pizze/pizzaAmericana.png')
								world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
								flagOrdineIngredienti=3	
							else:
								flagOrdineIngredienti = 0
								eliminaSalame = False
								eliminaMozzarella = False 
								eliminaPomodoro = False
								time.sleep(1)
								return 99
						
								
						if dragSalame:
							dragSalame = False
							#print(xPom, yPom)
							rect_salame.x = self.xSal
							rect_salame.y = self.ySal
							#self.ristampaPatata(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame)	
						pygame.display.flip()				
												
								
					if event.type == pygame.MOUSEMOTION:
						if dragPomodoro: 
							print("ciao")
							mouse_xPom, mouse_yPom = event.pos
							rect_pomodoro.x = mouse_xPom + offset_xPom
							rect_pomodoro.y = mouse_yPom + offset_yPom
							ifYouHaveDrag = True
				             
						if dragMozzarella:
								#print(flag)
							mouse_xMoz, mouse_yMoz = event.pos
							rect_mozzarella.x = mouse_xMoz + offset_xMoz
							rect_mozzarella.y = mouse_yMoz + offset_yMoz
							ifYouHaveDrag = True	
										
						if dragSalame:
								#print(flag)
							mouse_xSal, mouse_ySal = event.pos
							rect_salame.x = mouse_xSal + offset_xSal
							rect_salame.y = mouse_ySal + offset_ySal
							ifYouHaveDrag = True			
						
						
				print(ifYouHaveDrag)				
				if ifYouHaveDrag:							
					#self.ristampaPatata(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame)			
														
					print("A")	
				ifYouHaveDrag = False
				if(eliminaPomodoro == False):
					#print("dad")
					world.blit(surf_pomodoro, rect_pomodoro)
				if(eliminaMozzarella == False):
					world.blit(surf_mozzarella, rect_mozzarella)
				if(eliminaSalame == False):
					world.blit(surf_salame, rect_salame)

				pygame.display.flip()		
				if(flagOrdineIngredienti == 3):
					time.sleep(1)
					self.posizioni = []
					self.giaPoz = []
					self.xPomodoro = 0
					self.xMozzarella = 0
					self.yPomodoro = 0
					self.yMozz = 0
					self.xSal = 0
					self.ySal = 0
					self.xImpasto = 475
					self.yImpasto = 510
					ripeti = False	
				tempoRimasto = tempoPizza + tempoRimasto
				if(tempoRimasto > 3000):
					time.sleep(1)
					return 99
				self.ristampaPatata(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame, tempoRimasto)
		if self.pathPizza == 'Immagini_Gioco/pizze/pizzaSalsiccia_Funghi.png':
		
			self.posizioni = [(150, 550), (950, 700), (150, 700), (950, 550)] 
			
			
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/impasto.png')
			rect_pizzaVuota = surf_pizzaVuota.get_rect()
			rect_pizzaVuota.move_ip(self.xImpasto, self.yImpasto)
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
					
			surf_pomodoro=pygame.image.load('Immagini_Gioco/Immagini_Livello/pomodoro.png')
			rect_pomodoro = surf_pomodoro.get_rect()
			poz = random.randint(0, 3)
			self.giaPoz.append(poz)
			self.xPomodoro = self.posizioni[poz][0]
			self.yPomodoro = self.posizioni[poz][1]
			rect_pomodoro.move_ip(self.xPomodoro, self.yPomodoro) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
			world.blit(surf_pomodoro, (self.xPomodoro, self.yPomodoro))
			
			surf_mozzarella=pygame.image.load('Immagini_Gioco/Immagini_Livello/mozzarella.png')
			rect_mozzarella = surf_mozzarella.get_rect()
			poz = random.randint(0, 3)
			if poz in self.giaPoz:
				controllo = True
				while controllo:
					poz = random.randint(0, 3)
					if (poz in self.giaPoz):
						print("nope")
					else:
						self.giaPoz.append(poz)
						controllo = False
			else:
				self.giaPoz.append(poz)
			self.xMozz = self.posizioni[poz][0]
			self.yMozz = self.posizioni[poz][1]
			rect_mozzarella.move_ip(self.xMozz, self.yMozz)
			world.blit(surf_mozzarella, (self.xMozz,self.yMozz))
			
			self.giaPoz.append(poz)
				
			surf_salame= pygame.image.load('Immagini_Gioco/ingredienti/salsiccia.png')
			rect_salame = surf_salame.get_rect()
			poz = random.randint(0, 3)
			if poz in self.giaPoz:
				controllo = True
				print(poz)
				while controllo:
					poz = random.randint(0, 3)
					if (poz in self.giaPoz):
						print("nope")
					else:
						self.giaPoz.append(poz)
						controllo = False
			else:
				self.giaPoz.append(poz)
			self.xSal = self.posizioni[poz][0]
			self.ySal = self.posizioni[poz][1]
			rect_salame.move_ip(self.xSal, self.ySal)
			world.blit(surf_salame, (self.xSal, self.ySal))
			
			self.giaPoz.append(poz)
			
			surf_fun= pygame.image.load('Immagini_Gioco/ingredienti/funghetto.png')
			rect_fun = surf_fun.get_rect()
			poz = random.randint(0, 3)
			if poz in self.giaPoz:
				controllo = True
				print(poz)
				while controllo:
					poz = random.randint(0, 3)
					if (poz in self.giaPoz):
						print("nope")
					else:
						self.giaPoz.append(poz)
						controllo = False
			else:
				self.giaPoz.append(poz)
			self.xFun = self.posizioni[poz][0]
			self.yFun = self.posizioni[poz][1]
			rect_fun.move_ip(self.xFun, self.yFun)
			world.blit(surf_fun, (self.xFun, self.yFun))
				
			pygame.display.flip()
				
			dragPomodoro = False
			dragMozzarella = False
			dragSalame = False
			dragFungo = False
			eliminaFungo = False
			eliminaSalame = False
			eliminaPomodoro = False
			eliminaMozzarella = False
			ifYouHaveDrag = False
			flagOrdineIngredienti = 0
			clock2 = pygame.time.Clock()
			text = ""
			tempoRimasto = 0

				
			ripeti = True
				
			while ripeti:
				tempoPizza = clock2.tick()
				for event in pygame.event.get():
					if event.type == pygame.QUIT:
						pygame.quit()
						sys.exit()
							
					if event.type == pygame.MOUSEBUTTONDOWN:
						click = event.pos
							
						if rect_pomodoro.collidepoint(click) and event.button == 1: 
							dragPomodoro = True
							mouse_xPom, mouse_yPom = event.pos
							offset_xPom = rect_pomodoro.x - mouse_xPom
							offset_yPom = rect_pomodoro.y - mouse_yPom
								
						if rect_mozzarella.collidepoint(click) and event.button == 1: 
							dragMozzarella = True
							mouse_xMoz, mouse_yMoz = event.pos
							offset_xMoz = rect_mozzarella.x - mouse_xMoz
							offset_yMoz = rect_mozzarella.y- mouse_yMoz
								
						if rect_salame.collidepoint(click) and event.button == 1: 
							dragSalame = True
							mouse_xSal, mouse_ySal = event.pos
							offset_xSal = rect_salame.x - mouse_xSal
							offset_ySal = rect_salame.y- mouse_ySal
							
						if rect_fun.collidepoint(click) and event.button == 1: 
							dragFungo= True
							mouse_xFun, mouse_yFun = event.pos
							offset_xFun = rect_fun.x - mouse_xFun
							offset_yFun = rect_fun.y- mouse_yFun
								
					if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
						
						if rect_pomodoro.colliderect(rect_pizzaVuota):
							eliminaPomodoro = True
							surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/marinara.png')
							world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
							flagOrdineIngredienti=1
								
						if dragPomodoro:
							#print(eliminaPomodoro)
							dragPomodoro = False
							#print(xPom, yPom)
							rect_pomodoro.x = self.xPomodoro
							rect_pomodoro.y = self.yPomodoro
							#self.ristampaSalsicciaF(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame, dragFungo, eliminaFungo)				
								
						if rect_mozzarella.colliderect(rect_pizzaVuota):
							if flagOrdineIngredienti == 1:
								eliminaMozzarella = True
								surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/pizzaMargherita.png')
								world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
								flagOrdineIngredienti=2	
							else:
								eliminaSalame = False
								eliminaMozzarella = False 
								eliminaPomodoro = False
								eliminaFungo = False
								time.sleep(1)
								return 99
							
								
						if dragMozzarella:
						#	print(eliminaPomodoro)
							dragMozzarella = False
							#print(xPom, yPom)
							rect_mozzarella.x = self.xMozz
							rect_mozzarella.y = self.yMozz
							#self.ristampaSalsicciaF(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame, dragFungo, eliminaFungo)	
					#	pygame.display.flip()
							
						if rect_salame.colliderect(rect_pizzaVuota):
							if ( flagOrdineIngredienti == 2):
								eliminaSalame = True
								surf_pizzaVuota=pygame.image.load('Immagini_Gioco/pizze/pizzaSalsiccia.png')
								world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
								flagOrdineIngredienti=3	
							else:
								flagOrdineIngredienti = 0
								eliminaSalame = False
								eliminaMozzarella = False 
								eliminaPomodoro = False
								eliminaFungo = False
								time.sleep(1)
								return 99

						
								
						if dragSalame:
							dragSalame = False
							#print(xPom, yPom)
							rect_salame.x = self.xSal
							rect_salame.y = self.ySal
							#self.ristampaSalsicciaF(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame, dragFungo, eliminaFungo)
								
						if rect_fun.colliderect(rect_pizzaVuota):
							if ( flagOrdineIngredienti == 3):
								eliminaFungo = True
								surf_pizzaVuota=pygame.image.load('Immagini_Gioco/pizze/pizzaSalsiccia.png')
								world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
								flagOrdineIngredienti=4
							else:
								flagOrdineIngredienti = 0
								eliminaSalame = False
								eliminaMozzarella = False 
								eliminaPomodoro = False
								eliminaFungo = False
								time.sleep(1)
								return 99
								
						if dragFungo:
							dragFungo = False
							#print(xPom, yPom)
							rect_fun.x = self.xFun
							rect_fun.y = self.yFun
							#self.ristampaSalsicciaF(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame, dragFungo, eliminaFungo)


						pygame.display.flip()				
												
								
					if event.type == pygame.MOUSEMOTION:
						if dragPomodoro: 
							print("ciao")
							mouse_xPom, mouse_yPom = event.pos
							rect_pomodoro.x = mouse_xPom + offset_xPom
							rect_pomodoro.y = mouse_yPom + offset_yPom
							ifYouHaveDrag = True
				             
						if dragMozzarella:
								#print(flag)
							mouse_xMoz, mouse_yMoz = event.pos
							rect_mozzarella.x = mouse_xMoz + offset_xMoz
							rect_mozzarella.y = mouse_yMoz + offset_yMoz
							ifYouHaveDrag = True	
										
						if dragSalame:
								#print(flag)
							mouse_xSal, mouse_ySal = event.pos
							rect_salame.x = mouse_xSal + offset_xSal
							rect_salame.y = mouse_ySal + offset_ySal
							ifYouHaveDrag = True
																
						if dragFungo:
								#print(flag)
							mouse_xFun, mouse_yFun = event.pos
							rect_fun.x = mouse_xFun + offset_xFun
							rect_fun.y = mouse_yFun + offset_yFun
							ifYouHaveDrag = True				
						
						
				print(ifYouHaveDrag)				
				if ifYouHaveDrag:							
					#self.ristampaSalsicciaF(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame, dragFungo, eliminaFungo)		
														
					print("A")	
				ifYouHaveDrag = False
				if(eliminaPomodoro == False):
					#print("dad")
					world.blit(surf_pomodoro, rect_pomodoro)
				if(eliminaMozzarella == False):
					world.blit(surf_mozzarella, rect_mozzarella)
				if(eliminaSalame == False):
					world.blit(surf_salame, rect_salame)
				if(eliminaFungo == False):
					world.blit(surf_fun, rect_fun)

				pygame.display.flip()		
				if(flagOrdineIngredienti == 4):
					time.sleep(1)
					self.posizioni = []
					self.giaPoz = []
					self.xPomodoro = 0
					self.xMozzarella = 0
					self.yPomodoro = 0
					self.yMozz = 0
					self.xSal = 0
					self.ySal = 0
					self.xFun = 0
					self.yFun = 0
					self.xImpasto = 475
					self.yImpasto = 510
					ripeti = False
				tempoRimasto = tempoPizza + tempoRimasto
				if(tempoRimasto > 4000):
					time.sleep(1)
					return 99
				self.ristampaSalsicciaF(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame, dragFungo, eliminaFungo, tempoRimasto)	
		if self.pathPizza == 'Immagini_Gioco/pizze/pizzaOlive.png':
						
			self.posizioni = [(150, 550), (950, 700), (150, 700)] 
			
			
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/impasto.png')
			rect_pizzaVuota = surf_pizzaVuota.get_rect()
			rect_pizzaVuota.move_ip(self.xImpasto, self.yImpasto)
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
					
			surf_pomodoro=pygame.image.load('Immagini_Gioco/Immagini_Livello/pomodoro.png')
			rect_pomodoro = surf_pomodoro.get_rect()
			poz = random.randint(0, 2)
			self.giaPoz.append(poz)
			self.xPomodoro = self.posizioni[poz][0]
			self.yPomodoro = self.posizioni[poz][1]
			rect_pomodoro.move_ip(self.xPomodoro, self.yPomodoro) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
			world.blit(surf_pomodoro, (self.xPomodoro, self.yPomodoro))
			
			surf_mozzarella=pygame.image.load('Immagini_Gioco/Immagini_Livello/mozzarella.png')
			rect_mozzarella = surf_mozzarella.get_rect()
			poz = random.randint(0, 2)
			if poz in self.giaPoz:
				controllo = True
				while controllo:
					poz = random.randint(0, 2)
					if (poz in self.giaPoz):
						print("nope")
					else:
						self.giaPoz.append(poz)
						controllo = False
			else:
				self.giaPoz.append(poz)
			self.xMozz = self.posizioni[poz][0]
			self.yMozz = self.posizioni[poz][1]
			rect_mozzarella.move_ip(self.xMozz, self.yMozz)
			world.blit(surf_mozzarella, (self.xMozz,self.yMozz))
			
			self.giaPoz.append(poz)
				
			surf_salame= pygame.image.load('Immagini_Gioco/ingredienti/olivaNera.png')
			rect_salame = surf_salame.get_rect()
			poz = random.randint(0, 2)
			if poz in self.giaPoz:
				controllo = True
				print(poz)
				while controllo:
					poz = random.randint(0, 2)
					if (poz in self.giaPoz):
						print("nope")
					else:
						self.giaPoz.append(poz)
						controllo = False
			else:
				self.giaPoz.append(poz)
			self.xSal = self.posizioni[poz][0]
			self.ySal = self.posizioni[poz][1]
			rect_salame.move_ip(self.xSal, self.ySal)
			world.blit(surf_salame, (self.xSal, self.ySal))
				
			pygame.display.flip()
				
			dragPomodoro = False
			dragMozzarella = False
			dragSalame = False
			eliminaSalame = False
			eliminaPomodoro = False
			eliminaMozzarella = False
			ifYouHaveDrag = False
			flagOrdineIngredienti = 0

			clock2 = pygame.time.Clock()
			text = ""
			tempoRimasto = 0
				
			ripeti = True
				
			while ripeti:
				tempoPizza = clock2.tick()
				for event in pygame.event.get():
					if event.type == pygame.QUIT:
						pygame.quit()
						sys.exit()
							
					if event.type == pygame.MOUSEBUTTONDOWN:
						click = event.pos
							
						if rect_pomodoro.collidepoint(click) and event.button == 1: 
							dragPomodoro = True
							mouse_xPom, mouse_yPom = event.pos
							offset_xPom = rect_pomodoro.x - mouse_xPom
							offset_yPom = rect_pomodoro.y - mouse_yPom
								
						if rect_mozzarella.collidepoint(click) and event.button == 1: 
							dragMozzarella = True
							mouse_xMoz, mouse_yMoz = event.pos
							offset_xMoz = rect_mozzarella.x - mouse_xMoz
							offset_yMoz = rect_mozzarella.y- mouse_yMoz
								
						if rect_salame.collidepoint(click) and event.button == 1: 
							dragSalame = True
							mouse_xSal, mouse_ySal = event.pos
							offset_xSal = rect_salame.x - mouse_xSal
							offset_ySal = rect_salame.y- mouse_ySal
								
					if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
						
						if rect_pomodoro.colliderect(rect_pizzaVuota):
							eliminaPomodoro = True
							surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/marinara.png')
							world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
							flagOrdineIngredienti=1
								
						if dragPomodoro:
							#print(eliminaPomodoro)
							dragPomodoro = False
							#print(xPom, yPom)
							rect_pomodoro.x = self.xPomodoro
							rect_pomodoro.y = self.yPomodoro
							#self.ristampaOlive(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame)				
								
						if rect_mozzarella.colliderect(rect_pizzaVuota):
							if flagOrdineIngredienti == 1:
								eliminaMozzarella = True
								surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/pizzaMargherita.png')
								world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
								flagOrdineIngredienti=2	
							else:
								time.sleep(1)
								return 99
							
								
						if dragMozzarella:
						#	print(eliminaPomodoro)
							dragMozzarella = False
							#print(xPom, yPom)
							rect_mozzarella.x = self.xMozz
							rect_mozzarella.y = self.yMozz
							#self.ristampaOlive(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame)	
					#	pygame.display.flip()
							
						if rect_salame.colliderect(rect_pizzaVuota):
							if ( flagOrdineIngredienti == 2):
								eliminaSalame = True
								surf_pizzaVuota=pygame.image.load('Immagini_Gioco/pizze/pizzaOlive.png')
								world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
								flagOrdineIngredienti=3	
							else:
								flagOrdineIngredienti = 0
								eliminaSalame = False
								eliminaMozzarella = False 
								eliminaPomodoro = False
								time.sleep(1)
								return 99
						
								
						if dragSalame:
							dragSalame = False
							#print(xPom, yPom)
							rect_salame.x = self.xSal
							rect_salame.y = self.ySal
						#	self.ristampaOlive(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame)	
						pygame.display.flip()				
												
								
					if event.type == pygame.MOUSEMOTION:
						if dragPomodoro: 
							print("ciao")
							mouse_xPom, mouse_yPom = event.pos
							rect_pomodoro.x = mouse_xPom + offset_xPom
							rect_pomodoro.y = mouse_yPom + offset_yPom
							ifYouHaveDrag = True
				             
						if dragMozzarella:
								#print(flag)
							mouse_xMoz, mouse_yMoz = event.pos
							rect_mozzarella.x = mouse_xMoz + offset_xMoz
							rect_mozzarella.y = mouse_yMoz + offset_yMoz
							ifYouHaveDrag = True	
										
						if dragSalame:
								#print(flag)
							mouse_xSal, mouse_ySal = event.pos
							rect_salame.x = mouse_xSal + offset_xSal
							rect_salame.y = mouse_ySal + offset_ySal
							ifYouHaveDrag = True			
						
						
				print(ifYouHaveDrag)				
				if ifYouHaveDrag:							
					#self.ristampaOlive(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame)			
														
					print("A")	
				ifYouHaveDrag = False
				if(eliminaPomodoro == False):
					#print("dad")
					world.blit(surf_pomodoro, rect_pomodoro)
				if(eliminaMozzarella == False):
					world.blit(surf_mozzarella, rect_mozzarella)
				if(eliminaSalame == False):
					world.blit(surf_salame, rect_salame)

				pygame.display.flip()		
				if(flagOrdineIngredienti == 3):
					time.sleep(1)
					self.posizioni = []
					self.giaPoz = []
					self.xPomodoro = 0
					self.xMozzarella = 0
					self.yPomodoro = 0
					self.yMozz = 0
					self.xSal = 0
					self.ySal = 0
					self.xImpasto = 475
					self.yImpasto = 510
					ripeti = False	
				tempoRimasto = tempoPizza + tempoRimasto
				if(tempoRimasto > 3000):
					time.sleep(1)
					return 99
				self.ristampaOlive(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame, tempoRimasto)
					
		if self.pathPizza == 'Immagini_Gioco/pizze/pizzaProsciutto_Olive.png':
					
			self.posizioni = [(150, 550), (950, 700), (150, 700), (950, 550)] 
			
			
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/impasto.png')
			rect_pizzaVuota = surf_pizzaVuota.get_rect()
			rect_pizzaVuota.move_ip(self.xImpasto, self.yImpasto)
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
					
			surf_pomodoro=pygame.image.load('Immagini_Gioco/Immagini_Livello/pomodoro.png')
			rect_pomodoro = surf_pomodoro.get_rect()
			poz = random.randint(0, 3)
			self.giaPoz.append(poz)
			self.xPomodoro = self.posizioni[poz][0]
			self.yPomodoro = self.posizioni[poz][1]
			rect_pomodoro.move_ip(self.xPomodoro, self.yPomodoro) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
			world.blit(surf_pomodoro, (self.xPomodoro, self.yPomodoro))
			
			surf_mozzarella=pygame.image.load('Immagini_Gioco/Immagini_Livello/mozzarella.png')
			rect_mozzarella = surf_mozzarella.get_rect()
			poz = random.randint(0, 3)
			if poz in self.giaPoz:
				controllo = True
				while controllo:
					poz = random.randint(0, 3)
					if (poz in self.giaPoz):
						print("nope")
					else:
						self.giaPoz.append(poz)
						controllo = False
			else:
				self.giaPoz.append(poz)
			self.xMozz = self.posizioni[poz][0]
			self.yMozz = self.posizioni[poz][1]
			rect_mozzarella.move_ip(self.xMozz, self.yMozz)
			world.blit(surf_mozzarella, (self.xMozz,self.yMozz))
			
			self.giaPoz.append(poz)
				
			surf_salame= pygame.image.load('Immagini_Gioco/ingredienti/olivaNera.png')
			rect_salame = surf_salame.get_rect()
			poz = random.randint(0, 3)
			if poz in self.giaPoz:
				controllo = True
				print(poz)
				while controllo:
					poz = random.randint(0, 3)
					if (poz in self.giaPoz):
						print("nope")
					else:
						self.giaPoz.append(poz)
						controllo = False
			else:
				self.giaPoz.append(poz)
			self.xSal = self.posizioni[poz][0]
			self.ySal = self.posizioni[poz][1]
			rect_salame.move_ip(self.xSal, self.ySal)
			world.blit(surf_salame, (self.xSal, self.ySal))
			
			self.giaPoz.append(poz)
			
			surf_fun= pygame.image.load('Immagini_Gioco/ingredienti/prosciuttone.png')
			rect_fun = surf_fun.get_rect()
			poz = random.randint(0, 3)
			if poz in self.giaPoz:
				controllo = True
				print(poz)
				while controllo:
					poz = random.randint(0, 3)
					if (poz in self.giaPoz):
						print("nope")
					else:
						self.giaPoz.append(poz)
						controllo = False
			else:
				self.giaPoz.append(poz)
			self.xFun = self.posizioni[poz][0]
			self.yFun = self.posizioni[poz][1]
			rect_fun.move_ip(self.xFun, self.yFun)
			world.blit(surf_fun, (self.xFun, self.yFun))
				
			pygame.display.flip()
				
			dragPomodoro = False
			dragMozzarella = False
			dragSalame = False
			dragFungo = False
			eliminaFungo = False
			eliminaSalame = False
			eliminaPomodoro = False
			eliminaMozzarella = False
			ifYouHaveDrag = False
			flagOrdineIngredienti = 0
			
			clock2 = pygame.time.Clock()
			text = ""
			tempoRimasto = 0
				
			ripeti = True
				
			while ripeti:
				tempoPizza = clock2.tick()
				for event in pygame.event.get():
					if event.type == pygame.QUIT:
						pygame.quit()
						sys.exit()
							
					if event.type == pygame.MOUSEBUTTONDOWN:
						click = event.pos
							
						if rect_pomodoro.collidepoint(click) and event.button == 1: 
							dragPomodoro = True
							mouse_xPom, mouse_yPom = event.pos
							offset_xPom = rect_pomodoro.x - mouse_xPom
							offset_yPom = rect_pomodoro.y - mouse_yPom
								
						if rect_mozzarella.collidepoint(click) and event.button == 1: 
							dragMozzarella = True
							mouse_xMoz, mouse_yMoz = event.pos
							offset_xMoz = rect_mozzarella.x - mouse_xMoz
							offset_yMoz = rect_mozzarella.y- mouse_yMoz
								
						if rect_salame.collidepoint(click) and event.button == 1: 
							dragSalame = True
							mouse_xSal, mouse_ySal = event.pos
							offset_xSal = rect_salame.x - mouse_xSal
							offset_ySal = rect_salame.y- mouse_ySal
							
						if rect_fun.collidepoint(click) and event.button == 1: 
							dragFungo= True
							mouse_xFun, mouse_yFun = event.pos
							offset_xFun = rect_fun.x - mouse_xFun
							offset_yFun = rect_fun.y- mouse_yFun
								
					if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
						
						if rect_pomodoro.colliderect(rect_pizzaVuota):
							eliminaPomodoro = True
							surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/marinara.png')
							world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
							flagOrdineIngredienti=1
								
						if dragPomodoro:
							#print(eliminaPomodoro)
							dragPomodoro = False
							#print(xPom, yPom)
							rect_pomodoro.x = self.xPomodoro
							rect_pomodoro.y = self.yPomodoro
							#self.ristampaOP(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame, dragFungo, eliminaFungo)				
								
						if rect_mozzarella.colliderect(rect_pizzaVuota):
							if flagOrdineIngredienti == 1:
								eliminaMozzarella = True
								surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/pizzaMargherita.png')
								world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
								flagOrdineIngredienti=2	
							else:
								eliminaSalame = False
								eliminaMozzarella = False 
								eliminaPomodoro = False
								eliminaFungo = False
								time.sleep(1)
								return 99
							
								
						if dragMozzarella:
						#	print(eliminaPomodoro)
							dragMozzarella = False
							#print(xPom, yPom)
							rect_mozzarella.x = self.xMozz
							rect_mozzarella.y = self.yMozz
							#self.ristampaOP(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame, dragFungo, eliminaFungo)	
					#	pygame.display.flip()
							
						if rect_salame.colliderect(rect_pizzaVuota):
							if ( flagOrdineIngredienti == 2):
								eliminaSalame = True
								surf_pizzaVuota=pygame.image.load('Immagini_Gioco/pizze/pizzaOlive.png')
								world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
								flagOrdineIngredienti=3	
							else:
								flagOrdineIngredienti = 0
								eliminaSalame = False
								eliminaMozzarella = False 
								eliminaPomodoro = False
								eliminaFungo = False
								time.sleep(1)
								return 99

						
								
						if dragSalame:
							dragSalame = False
							#print(xPom, yPom)
							rect_salame.x = self.xSal
							rect_salame.y = self.ySal
						#	self.ristampaOP(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame, dragFungo, eliminaFungo)
								
						if rect_fun.colliderect(rect_pizzaVuota):
							if ( flagOrdineIngredienti == 3):
								eliminaFungo = True
								surf_pizzaVuota=pygame.image.load('Immagini_Gioco/pizze/pizzaProsciutto_Olive.png')
								world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
								flagOrdineIngredienti=4
							else:
								flagOrdineIngredienti = 0
								eliminaSalame = False
								eliminaMozzarella = False 
								eliminaPomodoro = False
								eliminaFungo = False
								time.sleep(1)
								return 99
								
						if dragFungo:
							dragFungo = False
							#print(xPom, yPom)
							rect_fun.x = self.xFun
							rect_fun.y = self.yFun
							#self.ristampaOP(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame, dragFungo, eliminaFungo)


						pygame.display.flip()				
												
								
					if event.type == pygame.MOUSEMOTION:
						if dragPomodoro: 
							print("ciao")
							mouse_xPom, mouse_yPom = event.pos
							rect_pomodoro.x = mouse_xPom + offset_xPom
							rect_pomodoro.y = mouse_yPom + offset_yPom
							ifYouHaveDrag = True
				             
						if dragMozzarella:
								#print(flag)
							mouse_xMoz, mouse_yMoz = event.pos
							rect_mozzarella.x = mouse_xMoz + offset_xMoz
							rect_mozzarella.y = mouse_yMoz + offset_yMoz
							ifYouHaveDrag = True	
										
						if dragSalame:
								#print(flag)
							mouse_xSal, mouse_ySal = event.pos
							rect_salame.x = mouse_xSal + offset_xSal
							rect_salame.y = mouse_ySal + offset_ySal
							ifYouHaveDrag = True
																
						if dragFungo:
								#print(flag)
							mouse_xFun, mouse_yFun = event.pos
							rect_fun.x = mouse_xFun + offset_xFun
							rect_fun.y = mouse_yFun + offset_yFun
							ifYouHaveDrag = True				
						
						
				print(ifYouHaveDrag)				
				if ifYouHaveDrag:							
					#self.ristampaOP(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame, dragFungo, eliminaFungo)		
														
					print("A")	
				ifYouHaveDrag = False
				if(eliminaPomodoro == False):
					#print("dad")
					world.blit(surf_pomodoro, rect_pomodoro)
				if(eliminaMozzarella == False):
					world.blit(surf_mozzarella, rect_mozzarella)
				if(eliminaSalame == False):
					world.blit(surf_salame, rect_salame)
				if(eliminaFungo == False):
					world.blit(surf_fun, rect_fun)

				pygame.display.flip()		
				if(flagOrdineIngredienti == 4):
					time.sleep(1)
					self.posizioni = []
					self.giaPoz = []
					self.xPomodoro = 0
					self.xMozzarella = 0
					self.yPomodoro = 0
					self.yMozz = 0
					self.xSal = 0
					self.ySal = 0
					self.xFun = 0
					self.yFun = 0
					self.xImpasto = 475
					self.yImpasto = 510
					ripeti = False		
				tempoRimasto = tempoPizza + tempoRimasto
				if(tempoRimasto > 4000):
					time.sleep(1)
					return 99
				self.ristampaOP(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame, dragFungo, eliminaFungo, tempoRimasto)	
					
					
		if self.pathPizza == 'Immagini_Gioco/pizze/pizzaFunghi.png':
			print("eia")
			self.posizioni = [(150, 550), (950, 700), (150, 700)] 
			
			
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/impasto.png')
			rect_pizzaVuota = surf_pizzaVuota.get_rect()
			rect_pizzaVuota.move_ip(self.xImpasto, self.yImpasto)
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
					
			surf_pomodoro=pygame.image.load('Immagini_Gioco/Immagini_Livello/pomodoro.png')
			rect_pomodoro = surf_pomodoro.get_rect()
			poz = random.randint(0, 2)
			self.giaPoz.append(poz)
			self.xPomodoro = self.posizioni[poz][0]
			self.yPomodoro = self.posizioni[poz][1]
			rect_pomodoro.move_ip(self.xPomodoro, self.yPomodoro) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
			world.blit(surf_pomodoro, (self.xPomodoro, self.yPomodoro))
			
			surf_mozzarella=pygame.image.load('Immagini_Gioco/Immagini_Livello/mozzarella.png')
			rect_mozzarella = surf_mozzarella.get_rect()
			poz = random.randint(0, 2)
			if poz in self.giaPoz:
				controllo = True
				while controllo:
					poz = random.randint(0, 2)
					if (poz in self.giaPoz):
						print("nope")
					else:
						self.giaPoz.append(poz)
						controllo = False
			else:
				self.giaPoz.append(poz)
			self.xMozz = self.posizioni[poz][0]
			self.yMozz = self.posizioni[poz][1]
			rect_mozzarella.move_ip(self.xMozz, self.yMozz)
			world.blit(surf_mozzarella, (self.xMozz,self.yMozz))
			
			self.giaPoz.append(poz)
				
			surf_salame= pygame.image.load('Immagini_Gioco/ingredienti/funghetto.png')
			rect_salame = surf_salame.get_rect()
			poz = random.randint(0, 2)
			if poz in self.giaPoz:
				controllo = True
				print(poz)
				while controllo:
					poz = random.randint(0, 2)
					if (poz in self.giaPoz):
						print("nope")
					else:
						self.giaPoz.append(poz)
						controllo = False
			else:
				self.giaPoz.append(poz)
			self.xSal = self.posizioni[poz][0]
			self.ySal = self.posizioni[poz][1]
			rect_salame.move_ip(self.xSal, self.ySal)
			world.blit(surf_salame, (self.xSal, self.ySal))
				
			pygame.display.flip()
				
			dragPomodoro = False
			dragMozzarella = False
			dragSalame = False
			eliminaSalame = False
			eliminaPomodoro = False
			eliminaMozzarella = False
			ifYouHaveDrag = False
			flagOrdineIngredienti = 0
			clock2 = pygame.time.Clock()
			text = ""
			tempoRimasto = 0
				
			ripeti = True
				
			while ripeti:
				tempoPizza = clock2.tick()
				print("Ougay")
				for event in pygame.event.get():
					if event.type == pygame.QUIT:
						pygame.quit()
						sys.exit()
							
					if event.type == pygame.MOUSEBUTTONDOWN:
						click = event.pos
							
						if rect_pomodoro.collidepoint(click) and event.button == 1: 
							dragPomodoro = True
							mouse_xPom, mouse_yPom = event.pos
							offset_xPom = rect_pomodoro.x - mouse_xPom
							offset_yPom = rect_pomodoro.y - mouse_yPom
								
						if rect_mozzarella.collidepoint(click) and event.button == 1: 
							dragMozzarella = True
							mouse_xMoz, mouse_yMoz = event.pos
							offset_xMoz = rect_mozzarella.x - mouse_xMoz
							offset_yMoz = rect_mozzarella.y- mouse_yMoz
								
						if rect_salame.collidepoint(click) and event.button == 1: 
							dragSalame = True
							mouse_xSal, mouse_ySal = event.pos
							offset_xSal = rect_salame.x - mouse_xSal
							offset_ySal = rect_salame.y- mouse_ySal
								
					if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
						
						if rect_pomodoro.colliderect(rect_pizzaVuota):
							eliminaPomodoro = True
							surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/marinara.png')
							world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
							flagOrdineIngredienti=1
								
						if dragPomodoro:
							#print(eliminaPomodoro)
							dragPomodoro = False
							#print(xPom, yPom)
							rect_pomodoro.x = self.xPomodoro
							rect_pomodoro.y = self.yPomodoro
							#self.ristampaFunghi(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame)				
								
						if rect_mozzarella.colliderect(rect_pizzaVuota):
							if flagOrdineIngredienti == 1:
								eliminaMozzarella = True
								surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/pizzaMargherita.png')
								world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
								flagOrdineIngredienti=2	
							else:
								time.sleep(1)
								return 99
							
								
						if dragMozzarella:
						#	print(eliminaPomodoro)
							dragMozzarella = False
							#print(xPom, yPom)
							rect_mozzarella.x = self.xMozz
							rect_mozzarella.y = self.yMozz
							#self.ristampaFunghi(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame)	
					#	pygame.display.flip()
							
						if rect_salame.colliderect(rect_pizzaVuota):
							if ( flagOrdineIngredienti == 2):
								eliminaSalame = True
								surf_pizzaVuota=pygame.image.load('Immagini_Gioco/pizze/pizzaFunghi.png')
								world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
								flagOrdineIngredienti=3	
							else:
								flagOrdineIngredienti = 0
								eliminaSalame = False
								eliminaMozzarella = False 
								eliminaPomodoro = False
								time.sleep(1)
								return 99
						
								
						if dragSalame:
							dragSalame = False
							#print(xPom, yPom)
							rect_salame.x = self.xSal
							rect_salame.y = self.ySal
							#self.ristampaFunghi(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame)	
						pygame.display.flip()				
												
								
					if event.type == pygame.MOUSEMOTION:
						if dragPomodoro: 
							print("ciao")
							mouse_xPom, mouse_yPom = event.pos
							rect_pomodoro.x = mouse_xPom + offset_xPom
							rect_pomodoro.y = mouse_yPom + offset_yPom
							ifYouHaveDrag = True
				             
						if dragMozzarella:
								#print(flag)
							mouse_xMoz, mouse_yMoz = event.pos
							rect_mozzarella.x = mouse_xMoz + offset_xMoz
							rect_mozzarella.y = mouse_yMoz + offset_yMoz
							ifYouHaveDrag = True	
										
						if dragSalame:
								#print(flag)
							mouse_xSal, mouse_ySal = event.pos
							rect_salame.x = mouse_xSal + offset_xSal
							rect_salame.y = mouse_ySal + offset_ySal
							ifYouHaveDrag = True			
						
						
				print(ifYouHaveDrag)				
				if ifYouHaveDrag:							
					#self.ristampaFunghi(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame)			
														
					print("A")	
				ifYouHaveDrag = False
				if(eliminaPomodoro == False):
					#print("dad")
					world.blit(surf_pomodoro, rect_pomodoro)
				if(eliminaMozzarella == False):
					world.blit(surf_mozzarella, rect_mozzarella)
				if(eliminaSalame == False):
					world.blit(surf_salame, rect_salame)

				pygame.display.flip()		
				if(flagOrdineIngredienti == 3):
					time.sleep(1)
					self.posizioni = []
					self.giaPoz = []
					self.xPomodoro = 0
					self.xMozzarella = 0
					self.yPomodoro = 0
					self.yMozz = 0
					self.xSal = 0
					self.ySal = 0
					self.xImpasto = 475
					self.yImpasto = 510
					ripeti = False	
				tempoRimasto = tempoPizza + tempoRimasto
				if(tempoRimasto > 3000):
					time.sleep(1)
					return 99	
				self.ristampaFunghi(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame, tempoRimasto)	
					
		if self.pathPizza == 'Immagini_Gioco/pizze/pizzaQuattroStagioni.png':
		
			self.posizioni = [(150, 550), (950, 700), (150, 700), (950, 550), (1100, 620)] 
			
			
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/impasto.png')
			rect_pizzaVuota = surf_pizzaVuota.get_rect()
			rect_pizzaVuota.move_ip(self.xImpasto, self.yImpasto)
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
					
			surf_pomodoro=pygame.image.load('Immagini_Gioco/Immagini_Livello/pomodoro.png')
			rect_pomodoro = surf_pomodoro.get_rect()
			poz = random.randint(0, 4)
			self.giaPoz.append(poz)
			self.xPomodoro = self.posizioni[poz][0]
			self.yPomodoro = self.posizioni[poz][1]
			rect_pomodoro.move_ip(self.xPomodoro, self.yPomodoro) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
			world.blit(surf_pomodoro, (self.xPomodoro, self.yPomodoro))
			
			surf_mozzarella=pygame.image.load('Immagini_Gioco/Immagini_Livello/mozzarella.png')
			rect_mozzarella = surf_mozzarella.get_rect()
			poz = random.randint(0, 4)
			if poz in self.giaPoz:
				controllo = True
				while controllo:
					poz = random.randint(0, 4)
					if (poz in self.giaPoz):
						print("nope")
					else:
						self.giaPoz.append(poz)
						controllo = False
			else:
				self.giaPoz.append(poz)
			self.xMozz = self.posizioni[poz][0]
			self.yMozz = self.posizioni[poz][1]
			rect_mozzarella.move_ip(self.xMozz, self.yMozz)
			world.blit(surf_mozzarella, (self.xMozz,self.yMozz))
			
			self.giaPoz.append(poz)
				
			surf_salame= pygame.image.load('Immagini_Gioco/ingredienti/olivaNera.png')
			rect_salame = surf_salame.get_rect()
			poz = random.randint(0, 4)
			if poz in self.giaPoz:
				controllo = True
				print(poz)
				while controllo:
					poz = random.randint(0, 4)
					if (poz in self.giaPoz):
						print("nope")
					else:
						self.giaPoz.append(poz)
						controllo = False
			else:
				self.giaPoz.append(poz)
			self.xSal = self.posizioni[poz][0]
			self.ySal = self.posizioni[poz][1]
			rect_salame.move_ip(self.xSal, self.ySal)
			world.blit(surf_salame, (self.xSal, self.ySal))
			
			self.giaPoz.append(poz)
			
			surf_fun= pygame.image.load('Immagini_Gioco/ingredienti/prosciuttone.png')
			rect_fun = surf_fun.get_rect()
			poz = random.randint(0, 4)
			if poz in self.giaPoz:
				controllo = True
				print(poz)
				while controllo:
					poz = random.randint(0, 4)
					if (poz in self.giaPoz):
						print("nope")
					else:
						self.giaPoz.append(poz)
						controllo = False
			else:
				self.giaPoz.append(poz)
			self.xFun = self.posizioni[poz][0]
			self.yFun = self.posizioni[poz][1]
			rect_fun.move_ip(self.xFun, self.yFun)
			world.blit(surf_fun, (self.xFun, self.yFun))
			
			self.giaPoz.append(poz)
			
			surf_car= pygame.image.load('Immagini_Gioco/ingredienti/carciofino.png')
			rect_car = surf_car.get_rect()
			poz = random.randint(0, 4)
			if poz in self.giaPoz:
				controllo = True
				print(poz)
				while controllo:
					poz = random.randint(0, 4)
					if (poz in self.giaPoz):
						print("nope")
					else:
						self.giaPoz.append(poz)
						controllo = False
			else:
				self.giaPoz.append(poz)
			self.xcar = self.posizioni[poz][0]
			self.ycar = self.posizioni[poz][1]
			rect_car.move_ip(self.xcar, self.ycar)
			world.blit(surf_car, (self.xcar, self.ycar))
				
			pygame.display.flip()
				
			dragPomodoro = False
			dragMozzarella = False
			dragSalame = False
			dragFungo = False
			dragCarciofo = False
			eliminaCarciofo = False
			eliminaFungo = False
			eliminaSalame = False
			eliminaPomodoro = False
			eliminaMozzarella = False
			ifYouHaveDrag = False
			flagOrdineIngredienti = 0

			clock2 = pygame.time.Clock()
			text = ""
			tempoRimasto = 0
				
			ripeti = True
				
			while ripeti:
				tempoPizza = clock2.tick()
				for event in pygame.event.get():
					if event.type == pygame.QUIT:
						pygame.quit()
						sys.exit()
							
					if event.type == pygame.MOUSEBUTTONDOWN:
						click = event.pos
							
						if rect_pomodoro.collidepoint(click) and event.button == 1: 
							dragPomodoro = True
							mouse_xPom, mouse_yPom = event.pos
							offset_xPom = rect_pomodoro.x - mouse_xPom
							offset_yPom = rect_pomodoro.y - mouse_yPom
								
						if rect_mozzarella.collidepoint(click) and event.button == 1: 
							dragMozzarella = True
							mouse_xMoz, mouse_yMoz = event.pos
							offset_xMoz = rect_mozzarella.x - mouse_xMoz
							offset_yMoz = rect_mozzarella.y- mouse_yMoz
								
						if rect_salame.collidepoint(click) and event.button == 1: 
							dragSalame = True
							mouse_xSal, mouse_ySal = event.pos
							offset_xSal = rect_salame.x - mouse_xSal
							offset_ySal = rect_salame.y- mouse_ySal
							
						if rect_fun.collidepoint(click) and event.button == 1: 
							dragFungo= True
							mouse_xFun, mouse_yFun = event.pos
							offset_xFun = rect_fun.x - mouse_xFun
							offset_yFun = rect_fun.y- mouse_yFun
							
						if rect_car.collidepoint(click) and event.button == 1: 
							dragCarciofo= True
							mouse_xcar, mouse_ycar = event.pos
							offset_xcar = rect_car.x - mouse_xcar
							offset_ycar = rect_car.y- mouse_ycar							
								
					if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
						
						if rect_pomodoro.colliderect(rect_pizzaVuota):
							eliminaPomodoro = True
							surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/marinara.png')
							world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
							flagOrdineIngredienti=1
								
						if dragPomodoro:
							#print(eliminaPomodoro)
							dragPomodoro = False
							#print(xPom, yPom)
							rect_pomodoro.x = self.xPomodoro
							rect_pomodoro.y = self.yPomodoro
							#self.ristampaOP(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame, dragFungo, eliminaFungo)				
								
						if rect_mozzarella.colliderect(rect_pizzaVuota):
							if flagOrdineIngredienti == 1:
								eliminaMozzarella = True
								surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/pizzaMargherita.png')
								world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
								flagOrdineIngredienti=2	
							else:
								eliminaSalame = False
								eliminaMozzarella = False 
								eliminaPomodoro = False
								eliminaCarciofo = False
								eliminaFungo = False
								time.sleep(1)
								return 99
							
								
						if dragMozzarella:
						#	print(eliminaPomodoro)
							dragMozzarella = False
							#print(xPom, yPom)
							rect_mozzarella.x = self.xMozz
							rect_mozzarella.y = self.yMozz
							#self.ristampaQuat(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame, dragFungo, eliminaFungo , dragCarciofo , eliminaCarciofo)	
					#	pygame.display.flip()
							
						if rect_salame.colliderect(rect_pizzaVuota):
							if ( flagOrdineIngredienti == 2):
								eliminaSalame = True
								surf_pizzaVuota=pygame.image.load('Immagini_Gioco/pizze/pizzaOlive.png')
								world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
								flagOrdineIngredienti=3	
							else:
								flagOrdineIngredienti = 0
								eliminaSalame = False
								eliminaMozzarella = False 
								eliminaPomodoro = False
								eliminaCarciofo = False
								eliminaFungo = False
								time.sleep(1)
								return 99

						
								
						if dragSalame:
							dragSalame = False
							#print(xPom, yPom)
							rect_salame.x = self.xSal
							rect_salame.y = self.ySal
							#self.ristampaQuat(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame, dragFungo, eliminaFungo  , dragCarciofo , eliminaCarciofo)
								
						if rect_fun.colliderect(rect_pizzaVuota):
							if ( flagOrdineIngredienti == 3):
								eliminaFungo = True
								surf_pizzaVuota=pygame.image.load('Immagini_Gioco/pizze/pizzaProsciutto_Olive.png')
								world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
								flagOrdineIngredienti=4
							else:
								flagOrdineIngredienti = 0
								eliminaSalame = False
								eliminaMozzarella = False 
								eliminaCarciofo = False
								eliminaPomodoro = False
								eliminaFungo = False
								time.sleep(1)
								return 99
								
						if dragFungo:
							dragFungo = False
							#print(xPom, yPom)
							rect_fun.x = self.xFun
							rect_fun.y = self.yFun
							#self.ristampaQuat(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame, dragFungo, eliminaFungo , dragCarciofo , eliminaCarciofo)

						if rect_car.colliderect(rect_pizzaVuota):
							if ( flagOrdineIngredienti == 4):
								eliminaCarciofo= True
								surf_pizzaVuota=pygame.image.load('Immagini_Gioco/pizze/pizzaQuattroStagioni.png')
								world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
								flagOrdineIngredienti=5
							else:
								flagOrdineIngredienti = 0
								eliminaSalame = False
								eliminaMozzarella = False 
								eliminaCarciofo = False
								eliminaPomodoro = False
								eliminaFungo = False
								time.sleep(1)
								return 99
								
						if dragCarciofo:
							dragCarciofo = False
							#print(xPom, yPom)
							rect_car.x = self.xcar
							rect_car.y = self.ycar
						#	self.ristampaQuat(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame, dragFungo, eliminaFungo  , dragCarciofo , eliminaCarciofo)
						pygame.display.flip()				
												
								
					if event.type == pygame.MOUSEMOTION:
						if dragPomodoro: 
							print("ciao")
							mouse_xPom, mouse_yPom = event.pos
							rect_pomodoro.x = mouse_xPom + offset_xPom
							rect_pomodoro.y = mouse_yPom + offset_yPom
							ifYouHaveDrag = True
				             
						if dragMozzarella:
								#print(flag)
							mouse_xMoz, mouse_yMoz = event.pos
							rect_mozzarella.x = mouse_xMoz + offset_xMoz
							rect_mozzarella.y = mouse_yMoz + offset_yMoz
							ifYouHaveDrag = True	
										
						if dragSalame:
								#print(flag)
							mouse_xSal, mouse_ySal = event.pos
							rect_salame.x = mouse_xSal + offset_xSal
							rect_salame.y = mouse_ySal + offset_ySal
							ifYouHaveDrag = True
																
						if dragFungo:
								#print(flag)
							mouse_xFun, mouse_yFun = event.pos
							rect_fun.x = mouse_xFun + offset_xFun
							rect_fun.y = mouse_yFun + offset_yFun
							ifYouHaveDrag = True		
						if dragCarciofo:
								#print(flag)
							mouse_xcar, mouse_ycar = event.pos
							rect_car.x = mouse_xcar + offset_xcar
							rect_car.y = mouse_ycar + offset_ycar
							ifYouHaveDrag = True			
						
						
				print(ifYouHaveDrag)				
				if ifYouHaveDrag:							
					#self.ristampaQuat(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame, dragFungo, eliminaFungo, dragCarciofo, eliminaCarciofo)		
														
					print("A")	
				ifYouHaveDrag = False
				if(eliminaPomodoro == False):
					#print("dad")
					world.blit(surf_pomodoro, rect_pomodoro)
				if(eliminaMozzarella == False):
					world.blit(surf_mozzarella, rect_mozzarella)
				if(eliminaSalame == False):
					world.blit(surf_salame, rect_salame)
				if(eliminaFungo == False):
					world.blit(surf_fun, rect_fun)
				if(eliminaCarciofo == False):
					world.blit(surf_car, rect_car)
					
				pygame.display.flip()		
				if(flagOrdineIngredienti == 5):
					time.sleep(1)
					self.posizioni = []
					self.giaPoz = []
					self.xPomodoro = 0
					self.xMozzarella = 0
					self.yPomodoro = 0
					self.yMozz = 0
					self.xSal = 0
					self.ySal = 0
					self.xFun = 0
					self.yFun = 0
					self.xcar = 0
					self.ycar = 0
					self.xImpasto = 475
					self.yImpasto = 510
					ripeti = False	
				tempoRimasto = tempoPizza + tempoRimasto
				if(tempoRimasto > 5000):
					time.sleep(1)
					return 99
				self.ristampaQuat(world, flagOrdineIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragSalame, eliminaSalame, dragFungo, eliminaFungo, dragCarciofo, eliminaCarciofo, tempoRimasto)	

	def ristampaMake(self, world, tempoRimasto = 0):
		
		#surf_background = pygame.image.load("Immagini_Gioco/INVENTARIO/tavernaG.jpg").convert()
		#world.blit(surf_background, (0, 0))
		
		surf_azioni = pygame.image.load("Immagini_Gioco/HUB/dialogPizza.jpg")
		world.blit(surf_azioni , (0, 450))
		
		surf_box = pygame.image.load("Immagini_Gioco/INVENTARIO/boxPizz.jpg")
		world.blit(surf_box, (412, 500))
		
		#world.blit(pygame.image.load('Immagini_Gioco/Immagini_Livello/impasto.png'), (self.xImpasto, self.yImpasto))
		

	def ristampaTempo(self, world, tempoRimasto ):
	
		#world.blit(pygame.image.load("Immagini_Gioco/INVENTARIO/copri.jpg"), (100,500))
		
		appoggio = int(tempoRimasto) / 1000
		app =  str(appoggio)
		text =  "TEMPO: " +   app[0:4] 
		tempo = self.font.render(text, False, (255, 255, 0))
		#tempo.fill((0,0,255))
	#	tempo = self.font.render(text, False, (255, 255, 0))
		print(tempoRimasto)
		world.blit(tempo ,(120, 520))	
		#pygame.display.flip()	
		
		#world.blit(pygame.image.load("Immagini_Gioco/INVENTARIO/copri.jpg"), (100,500))
		
		#self.ristampaMake(world)
		
	
		
	def ristampaMargherita(self, world, flag, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, tempoRimasto):
		self.ristampaMake(world)
		if(flag == 0):  
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/impasto.png')

			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif (flag == 1):
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/marinara.png')

			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif (flag == 2):
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/pizzaMargherita.png')
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))

		
		if dragPomodoro == False and eliminaPomodoro == False :	
			surf_pomodoro=pygame.image.load('Immagini_Gioco/Immagini_Livello/pomodoro.png')
			world.blit(surf_pomodoro, (self.xPomodoro,self.yPomodoro))
		if dragMozzarella == False and eliminaMozzarella == False:	
			surf_mozzarella=pygame.image.load('Immagini_Gioco/Immagini_Livello/mozzarella.png')
			world.blit(surf_mozzarella, (self.xMozz, self.yMozz))
			
		
		valore = 3000
		appoggio = (valore - int(tempoRimasto)) / 1000
		app =  str(appoggio)
		text =  "TEMPO: " +   app[0:4] 
		print(tempoRimasto)
		world.blit(self.font.render(text, False, (255, 255, 0)) ,(120, 520))	
			
		pygame.display.flip()
		
				
		


	def ristampaProsciutto(self, world, flag, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragProsciutto, eliminaProsciutto, tempoRimasto):
		self.ristampaMake(world)
		if(flag == 0):  
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/impasto.png')
			rect_pizzaVuota = surf_pizzaVuota.get_rect()
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif (flag == 1):
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/marinara.png')
			rect_pizzaVuota = surf_pizzaVuota.get_rect()
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif (flag == 2):
			print("fatto")
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/pizzaMargherita.png')
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif ( flag == 3):
			print("fatto")
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/pizze/pizzaProsciutto.png')
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		
		if dragPomodoro == False and eliminaPomodoro == False :	
			surf_pomodoro=pygame.image.load('Immagini_Gioco/Immagini_Livello/pomodoro.png')
			world.blit(surf_pomodoro, (self.xPomodoro,self.yPomodoro))
		if dragMozzarella == False and eliminaMozzarella == False:	
			surf_mozzarella=pygame.image.load('Immagini_Gioco/Immagini_Livello/mozzarella.png')
			world.blit(surf_mozzarella, (self.xMozz, self.yMozz))
		if dragProsciutto == False and eliminaProsciutto == False:	
			surf_prosciutto=pygame.image.load('Immagini_Gioco/ingredienti/prosciuttone.png')
			world.blit(surf_prosciutto, (self.xProsc,self.yProsc))
			

		valore = 3000
		appoggio = (valore - int(tempoRimasto)) / 1000
		app =  str(appoggio)
		text =  "TEMPO: " +   app[0:4] 
		print(tempoRimasto)
		world.blit(self.font.render(text, False, (255, 255, 0)) ,(120, 520))	
			
		pygame.display.flip()
			
		

	def ristampaSalame(self, world, flag, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragProsciutto, eliminaProsciutto, tempoRimasto):
		self.ristampaMake(world)
		if(flag == 0):  
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/impasto.png')
			rect_pizzaVuota = surf_pizzaVuota.get_rect()
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif (flag == 1):
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/marinara.png')
			rect_pizzaVuota = surf_pizzaVuota.get_rect()
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif (flag == 2):
			print("fatto")
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/pizzaMargherita.png')
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif ( flag == 3):
			print("fatto")
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/pizze/pizzaSalame.png')
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		
		if dragPomodoro == False and eliminaPomodoro == False :	
			surf_pomodoro=pygame.image.load('Immagini_Gioco/Immagini_Livello/pomodoro.png')
			world.blit(surf_pomodoro, (self.xPomodoro,self.yPomodoro))
		if dragMozzarella == False and eliminaMozzarella == False:	
			surf_mozzarella=pygame.image.load('Immagini_Gioco/Immagini_Livello/mozzarella.png')
			world.blit(surf_mozzarella, (self.xMozz, self.yMozz))
		if dragProsciutto == False and eliminaProsciutto == False:	
			surf_prosciutto=pygame.image.load('Immagini_Gioco/Immagini_Livello/salame2.png')
			world.blit(surf_prosciutto, (self.xSal,self.ySal))
			
		valore = 3000
		appoggio = (valore - int(tempoRimasto)) / 1000
		app =  str(appoggio)
		text =  "TEMPO: " +   app[0:4] 
		print(tempoRimasto)
		world.blit(self.font.render(text, False, (255, 255, 0)) ,(120, 520))	
			
		pygame.display.flip()
		
	def ristampaOlive(self, world, flag, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragProsciutto, eliminaProsciutto, tempoRimasto):
		self.ristampaMake(world)
		if(flag == 0):  
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/impasto.png')
			rect_pizzaVuota = surf_pizzaVuota.get_rect()
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif (flag == 1):
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/marinara.png')
			rect_pizzaVuota = surf_pizzaVuota.get_rect()
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif (flag == 2):
			print("fatto")
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/pizzaMargherita.png')
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif ( flag == 3):
			print("fatto")
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/pizze/pizzaOlive.png')
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		
		if dragPomodoro == False and eliminaPomodoro == False :	
			surf_pomodoro=pygame.image.load('Immagini_Gioco/Immagini_Livello/pomodoro.png')
			world.blit(surf_pomodoro, (self.xPomodoro,self.yPomodoro))
		if dragMozzarella == False and eliminaMozzarella == False:	
			surf_mozzarella=pygame.image.load('Immagini_Gioco/Immagini_Livello/mozzarella.png')
			world.blit(surf_mozzarella, (self.xMozz, self.yMozz))
		if dragProsciutto == False and eliminaProsciutto == False:	
			surf_prosciutto=pygame.image.load('Immagini_Gioco/ingredienti/olivaNera.png')
			world.blit(surf_prosciutto, (self.xSal,self.ySal))
			
		valore = 3000
		appoggio = (valore - int(tempoRimasto)) / 1000
		app =  str(appoggio)
		text =  "TEMPO: " +   app[0:4] 
		print(tempoRimasto)
		world.blit(self.font.render(text, False, (255, 255, 0)) ,(120, 520))	
			
		pygame.display.flip()
		
	def ristampaFunghi(self, world, flag, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragProsciutto, eliminaProsciutto, tempoRimasto):
		self.ristampaMake(world)
		if(flag == 0):  
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/impasto.png')
			rect_pizzaVuota = surf_pizzaVuota.get_rect()
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif (flag == 1):
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/marinara.png')
			rect_pizzaVuota = surf_pizzaVuota.get_rect()
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif (flag == 2):
			print("fatto")
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/pizzaMargherita.png')
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif ( flag == 3):
			print("fatto")
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/pizze/pizzaFunghi.png')
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		
		if dragPomodoro == False and eliminaPomodoro == False :	
			surf_pomodoro=pygame.image.load('Immagini_Gioco/Immagini_Livello/pomodoro.png')
			world.blit(surf_pomodoro, (self.xPomodoro,self.yPomodoro))
		if dragMozzarella == False and eliminaMozzarella == False:	
			surf_mozzarella=pygame.image.load('Immagini_Gioco/Immagini_Livello/mozzarella.png')
			world.blit(surf_mozzarella, (self.xMozz, self.yMozz))
		if dragProsciutto == False and eliminaProsciutto == False:	
			surf_prosciutto=pygame.image.load('Immagini_Gioco/ingredienti/funghetto.png')
			world.blit(surf_prosciutto, (self.xSal,self.ySal))
			
		valore = 3000
		appoggio = (valore - int(tempoRimasto)) / 1000
		app =  str(appoggio)
		text =  "TEMPO: " +   app[0:4] 
		print(tempoRimasto)
		world.blit(self.font.render(text, False, (255, 255, 0)) ,(120, 520))	
			
		pygame.display.flip()
		
			
	def ristampaSalsiccia(self, world, flag, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragProsciutto, eliminaProsciutto, tempoRimasto):
		self.ristampaMake(world)
		if(flag == 0):  
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/impasto.png')
			rect_pizzaVuota = surf_pizzaVuota.get_rect()
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif (flag == 1):
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/marinara.png')
			rect_pizzaVuota = surf_pizzaVuota.get_rect()
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif (flag == 2):
			print("fatto")
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/pizzaMargherita.png')
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif ( flag == 3):
			print("fatto")
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/pizze/pizzaSalsiccia.png')
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		
		if dragPomodoro == False and eliminaPomodoro == False :	
			surf_pomodoro=pygame.image.load('Immagini_Gioco/Immagini_Livello/pomodoro.png')
			world.blit(surf_pomodoro, (self.xPomodoro,self.yPomodoro))
		if dragMozzarella == False and eliminaMozzarella == False:	
			surf_mozzarella=pygame.image.load('Immagini_Gioco/Immagini_Livello/mozzarella.png')
			world.blit(surf_mozzarella, (self.xMozz, self.yMozz))
		if dragProsciutto == False and eliminaProsciutto == False:	
			surf_prosciutto=pygame.image.load('Immagini_Gioco/ingredienti/salsiccia.png')
			world.blit(surf_prosciutto, (self.xSal,self.ySal))
			
		valore = 3000
		appoggio = (valore - int(tempoRimasto)) / 1000
		app =  str(appoggio)
		text =  "TEMPO: " +   app[0:4] 
		print(tempoRimasto)
		world.blit(self.font.render(text, False, (255, 255, 0)) ,(120, 520))	
			
		pygame.display.flip()
		
		
	def ristampaPatata(self, world, flag, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragProsciutto, eliminaProsciutto, tempoRimasto):
		self.ristampaMake(world)
		if(flag == 0):  
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/impasto.png')
			rect_pizzaVuota = surf_pizzaVuota.get_rect()
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif (flag == 1):
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/marinara.png')
			rect_pizzaVuota = surf_pizzaVuota.get_rect()
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif (flag == 2):
			print("fatto")
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/pizzaMargherita.png')
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif ( flag == 3):
			print("fatto")
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/pizze/pizzaAmericana.png')
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		
		if dragPomodoro == False and eliminaPomodoro == False :	
			surf_pomodoro=pygame.image.load('Immagini_Gioco/Immagini_Livello/pomodoro.png')
			world.blit(surf_pomodoro, (self.xPomodoro,self.yPomodoro))
		if dragMozzarella == False and eliminaMozzarella == False:	
			surf_mozzarella=pygame.image.load('Immagini_Gioco/Immagini_Livello/mozzarella.png')
			world.blit(surf_mozzarella, (self.xMozz, self.yMozz))
		if dragProsciutto == False and eliminaProsciutto == False:	
			surf_prosciutto=pygame.image.load('Immagini_Gioco/ingredienti/patata.png')
			world.blit(surf_prosciutto, (self.xSal,self.ySal))
			
		valore = 3000
		appoggio = (valore - int(tempoRimasto)) / 1000
		app =  str(appoggio)
		text =  "TEMPO: " +   app[0:4] 
		print(tempoRimasto)
		world.blit(self.font.render(text, False, (255, 255, 0)) ,(120, 520))	
			
		pygame.display.flip()
		
	def ristampaSalsicciaF(self, world, flag, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragProsciutto, eliminaProsciutto, dragFungo, eliminaFungo, tempoRimasto):
		self.ristampaMake(world)
		if(flag == 0):  
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/impasto.png')
			rect_pizzaVuota = surf_pizzaVuota.get_rect()
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif (flag == 1):
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/marinara.png')
			rect_pizzaVuota = surf_pizzaVuota.get_rect()
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif (flag == 2):
			print("fatto")
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/pizzaMargherita.png')
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif ( flag == 3):
			print("fatto")
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/pizze/pizzaSalsiccia.png')
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif (flag == 4):
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/pizze/pizzaSalsiccia_Funghi.png')
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		
		if dragPomodoro == False and eliminaPomodoro == False :	
			surf_pomodoro=pygame.image.load('Immagini_Gioco/Immagini_Livello/pomodoro.png')
			world.blit(surf_pomodoro, (self.xPomodoro,self.yPomodoro))
		if dragMozzarella == False and eliminaMozzarella == False:	
			surf_mozzarella=pygame.image.load('Immagini_Gioco/Immagini_Livello/mozzarella.png')
			world.blit(surf_mozzarella, (self.xMozz, self.yMozz))
		if dragProsciutto == False and eliminaProsciutto == False:	
			surf_prosciutto=pygame.image.load('Immagini_Gioco/ingredienti/salsiccia.png')
			world.blit(surf_prosciutto, (self.xSal,self.ySal))
		if dragFungo == False and eliminaFungo == False:	
			surf_fun=pygame.image.load('Immagini_Gioco/ingredienti/funghetto.png')
			world.blit(surf_fun, (self.xFun,self.yFun))
			
		valore = 4000
		appoggio = (valore - int(tempoRimasto)) / 1000
		app =  str(appoggio)
		text =  "TEMPO: " +   app[0:4] 
		print(tempoRimasto)
		world.blit(self.font.render(text, False, (255, 255, 0)) ,(120, 520))	
			
		pygame.display.flip()
		
	def ristampaOP(self, world, flag, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragProsciutto, eliminaProsciutto, dragFungo, eliminaFungo, tempoRimasto):
		self.ristampaMake(world)
		if(flag == 0):  
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/impasto.png')
			rect_pizzaVuota = surf_pizzaVuota.get_rect()
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif (flag == 1):
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/marinara.png')
			rect_pizzaVuota = surf_pizzaVuota.get_rect()
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif (flag == 2):
			print("fatto")
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/pizzaMargherita.png')
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif ( flag == 3):
			print("fatto")
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/pizze/pizzaOlive.png')
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif (flag == 4):
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/pizze/pizzaProsciutto_Olive.png')
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		
		if dragPomodoro == False and eliminaPomodoro == False :	
			surf_pomodoro=pygame.image.load('Immagini_Gioco/Immagini_Livello/pomodoro.png')
			world.blit(surf_pomodoro, (self.xPomodoro,self.yPomodoro))
		if dragMozzarella == False and eliminaMozzarella == False:	
			surf_mozzarella=pygame.image.load('Immagini_Gioco/Immagini_Livello/mozzarella.png')
			world.blit(surf_mozzarella, (self.xMozz, self.yMozz))
		if dragProsciutto == False and eliminaProsciutto == False:	
			surf_prosciutto=pygame.image.load('Immagini_Gioco/ingredienti/olivaNera.png')
			world.blit(surf_prosciutto, (self.xSal,self.ySal))
		if dragFungo == False and eliminaFungo == False:	
			surf_fun=pygame.image.load('Immagini_Gioco/ingredienti/prosciuttone.png')
			world.blit(surf_fun, (self.xFun,self.yFun))
			
		valore = 4000
		appoggio = (valore - int(tempoRimasto)) / 1000
		app =  str(appoggio)
		text =  "TEMPO: " +   app[0:4] 
		print(tempoRimasto)
		world.blit(self.font.render(text, False, (255, 255, 0)) ,(120, 520))	
			
		pygame.display.flip()
		
	def ristampaQuat(self, world, flag, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella, dragProsciutto, eliminaProsciutto, dragFungo, eliminaFungo, dragCarciofo, eliminaCarciofo, tempoRimasto):
		self.ristampaMake(world)
		if(flag == 0):  
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/impasto.png')
			rect_pizzaVuota = surf_pizzaVuota.get_rect()
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif (flag == 1):
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/marinara.png')
			rect_pizzaVuota = surf_pizzaVuota.get_rect()
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif (flag == 2):
			print("fatto")
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/pizzaMargherita.png')
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif ( flag == 3):
			print("fatto")
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/pizze/pizzaOlive.png')
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif (flag == 4):
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/pizze/pizzaProsciutto_Olive.png')
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		elif (flag == 5):
			surf_pizzaVuota=pygame.image.load('Immagini_Gioco/pizze/pizzaQuattroStagioni.png')
			world.blit(surf_pizzaVuota, (self.xImpasto, self.yImpasto))
		
		if dragPomodoro == False and eliminaPomodoro == False :	
			surf_pomodoro=pygame.image.load('Immagini_Gioco/Immagini_Livello/pomodoro.png')
			world.blit(surf_pomodoro, (self.xPomodoro,self.yPomodoro))
		if dragMozzarella == False and eliminaMozzarella == False:	
			surf_mozzarella=pygame.image.load('Immagini_Gioco/Immagini_Livello/mozzarella.png')
			world.blit(surf_mozzarella, (self.xMozz, self.yMozz))
		if dragProsciutto == False and eliminaProsciutto == False:	
			surf_prosciutto=pygame.image.load('Immagini_Gioco/ingredienti/olivaNera.png')
			world.blit(surf_prosciutto, (self.xSal,self.ySal))
		if dragFungo == False and eliminaFungo == False:	
			surf_fun=pygame.image.load('Immagini_Gioco/ingredienti/prosciuttone.png')
			world.blit(surf_fun, (self.xFun,self.yFun))
		if dragCarciofo == False and eliminaCarciofo == False:	
			surf_fun=pygame.image.load('Immagini_Gioco/ingredienti/carciofino.png')
			world.blit(surf_fun, (self.xcar,self.ycar))
			
		valore = 5000
		appoggio = (valore - int(tempoRimasto)) / 1000
		app =  str(appoggio)
		text =  "TEMPO: " +   app[0:4] 
		print(tempoRimasto)
		world.blit(self.font.render(text, False, (255, 255, 0)) ,(120, 520))	
			
		pygame.display.flip()
