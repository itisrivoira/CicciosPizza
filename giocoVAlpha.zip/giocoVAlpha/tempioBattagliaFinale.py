import pygame, sys
import pygame_menu #libreria di pygame che permette una facile creazione del main menu di gioco
from pygame_menu import sound
from pygame.locals import *
import mappaLivelli
import time, datetime
import crazyPalace
import classPG
import Camminata
import Player
import gestioneCitta
import dialoghiNPC_secondari
import cittaLocaleTombolone
import turnoPlayer
import stradaPerTempio
import random


miaArea = gestioneCitta.areaCiccios("Immagini_Gioco/ULTIMO_LIVELLO/stanzaSigillo.jpg")
camminiamo = Camminata.Camminata()
player = Player.Player(camminiamo.getUpPath(), 550, 780)
#player = Player.Player(camminiamo.getUpPath(), 550, 780)
flagColl = 0
dialogo = dialoghiNPC_secondari.Dialogo()
arrayAnimazione = [pygame.image.load("Immagini_Gioco/ULTIMO_LIVELLO/stanzaSigillo.jpg"), pygame.image.load("Immagini_Gioco/ULTIMO_LIVELLO/flash1.jpg"), pygame.image.load("Immagini_Gioco/ULTIMO_LIVELLO/flash2.jpg"), pygame.image.load("Immagini_Gioco/ULTIMO_LIVELLO/arrivo1.jpg"), pygame.image.load("Immagini_Gioco/ULTIMO_LIVELLO/arrivo2.jpg")]
screen_shake = 0
WINDOW_SIZE = (1280,920)
display = pygame.Surface((1280,920))
finitaVibr = 0
finitaAni = 0

def colonnaSonora(volume):

	print("Ok")
	pygame.mixer.music.load("Suoni/discesaPizza.ogg")
	pygame.mixer.music.play(-1)   #play della colonna sonora -1 ---> indica per tempo infinito
	pygame.mixer.music.set_volume(volume)		
	

def ristampaMovi(world, x, y):
	
	path_stampa = camminiamo.ristampaMovi()
	surf_posizione= pygame.image.load(path_stampa)
	world.blit(surf_posizione, (x,y))
	return path_stampa
	
	
def ristampa(world, x, y, PATH, player, i= 0, monstro = 0):

	print(i)
	if (i >= 5):
		i = 0
		print(i)

	world.blit(arrayAnimazione[i], (0, 0))	
	time.sleep(0.06)
	
	if(monstro == 1):
		world.blit(pygame.image.load("Immagini_Gioco/ULTIMO_LIVELLO/vuota.jpg") , (0,0))
		world.blit(pygame.image.load("Immagini_Gioco/ULTIMO_LIVELLO/pizzaAnanasG.png") , (325,35))

	surf_Player=pygame.image.load(PATH)
	world.blit(surf_Player, (600,580))	
	world.blit(pygame.image.load("Immagini_Gioco/ULTIMO_LIVELLO/ciccioObMorto.png"), (800, 600))	
	
def stampaMostro(world, PATH):
	global finitaAni
	x = 325
	y = -330
	ripeti = True
	while ripeti:
		print("yo")
		world.blit(pygame.image.load("Immagini_Gioco/ULTIMO_LIVELLO/vuota.jpg") , (0,0))
		world.blit(pygame.image.load("Immagini_Gioco/ULTIMO_LIVELLO/pizzaAnanasG.png") , (x,y))
		surf_Player=pygame.image.load(PATH)
		world.blit(surf_Player, (600,580))
		shake(world)
		pygame.display.flip()
		y = y + 20
		time.sleep(0.1)
		if( y >= 35 ):
			ripeti = False
			finitaAni = 1
	
def shake(world):
	screen_shake = 30
	if screen_shake > 0:
		screen_shake -= 1
			
	render_offset = [ 0, 0 ]
	if screen_shake: 
		render_offset[0] = random.randint(0, 20) - 1
		render_offset[1] = random.randint(0, 20) - 1
        
	world.blit(pygame.transform.scale(world,WINDOW_SIZE), render_offset)
	pygame.display.update()

def main(player, inventario):
	global flagColl, finitaVibr, finitaAni
	
	
	pygame.init()
	colonnaSonora(1)
	worldx = 1280
	worldy = 920
	fps = 40
	ani = 4
	world = pygame.display.set_mode((worldx, worldy))
	#backdrop = pygame.image.load("Immagini_Gioco/background_menu/rossa2.jpg").convert()
	clock = pygame.time.Clock()
	#backdropbox = world.get_rect()
	main = True
	muovix = 0

	#player = Player()  # spawn player
	#player.rect.x = 0  # go to x
	#player.rect.y = 0  # go to y
	steps = 10
	
	vibrazione = 0
	i = 0

	world.blit(miaArea.getSurfArea(), (0, 0))

	
	nuovaPoz = camminiamo.getUpPath()	
	player.settaPoz(world, 600, 580)
	world.blit(player.getSurfPlayer(), (600,580))
	player.padella = "base"
	screen_shake = 0
	risultato = 0
	player.PP = 1000
	player.HP = 1000
	
	
	
	world.blit(pygame.image.load("Immagini_Gioco/ULTIMO_LIVELLO/ciccioObMorto.png"), (800, 600))	
	
	pygame.key.set_repeat(27,27)
	pygame.display.flip()
	
	time.sleep(10)
	
	clock1 = pygame.time.Clock()
	clock2 = pygame.time.Clock()
	
	while main:
		shaking = clock2.tick()
		screen_shake = 30
		print(player.rect_player.x)
		clock1.tick(27)
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				sys.exit()
			elif event.type == pygame.MOUSEBUTTONDOWN:
				click = event.pos
				print(click)
				
						
			
		if (vibrazione <= 12000):
			vibrazione = shaking + vibrazione
			shake(world)
			i += 1
		else:
			finitaVibr = 1

		if i > 5:
			i = 0
		ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player, i)
		
		if(finitaVibr == 1):
			if(finitaAni != 1):
				stampaMostro(world,  nuovaPoz)
		
			ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player, i, 1)	
			time.sleep(4)
			risultato = turnoPlayer.main(player, "pizza")	
			main = False	
			sys.exit()
			print("Lopez")		
		pygame.display.flip()
			
#main()

