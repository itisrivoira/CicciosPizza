import pygame
import pygame, sys #libreria di pygame che permette una facile creazione del main menu di gioco
from pygame.locals import *


class PiumaAtt():
	
	def __init__(self, x, y, idd, colorePiuma):
		self.surf_Piuma = colorePiuma
		self.rect_Piuma = self.surf_Piuma.get_rect()		
		self.rect_Piuma.move_ip(x, y)
		self.surf_PiumaId = idd
		
	def getRectPiuma(self):
		return self.rect_Piuma
		
	def getSurfPiuma(self):
		return self.surf_Piuma
		
	def spostaPiuma(self, x):
		self.rect_Piuma.move_ip((x, 0))

	def spostaPiumaVer(self, y):
		print("questo , " + str(y))
		print(str(self.rect_Piuma.y))
		self.rect_Piuma.move_ip((0, y))
		print("MI SONO MOSSA HA " + str(self.rect_Piuma.x) + str(self.rect_Piuma.y))
		
	def getId(self):
		return self.surf_PiumaId	
		
	def spostaObli(self, x, y):
		self.rect_Piuma.move_ip(x, y)
			
			
class PiumaAttV():

	def __init__(self, x, y, idd, colorePiuma):
		self.surf_Piuma =  colorePiuma
		self.rect_Piuma = self.surf_Piuma.get_rect()		
		self.rect_Piuma.move_ip(x, y)
		self.surf_PiumaId = idd
		
	def getRectPiuma(self):
		return self.rect_Piuma
		
	def getSurfPiuma(self):
		return self.surf_Piuma
		
	def spostaPiuma(self, y):
		self.rect_Piuma.move_ip(0, y)
		
	def getId(self):
		return self.surf_PiumaId	
		
		
class PiumaAttObli():

	def __init__(self, x, y, idd, colorePiuma):
		self.surf_Piuma = colorePiuma
		self.rect_Piuma = self.surf_Piuma.get_rect()		
		self.rect_Piuma.move_ip(x, y)
		self.surf_PiumaId = idd
		
	def getRectPiuma(self):
		return self.rect_Piuma
		
	def getSurfPiuma(self):
		return self.surf_Piuma
		
	def spostaPiuma(self, y):
		self.rect_Piuma.move_ip(0, y)
		
	def getId(self):
		return self.surf_PiumaId
		
	def setta_x(self, val):
 		self.rect_Piuma.x = self.rect_Piuma.x - val
 		
	def setta_y(self, val):
		self.rect_Piuma.y = self.rect_Piuma.y - val
		
	def risettaPosizioneIniziale(self, x, y):
		self.rect_Piuma.x = x
		self.rect_Piuma.y = y
		
class PiumaAttObliSx():

	def __init__(self, x, y, idd, colorePiuma):
		self.surf_Piuma = colorePiuma
		self.rect_Piuma = self.surf_Piuma.get_rect()		
		self.rect_Piuma.move_ip(x, y)
		self.surf_PiumaId = idd
		
	def getRectPiuma(self):
		return self.rect_Piuma
		
	def getSurfPiuma(self):
		return self.surf_Piuma
		
	def spostaPiuma(self, y):
		self.rect_Piuma.move_ip(0, y)
		
	def getId(self):
		return self.surf_PiumaId
		
	def setta_x(self, val):
 		self.rect_Piuma.x = self.rect_Piuma.x + val
 		
	def setta_y(self, val):
		self.rect_Piuma.y = self.rect_Piuma.y - val
		
	def risettaPosizioneIniziale(self, x, y):
		self.rect_Piuma.x = x
		self.rect_Piuma.y = y
		
class PiumaAttObliUP():

	def __init__(self, x, y, idd, colorePiuma):
		self.surf_Piuma = colorePiuma
		self.rect_Piuma = self.surf_Piuma.get_rect()		
		self.rect_Piuma.move_ip(x, y)
		self.surf_PiumaId = idd
		
	def getRectPiuma(self):
		return self.rect_Piuma
		
	def getSurfPiuma(self):
		return self.surf_Piuma
		
	def spostaPiuma(self, y):
		self.rect_Piuma.move_ip(0, y)
		
	def getId(self):
		return self.surf_PiumaId
		
	def setta_x(self, val):
 		self.rect_Piuma.x = self.rect_Piuma.x + val
 		
	def setta_y(self, val):
		self.rect_Piuma.y = self.rect_Piuma.y + val
		
	def risettaPosizioneIniziale(self, x, y):
		self.rect_Piuma.x = x
		self.rect_Piuma.y = y
		
class PiumaAttObliDOWN():

	def __init__(self, x, y, idd, colorePiuma):
		self.surf_Piuma =  colorePiuma
		self.rect_Piuma = self.surf_Piuma.get_rect()		
		self.rect_Piuma.move_ip(x, y)
		self.surf_PiumaId = idd
		
	def getRectPiuma(self):
		return self.rect_Piuma
		
	def getSurfPiuma(self):
		return self.surf_Piuma
		
	def spostaPiuma(self, y):
		self.rect_Piuma.move_ip(0, y)
		
	def getId(self):
		return self.surf_PiumaId
		
	def setta_x(self, val):
 		self.rect_Piuma.x = self.rect_Piuma.x - val
 		
	def setta_y(self, val):
		self.rect_Piuma.y = self.rect_Piuma.y + val
		
	def risettaPosizioneIniziale(self, x, y):
		self.rect_Piuma.x = x
		self.rect_Piuma.y = y
