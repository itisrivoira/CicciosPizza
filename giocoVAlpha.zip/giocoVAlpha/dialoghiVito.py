import pygame
import time

class DialoghiVito():

	def __init__(self):
		pygame.font.init()
		self.interazioni = 0
		self.surf_next= pygame.image.load("Immagini_Gioco/ImmaginiMappa/next.png")
		self.rect_next = self.surf_next.get_rect()
		self.surf_dialogBox = pygame.image.load("Immagini_Gioco/DialoghiNPC/npc_secondari/dialogBase.jpg")
		self.text = ""
		self.fontVito = pygame.font.Font('Immagini_Gioco/DialoghiNPC/fontDialoghi/vito/vitoFont.ttf', 27, bold=True)
		self.immagineVito = pygame.image.load("Immagini_Gioco/DialoghiNPC/vito/vito.png")
		self.dialogo0controllo = False
		
		
	def stampaDialoghi(self, world, numeroDialogo):
			contatoreNext = 0
			self.settaText(numeroDialogo, contatoreNext)
			#textSurface = self.fontVito.render(self.text, False, (0, 0, 0))
			ciclo = True
			world.blit(self.surf_dialogBox, (30, 600))	
			world.blit(self.immagineVito, (5, 630))
			descriptioncounter = 0   
			for x in self.text:
				descriptioncounter += 0.5
				world.blit(self.fontVito.render(x, False, (0, 255, 0)) ,(230,630+75*descriptioncounter))
			descriptioncounter = 0  
			#if(self.dialogo0controllo == False):
			self.rect_next.x = 1000
			self.rect_next.y = 800
			world.blit(self.surf_next, (1000, 800))
			pygame.display.flip()  		
			
			while ciclo:
				
					events = pygame.event.get() #lista eventi di una finestra
					for event in events:
						if event.type == pygame.QUIT:
							pygame.quit()
							
						elif event.type == pygame.MOUSEBUTTONDOWN:
							click = event.pos
							
							if(numeroDialogo == 0):
								if(contatoreNext != 3):

									if self.rect_next.collidepoint(click) and event.button==1:
										contatoreNext += 1
										if(contatoreNext == 1):
											self.ristampa(world)
											self.settaText(numeroDialogo, contatoreNext)
											descriptioncounter = 0 
											for x in self.text:
												descriptioncounter += 0.5
												world.blit(self.fontVito.render(x, False, (0, 255, 0)) ,(250,630+75*descriptioncounter))
											descriptioncounter = 0  
											world.blit(self.surf_next, (1000, 800))
											pygame.display.flip()  	
										elif(contatoreNext == 2):
											self.ristampa(world)
											self.settaText(numeroDialogo, contatoreNext)
											descriptioncounter = 0 
											for x in self.text:
												descriptioncounter += 0.5
												world.blit(self.fontVito.render(x, False, (0, 255, 0)) ,(250,600+75*descriptioncounter))
											descriptioncounter = 0  
											world.blit(self.surf_next, (1000, 800))
											pygame.display.flip()  
								else:
									ciclo = False
							elif(numeroDialogo == 1):
								#print("qua dialogo con consegna padella")


								if self.rect_next.collidepoint(click) and event.button==1:
									contatoreNext += 1
									if(contatoreNext == 1):
										self.ristampa(world)
										self.settaText(numeroDialogo, contatoreNext)
										descriptioncounter = 0 
										for x in self.text:
											descriptioncounter += 0.5
											world.blit(self.fontVito.render(x, False, (0, 255, 0)) ,(250,630+75*descriptioncounter))
										descriptioncounter = 0  
										world.blit(self.surf_next, (1000, 800))
										world.blit(pygame.image.load("Immagini_Gioco/INVENTARIO/padellaFiamma.png"), (600, 650))
										pygame.display.flip()  	

								if(contatoreNext == 2):
									ciclo = False
							elif (numeroDialogo == 3):
								if self.rect_next.collidepoint(click) and event.button==1:
									contatoreNext += 1  	
								if(contatoreNext == 1):
									ciclo = False	
								 	

					
	def settaText(self, numDialog, contatore, flag = 0):
		if(numDialog == 0):
			if(contatore == 0):
				#self.text = "VITO:    BELLA RAGA"
				self.text =["BUONGIORNO , IL MIO NOME E' VITO!","Tu devi essere il novellino che ha fatto domanda per diventare un pizzaiolo di Ciccio's Pizza.","Orbene, direi che ora posso spiegarti come funzionano le cose qui."]
			elif (contatore == 1):
				
				self.text = ["Questa Pizzeria e' stata fondata moltissimi anni fa dal leggendario Ciccio .", "Molti aspiranti pizzaioli provenienti da ogni angoli di Arivoir, la nostra terra ,",  "cercano di emulare le sue gesta.", "Tu se sei qui sei uno di loro, ma prima di essere assunto devi superare delle prove . ", "La vedi quella lavagna in alto a destra ?"]
			elif (contatore == 2):
				self.text = ["Perfetto !", "Avvicinati e premi il tasto invio, da li potrai scegliere tra le cinque sfide da superare " , "per essere assunto nel locale.", "Ricorda una volta completata una sfida torna a parlarmi !", "Se avrai completato la sfida in un buon tempo di riconpensero ! ", "Non mi resta che augurarti BUONA FORTUNA !"]
		elif(numDialog == 1):
			if contatore == 0:
				self.text = ["Complimenti sei stato una scheggia !!!", "Visto che sei stato cosi bravo ti riconpenserò con questa padella !", "Vedi qui in Ciccio's Pizza per fare una determinata pizza serve l'apposita padella !.", "Continua cosi è diventerai senza dubbio un ottimo pizzaiolo !"]
			elif contatore == 1:
				self.text = ["ECCO A TE FANNE BUON USO !!!"]
		elif (numDialog == 3):
			self.text =["Grazie Novellino hai recuperato tutte le padelle ! ", "Ora va a riposarti ci vediamo domani !"]
	def ristampa(self, world):				
		world.blit(self.surf_dialogBox, (30, 600))	
		world.blit(self.immagineVito, (5, 630))	
		
		
	
			
	
		
