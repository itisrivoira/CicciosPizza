

class Tempo():


	def __init__(self):
		self.setTimer = 1000

		
	def diminuisci(self):
		if(self.setTimer != 0):
			self.setTimer = self.setTimer - 1
		
	def getTimer(self):
		return self.setTimer
		
		

