import pygame, sys
import pygame_menu #libreria di pygame che permette una facile creazione del main menu di gioco
from pygame_menu import sound
from pygame.locals import *
import mappaLivelli
import citta1
import Camminata
import classPG
import cittaFiera

'''
Variables

'''

camminiamo = Camminata.Camminata()
flag = 0


box1 = "Immagini_Gioco/HUB/onlyLevel4/dialogBox1.jpg"
box2 = "Immagini_Gioco/HUB/onlyLevel4/dialogBox2.jpg"
box3 = "Immagini_Gioco/HUB/onlyLevel4/dialogBox3.jpg"
box4 = "Immagini_Gioco/HUB/onlyLevel4/dialogBox4.jpg"
box5 = "Immagini_Gioco/HUB/onlyLevel4/dialogBox5.jpg"
box6 = "Immagini_Gioco/HUB/onlyLevel4/dialogBox6.jpg"

personaggioTimer = classPG.Personaggio()



#def crea_stanza():
#	print("cristo")
#	surf_background = pygame.image.load("Immagini_Gioco/HUB/pavimentociccio.png").convert()
#	world.blit(surf_background, (0, 0))
#	pygame.display.flip()

def ristampaMovi(world, x, y):
	
	path_stampa = camminiamo.ristampaMovi()
	surf_posizione= pygame.image.load(path_stampa)
	world.blit(surf_posizione, (x,y))
	return path_stampa

		
def gameOver(world):
	surf_perso = pygame.image.load("Immagini_Gioco/Immagini_Livello/gameover.png")
	world.blit(surf_perso, (0, 0))
	surf_menu= pygame.image.load("Immagini_Gioco/Immagini_Livello/menu.png")
	rect_menu = surf_menu.get_rect()
	x=1050  
	y=700  
	rect_menu.move_ip(x, y)
	world.blit(surf_menu, (x,y))
	pygame.display.flip()
	
	DONE=False
	while not DONE:

		
		events = pygame.event.get() #lista eventi di una finestra
		for event in events:
			if event.type == pygame.QUIT:
				pygame.quit()
		        
			elif event.type == pygame.MOUSEBUTTONDOWN:
				click = event.pos

				if rect_menu.collidepoint(click) and event.button==1:
					DONE = True
				
	
def dialogeVito(world, box):
	global box2
	box2
	surf_dialoge = pygame.image.load(box)
	rect_dialoge = surf_dialoge.get_rect()
	xDia=30  
	yDia=600  
	rect_dialoge.move_ip(xDia, yDia) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_dialoge, (xDia,yDia))	
		
	surf_next= pygame.image.load("Immagini_Gioco/ImmaginiMappa/next.png")
	rect_next= surf_next.get_rect()
	x=1000
	y=800  
	rect_next.move_ip(x, y)
	world.blit(surf_next, (x,y))
	
	pygame.display.flip()
	
	DONE=False
	while not DONE:

		
		events = pygame.event.get() #lista eventi di una finestra
		for event in events:
			if event.type == pygame.QUIT:
				pygame.quit()
		        
			elif event.type == pygame.MOUSEBUTTONDOWN:
				click = event.pos

				if rect_next.collidepoint(click) and event.button==1:
					DONE = True
					
	dialogeVito2(world, box2)
	
def dialogeVito2(world, box):
	global box3
	box3
	surf_dialoge = pygame.image.load(box2)
	rect_dialoge = surf_dialoge.get_rect()
	xDia=30  
	yDia=600  
	rect_dialoge.move_ip(xDia, yDia) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_dialoge, (xDia,yDia))	
		
	surf_next= pygame.image.load("Immagini_Gioco/ImmaginiMappa/next.png")
	rect_next= surf_next.get_rect()
	x=1000
	y=800  
	rect_next.move_ip(x, y)
	world.blit(surf_next, (x,y))
	
	pygame.display.flip()
	
	DONE=False
	while not DONE:

		
		events = pygame.event.get() #lista eventi di una finestra
		for event in events:
			if event.type == pygame.QUIT:
				pygame.quit()
		        
			elif event.type == pygame.MOUSEBUTTONDOWN:
				click = event.pos

				if rect_next.collidepoint(click) and event.button==1:
					DONE = True
	dialogeVito3(world, box3)

def dialogeVito3(world, box):
	global box4
	box4
	surf_dialoge = pygame.image.load(box)
	rect_dialoge = surf_dialoge.get_rect()
	xDia=30  
	yDia=600  
	rect_dialoge.move_ip(xDia, yDia) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_dialoge, (xDia,yDia))	
		
	surf_next= pygame.image.load("Immagini_Gioco/ImmaginiMappa/next.png")
	rect_next= surf_next.get_rect()
	x=1000
	y=800  
	rect_next.move_ip(x, y)
	world.blit(surf_next, (x,y))
	
	pygame.display.flip()
	
	DONE=False
	while not DONE:

		
		events = pygame.event.get() #lista eventi di una finestra
		for event in events:
			if event.type == pygame.QUIT:
				pygame.quit()
		        
			elif event.type == pygame.MOUSEBUTTONDOWN:
				click = event.pos

				if rect_next.collidepoint(click) and event.button==1:
					DONE = True
	dialogeVito4(world, box4)
					
					
def dialogeVito4(world, box):
	global box5
	box5
	surf_dialoge = pygame.image.load(box)
	rect_dialoge = surf_dialoge.get_rect()
	xDia=30  
	yDia=600  
	rect_dialoge.move_ip(xDia, yDia) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_dialoge, (xDia,yDia))	
		
	surf_next= pygame.image.load("Immagini_Gioco/ImmaginiMappa/next.png")
	rect_next= surf_next.get_rect()
	x=1000
	y=800  
	rect_next.move_ip(x, y)
	world.blit(surf_next, (x,y))
	
	pygame.display.flip()
	
	DONE=False
	while not DONE:

		
		events = pygame.event.get() #lista eventi di una finestra
		for event in events:
			if event.type == pygame.QUIT:
				pygame.quit()
		        
			elif event.type == pygame.MOUSEBUTTONDOWN:
				click = event.pos

				if rect_next.collidepoint(click) and event.button==1:
					DONE = True
	dialogeVito5(world, box5)
					
def dialogeVito5(world, box):
	global box5
	box5
	surf_dialoge = pygame.image.load(box)
	rect_dialoge = surf_dialoge.get_rect()
	xDia=30  
	yDia=600  
	rect_dialoge.move_ip(xDia, yDia) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_dialoge, (xDia,yDia))	
		
	surf_next= pygame.image.load("Immagini_Gioco/ImmaginiMappa/next.png")
	rect_next= surf_next.get_rect()
	x=1000
	y=800  
	rect_next.move_ip(x, y)
	world.blit(surf_next, (x,y))
	
	pygame.display.flip()
	
	DONE=False
	while not DONE:

		
		events = pygame.event.get() #lista eventi di una finestra
		for event in events:
			if event.type == pygame.QUIT:
				pygame.quit()
		        
			elif event.type == pygame.MOUSEBUTTONDOWN:
				click = event.pos

				if rect_next.collidepoint(click) and event.button==1:
					DONE = True

					
def dialogeVito6(world, box):
	surf_dialoge = pygame.image.load(box)
	rect_dialoge = surf_dialoge.get_rect()
	xDia=30  
	yDia=600  
	rect_dialoge.move_ip(xDia, yDia) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_dialoge, (xDia,yDia))	
		
	surf_next= pygame.image.load("Immagini_Gioco/ImmaginiMappa/next.png")
	rect_next= surf_next.get_rect()
	x=1000
	y=800  
	rect_next.move_ip(x, y)
	world.blit(surf_next, (x,y))
	
	pygame.display.flip()
	
	DONE=False
	while not DONE:

		
		events = pygame.event.get() #lista eventi di una finestra
		for event in events:
			if event.type == pygame.QUIT:
				pygame.quit()
		        
			elif event.type == pygame.MOUSEBUTTONDOWN:
				click = event.pos

				if rect_next.collidepoint(click) and event.button==1:
					DONE = True
					
					
						

def ristampa(world, x, y, PATH, player ):

	surf_background = pygame.image.load("Immagini_Gioco/HUB/pavimentociccio.png").convert()
	world.blit(surf_background, (0, 0))
	
	surf_livelli=pygame.image.load("Immagini_Gioco/HUB/mappaLivelli.png")
	rect_livelli = surf_livelli.get_rect()
	xLvl=1000 
	yLvl=80 
	rect_livelli.move_ip(xLvl, yLvl) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_livelli, (xLvl,yLvl))
	
	
	surf_bancone=pygame.image.load("Immagini_Gioco/HUB/banconeVito.png")
	rect_bancone = surf_bancone.get_rect()
	xVito=300  
	yVito=50  
	rect_bancone.move_ip(xVito, yVito) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_bancone, (xVito,yVito))
	
	surf_tavoli=pygame.image.load("Immagini_Gioco/HUB/tavoloConPizza.png")
	rect_tavoli = surf_tavoli.get_rect()
	xTav=100
	yTav=700  
	rect_tavoli.move_ip(xTav, yTav) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_tavoli, (xTav,yTav))
	
	surf_tavoli2=pygame.image.load("Immagini_Gioco/HUB/tavoloConPizza.png")
	rect_tavoli2 = surf_tavoli2.get_rect()
	xTav2=320
	yTav2=700  
	rect_tavoli2.move_ip(xTav, yTav) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_tavoli2, (xTav2,yTav2))
	
	surf_tavoli3=pygame.image.load("Immagini_Gioco/HUB/tavoloConPizza.png")
	rect_tavoli3 = surf_tavoli3.get_rect()
	xTav3=100
	yTav3=500  
	rect_tavoli3.move_ip(xTav3, yTav3) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_tavoli3, (xTav3,yTav3))

	surf_tavoli4=pygame.image.load("Immagini_Gioco/HUB/tavoloConPizza.png")
	rect_tavoli4 = surf_tavoli4.get_rect()
	xTav4=320
	yTav4=500  
	rect_tavoli4.move_ip(xTav4, yTav4) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_tavoli4, (xTav4,yTav4))
	
	surf_forno=pygame.image.load("Immagini_Gioco/HUB/forno3.png")
	rect_forno = surf_forno.get_rect()
	xFor=25
	yFor=0  
	rect_forno.move_ip(xFor, yFor) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_forno, (xFor,yFor))	

	surf_area=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/cambiaArea.jpg")
	rect_area = surf_area.get_rect()
	xA=580  
	yA=810   
	rect_area.move_ip(xA, yA) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_area, (xA,yA))
	#pygame.draw.rect(world, (255,0,0), rect_chef) 
	surf_Player=pygame.image.load(PATH)
	world.blit(surf_Player, (x,y))
	rect_vito = pygame.Rect((560, 220), (100, 100))
	#pygame.draw.rect(world, (0,0,255), player.rect_player ) 
	#pygame.draw.rect(world, (1,0,0), rect_vito ) 


	

	
	
		
def main(colonna, player, inventario):	
	#pygame.init()
	worldx = 1280
	worldy = 920
	fps = 40
	ani = 4
	world = pygame.display.set_mode((worldx, worldy))
	global flag
	flag
	#backdrop = pygame.image.load("Immagini_Gioco/background_menu/rossa2.jpg").convert()
	clock = pygame.time.Clock()
	#backdropbox = world.get_rect()
	main = True
	muovix = 0

	#player = Player()  # spawn player
	#player.rect.x = 0  # go to x
	#player.rect.y = 0  # go to y
	steps = 10


	surf_background = pygame.image.load("Immagini_Gioco/HUB/pavimentociccio.png").convert()
	world.blit(surf_background, (0, 0))

	surf_bancone=pygame.image.load("Immagini_Gioco/HUB/banconeVito.png")
	rect_bancone = surf_bancone.get_rect()
	xVito=300 
	yVito=50  
	rect_bancone.move_ip(xVito, yVito) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_bancone, (xVito,yVito))

	surf_livelli=pygame.image.load("Immagini_Gioco/HUB/mappaLivelli.png")
	rect_livelli = surf_livelli.get_rect()
	xLvl=1000 
	yLvl=100  
	rect_livelli.move_ip(xLvl, yLvl) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_livelli, (xLvl,yLvl))

	surf_tavoli=pygame.image.load("Immagini_Gioco/HUB/tavoloConPizza.png")
	rect_tavoli = surf_tavoli.get_rect()
	xTav=100
	yTav=700  
	rect_tavoli.move_ip(xTav, yTav) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_tavoli, (xTav,yTav))

	surf_tavoli2=pygame.image.load("Immagini_Gioco/HUB/tavoloConPizza.png")
	rect_tavoli2 = surf_tavoli2.get_rect()
	xTav2=320
	yTav2=700  
	rect_tavoli2.move_ip(xTav2, yTav2) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_tavoli2, (xTav2,yTav2))
		
	surf_tavoli3=pygame.image.load("Immagini_Gioco/HUB/tavoloConPizza.png")
	rect_tavoli3 = surf_tavoli3.get_rect()
	xTav3=100
	yTav3=500  
	rect_tavoli3.move_ip(xTav3, yTav3) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_tavoli3, (xTav3,yTav3))

	surf_tavoli4=pygame.image.load("Immagini_Gioco/HUB/tavoloConPizza.png")
	rect_tavoli4 = surf_tavoli4.get_rect()
	xTav4=320
	yTav4=500  
	rect_tavoli4.move_ip(xTav4, yTav4) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_tavoli4, (xTav4,yTav4))

	surf_forno=pygame.image.load("Immagini_Gioco/HUB/forno3.png")
	rect_forno = surf_forno.get_rect()
	xFor=25
	yFor=0  
	rect_forno.move_ip(xFor, yFor) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_forno, (xFor,yFor))	
	
	surf_area=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/cambiaArea.jpg")
	rect_area = surf_area.get_rect()
	xA=580  
	yA=810  
	rect_area.move_ip(xA, yA) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_area, (xA,yA))

	player.settaPoz(world, 560, 330)
	nuovaPoz = camminiamo.getUpPath()
	world.blit(pygame.image.load(nuovaPoz), (player.getRectPlayer().x , player.getRectPlayer().y))
	
	dialogeVito(world, box1)
	


	ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player)	
	pygame.display.flip()
	pygame.key.set_repeat(27,27)  #serve per lo spostamento
	clock1 = pygame.time.Clock()

	'''
	Main Loop
	'''

	while main:
		#if (player.oca1 == True and player.oca2 == True and player.oca3 == True):
		#	player.oca1 = False
		#	player.oca2 = False 
		#	player.oca3 = False 
		#	player.settaPoz(world, 560, 330)
		#	nuovaPoz = camminiamo.getUpPath()
		#	main = False
		clock1.tick(27)
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				sys.exit()
		        
   
			if event.type == pygame.KEYDOWN:
				if event.key == pygame.K_LEFT:
					x2 = player.getRectPlayer().x - steps
					y2 = player.getRectPlayer().y
					prova = x2 - player.getRectPlayer().x
					prova2 = y2 - player.getRectPlayer().y
					rect_prova = player.getRectPlayer().move(prova, prova2)
					if rect_prova.colliderect(rect_bancone) or rect_prova.colliderect(rect_livelli) or rect_prova.colliderect(rect_tavoli) or rect_prova.colliderect(rect_tavoli2) or rect_prova.colliderect(rect_tavoli3) or rect_prova.colliderect(rect_tavoli4) or rect_prova.colliderect(rect_forno):
						print("non ti muovi")
					else:
						if(rect_prova.x > 10):
							player.setRect(prova, prova2)
							camminiamo.settaLeft()
							nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
							ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player)		
						
				if event.key == pygame.K_RIGHT:
					x2 = player.getRectPlayer().x + steps
					y2 = player.getRectPlayer().y
					prova = x2 - player.getRectPlayer().x
					prova2 = y2 - player.getRectPlayer().y
					rect_prova = player.getRectPlayer().move(prova, prova2)
					if rect_prova.colliderect(rect_bancone) or rect_prova.colliderect(rect_livelli) or rect_prova.colliderect(rect_tavoli) or rect_prova.colliderect(rect_tavoli2) or rect_prova.colliderect(rect_tavoli3) or rect_prova.colliderect(rect_tavoli4) or rect_prova.colliderect(rect_forno):
						print("non ti muovi")
					else:
						if(rect_prova.x < 1180):
							player.setRect(prova, prova2)
							camminiamo.settaRight()
							nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
							ristampa(world, player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player)
					
				if event.key == pygame.K_UP:
					x2 = player.getRectPlayer().x
					y2 = player.getRectPlayer().y - steps
					prova = x2 - player.getRectPlayer().x
					prova2 = y2 - player.getRectPlayer().y
					rect_prova = player.getRectPlayer().move(prova, prova2)
					if rect_prova.colliderect(rect_bancone) or rect_prova.colliderect(rect_livelli) or rect_prova.colliderect(rect_tavoli) or rect_prova.colliderect(rect_tavoli2) or rect_prova.colliderect(rect_tavoli3) or rect_prova.colliderect(rect_tavoli4) or rect_prova.colliderect(rect_forno):
						print("non ti muovi")
					else:
						player.setRect(prova, prova2)
						camminiamo.settaUP()
						nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
						ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player)	
							
								
				if event.key == pygame.K_DOWN:
					x2 = player.getRectPlayer().x
					y2 = player.getRectPlayer().y + steps
					prova = x2 - player.getRectPlayer().x
					prova2 = y2 - player.getRectPlayer().y
					rect_prova = player.getRectPlayer().move(prova, prova2)
					if rect_prova.colliderect(rect_bancone) or rect_prova.colliderect(rect_livelli) or rect_prova.colliderect(rect_tavoli) or rect_prova.colliderect(rect_tavoli2) or rect_prova.colliderect(rect_tavoli3) or rect_prova.colliderect(rect_tavoli4) or rect_prova.colliderect(rect_forno):
						print("non ti muovi")
					else:
						if(rect_prova.y < 800):
							if((player.rect_player.x >= 550 and player.rect_player.x <= 600) and (player.rect_player.y >= 740 and player.rect_player.y <= 780)):
								cittaFiera.main(player, inventario)
								player.setRect(prova, prova2)
								camminiamo.settaUP()
								nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
								ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player)
								if(player.ricominciaDopoSconfitta == True):
									player.ricominciaDopoSconfitta = False
									player.settaPoz(world, 500, 450)
								if (player.oca1 == True and player.oca2 == True and player.oca3 == True):
									main = False
									print("ouuuuuuuuU")
									player.oca1 = False
									player.oca2 = False 
									player.oca3 = False 
									player.settaPoz(world, 560, 330)
									nuovaPoz = camminiamo.getUpPath()
									#main = False
							else:
								player.setRect(prova, prova2)
								camminiamo.settaDOWN()
								nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
								ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player)
							
							
				if event.key == pygame.K_RETURN:
					if((rect_chef.x > 960 and rect_chef.x < 1100) and rect_chef.y == 280):
						posFerma = camminiamo.dialogo()
						print("Non è l'ora di perdere tempo")
						ristampa(world, rect_chef.x, rect_chef.y, -steps, 0, posFerma)
					elif((rect_chef.x > 490 and rect_chef.x < 610) and rect_chef.y == 300):
						posFerma = camminiamo.dialogo()
						print("parliamo con vito")
						dialogeVito6(world, box6)
						ristampa(world, rect_chef.x, rect_chef.y, -steps, 0, posFerma)
				if event.key == pygame.K_ESCAPE:
					main = False
				if event.key == 105:
					inventario.stampaInventario(player, world)
					ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player)
			#if event.type != pygame.KEYDOWN:
			#	print("aaaaaaaa")
			#	posFerma = camminiamo.stand()
			#	ristampa(world, rect_chef.x, rect_chef.y, 0, 0, posFerma)
			#	pygame.display.flip()	
				
		pygame.display.flip()
	
	print("ou111")

	return flag
