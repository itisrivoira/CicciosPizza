import pygame
import Player

class Inventario():

	def __init__(self):	
		self.surf_inventario = pygame.image.load("Immagini_Gioco/INVENTARIO/inventarioGiusto.jpg")
		self.surf_omino = pygame.image.load("Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDOWN/DOWNFERMO.png")
		self.surf_ominoC = pygame.image.load("Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTEDOWN/DOWN1.png")
		self.vita = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/PuntiPizzaSegnale.png")
		self.rect_vita =  pygame.Rect((220,380), (200, 50))
		self.rect_energy =  pygame.Rect((220,480), (200, 50))
		self.pizzaEnergy = pygame.image.load("Immagini_Gioco/INVENTARIO/pizzaEnergy.png")
		self.barraEnergy = pygame.image.load("Immagini_Gioco/INVENTARIO/barraEnergy.png")
		self.ripeti = False
		self.surf_exit = pygame.image.load("Immagini_Gioco/INVENTARIO/exit2.png")
		self.rect_exit =  pygame.Rect((1000, 800), (200, 110))
		self.PP = pygame.image.load("Immagini_Gioco/INVENTARIO/ppMouseOver.png")
		self.PEP = pygame.image.load("Immagini_Gioco/INVENTARIO/pepMouseOver.jpg")
		self.surf_equip = pygame.image.load("Immagini_Gioco/INVENTARIO/equip.png")
		self.rect_equip = pygame.Rect((600, 230), (200, 110))
		self.surf_menuPiz = pygame.image.load("Immagini_Gioco/INVENTARIO/menuPizza.png")
		self.rect_menuPiz = pygame.Rect((960, 180), (200, 110))
		self.surf_option = pygame.image.load("Immagini_Gioco/INVENTARIO/option2.png")
		self.rect_option = pygame.Rect((550, 780), (200, 110))
		self.surf_peng = pygame.image.load("Immagini_Gioco/INVENTARIO/peng.png")
		self.rect_peng = pygame.Rect((1150, 35), (200, 110))
		self.surf_box = pygame.image.load("Immagini_Gioco/INVENTARIO/box.jpg")
		self.rect_box = pygame.Rect((60, 615), (200, 110))
		self.stats = []
		self.font = pygame.font.Font('Immagini_Gioco/DialoghiNPC/fontDialoghi/vito/vitoFont.ttf', 27, bold=True)
		#self.riquadroStats = pygam
		
		##array inventario####
		self.array_padelle = [pygame.image.load("Immagini_Gioco/INVENTARIO/padellaBax.png") ,pygame.image.load("Immagini_Gioco/INVENTARIO/padellaFiamma.png"), pygame.image.load("Immagini_Gioco/INVENTARIO/palonaPizza.png") , pygame.image.load("Immagini_Gioco/INVENTARIO/palaPizzaa.png"),  pygame.image.load("Immagini_Gioco/INVENTARIO/palaSans.png")]
		self.rect_padelle = [pygame.Rect((650, 200), (100, 100)), pygame.Rect((800, 200), (100, 100)), pygame.Rect((1000, 200), (100, 100)), pygame.Rect((650, 400), (100, 100)),  pygame.Rect((870, 400), (100, 100))]
	
	def stampaInventario(self, player, world):
		self.stampa(world, player)
		pygame.display.flip()
		flag = 1
		ripeti = True
		while ripeti:
			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					pygame.quit()
					sys.exit()
				if event.type == pygame.MOUSEBUTTONDOWN:
					click = event.pos
					if self.rect_exit.collidepoint(click) and event.button == 1:
						ripeti = False
					if self.rect_equip.collidepoint(click) and event.button == 1:
						self.paginaEquipaggiamento(world, player)
					if self.rect_menuPiz.collidepoint(click) and event.button == 1:
						print("apro pagina elenco pizze")
					
						
			if self.rect_vita.collidepoint(pygame.mouse.get_pos()):	
				print("OU")
				world.blit(self.PP, (200,200))
				pygame.display.flip()
				
			elif self.rect_energy.collidepoint(pygame.mouse.get_pos()):
				world.blit(self.PEP, (200,300))
				pygame.display.flip()
			else: 
				self.stampa(world, player)
				pygame.display.flip()
					
	
			#pygame.display.flip()
					
		
		
				
	def disabilita(self):
		if (self.ripeti == False):
			self.ripeti == True
		else: 
			self.ripeti == False
			
	def stampa(self, world, player):
		world.fill((0,0,0))
		world.blit(self.surf_inventario, (0,0))
		if(player.HP > ( player.PP / 100) * 50):
			world.blit(self.surf_omino, (220,110))
		else:
			world.blit(self.surf_ominoC, (220,110))
		world.blit(self.surf_box, (self.rect_box.x, self.rect_box.y-300))
		world.blit(player.ritornaPizzaBar(), (175, 372))
		world.blit(self.vita, (75, 422))
		world.blit(self.barraEnergy , (175, 472))
		world.blit(self.surf_exit, (self.rect_exit.x, self.rect_exit.y))	
		world.blit(self.surf_equip, (self.rect_equip.x, self.rect_equip.y))
		world.blit(self.surf_menuPiz, (self.rect_menuPiz.x, self.rect_menuPiz.y))
		world.blit(self.surf_option, (self.rect_option.x, self.rect_option.y))	
		world.blit(self.surf_peng, (self.rect_peng.x, self.rect_peng.y))	
		world.blit(self.surf_box, (self.rect_box.x, self.rect_box.y))
		#world.blit(self.surf_box, (self.rect_box.x, self.rect_box.y-300))
		self.settaStats(player)	
		descriptioncounter = 0   
		for x in self.stats:
			descriptioncounter += 0.5
			world.blit(self.font.render(x, False, (255, 255, 255)) ,(80,620+85*descriptioncounter))
		descriptioncounter = 0  
		#pygame.draw.rect(world, (1,0,0), self.rect_energy ) 	
		#pygame.draw.rect(world, (1,0,0), self.rect_vita ) 	
			
		
	def settaStats(self, player):
		lvl = "LIVELLO PIZZA : " + str(player.lvl) 
		pp = "PUNTI PP MAX: " + str(player.PP) + " / " + str(player.HP)
		pep = "PUNTI PEP MASSIMI: " + str(player.PEP) + " / " + str(player.energy)
		self.stats = [lvl, pp, pep]
		
	def paginaEquipaggiamento(self, world, player):
		ripeti = True 
		while ripeti:
				
			self.ristampaEquipaggiamento(world, player)
			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					pygame.quit()
					sys.exit()
				if event.type == pygame.MOUSEBUTTONDOWN:
					click = event.pos
					if self.rect_padelle[0].collidepoint(click) and event.button == 1:
						player.padella = "base"
						self.ristampaEquipaggiamento(world, player)
					if self.rect_padelle[1].collidepoint(click) and event.button == 1:
						player.padella = "fiamma"
						self.ristampaEquipaggiamento(world, player)
					if self.rect_padelle[2].collidepoint(click) and event.button == 1:
						player.padella = "lunga"
						self.ristampaEquipaggiamento(world, player)
					if self.rect_padelle[3].collidepoint(click) and event.button == 1:
						player.padella = "pala"
						self.ristampaEquipaggiamento(world, player)
					if self.rect_padelle[4].collidepoint(click) and event.button == 1:
						player.padella = "ossa"
						self.ristampaEquipaggiamento(world, player)
					if self.rect_exit.collidepoint(click) and event.button == 1:
						ripeti = False
						
			if self.rect_padelle[0].collidepoint(pygame.mouse.get_pos()) and player.padella != "base" :	
				
				world.blit(pygame.image.load("Immagini_Gioco/INVENTARIO/overBase.jpg"), (200,200))
				pygame.display.flip()
			if self.rect_padelle[1].collidepoint(pygame.mouse.get_pos()) and player.havePadFuoco == True and player.padella != "fiamma" :	
				
				world.blit(pygame.image.load("Immagini_Gioco/INVENTARIO/overFuoco.jpg"), (200,200))
				pygame.display.flip()
			if self.rect_padelle[2].collidepoint(pygame.mouse.get_pos()) and player.havePadLunga == True and player.padella != "lunga":	
				
				world.blit(pygame.image.load("Immagini_Gioco/INVENTARIO/overPalaLunga.jpg"), (200,200))
				pygame.display.flip()
			if self.rect_padelle[3].collidepoint(pygame.mouse.get_pos()) and  player.havePadPala == True and player.padella != "pala":	
				
				world.blit(pygame.image.load("Immagini_Gioco/INVENTARIO/overPalaVito.jpg"), (200,200))
				pygame.display.flip()
			if self.rect_padelle[4].collidepoint(pygame.mouse.get_pos()) and player.havePadOssa == True and player.padella != "ossa":	
				
				world.blit(pygame.image.load("Immagini_Gioco/INVENTARIO/overPalaSans.jpg"), (200,200))
				pygame.display.flip()
			
					
			#world.blit(self.array_padelle[1], self.rect_padelle[0])
		#	pygame.draw.rect(world, (1,0,0), self.rect_padelle[0] ) 
			#world.blit(self.array_padelle[2], self.rect_padelle[1])
		#	pygame.draw.rect(world, (1,0,0), self.rect_padelle[1] ) 
			pygame.display.flip()	
			
			
	def ristampaEquipaggiamento(self, world, player):
		world.fill((0,0,0))
		world.blit(self.surf_inventario, (0,0))	
		world.blit(self.surf_omino, (220,310))
		world.blit(self.surf_box, (self.rect_box.x, self.rect_box.y-100))
		if (player.padella == "base"):
			world.blit(self.array_padelle[0], (self.rect_box.x + 160, self.rect_box.y))
			for i in range(len(self.array_padelle)):
				if i != 0:
					print(player.havePadFuoco)
					if i == 1 and player.havePadFuoco == True:
						world.blit(self.array_padelle[i], self.rect_padelle[i])
					elif i == 2 and player.havePadLunga == True:
						world.blit(self.array_padelle[i], self.rect_padelle[i])
					elif i == 3 and player.havePadPala == True:
						world.blit(self.array_padelle[i], self.rect_padelle[i])
					elif i == 4 and player.havePadOssa == True:
						world.blit(self.array_padelle[i], self.rect_padelle[i])											
				
		elif (player.padella == "fiamma"):
			world.blit(self.array_padelle[1], (self.rect_box.x + 160, self.rect_box.y))
			for i in range(len(self.array_padelle)):
				if i != 1:
					if i == 0 and player.havePadBase == True:
						world.blit(self.array_padelle[i], self.rect_padelle[i])
					elif i == 2 and player.havePadLunga == True:
						world.blit(self.array_padelle[i], self.rect_padelle[i])
					elif i == 3 and player.havePadPala == True:
						world.blit(self.array_padelle[i], self.rect_padelle[i])
					elif i == 4 and player.havePadOssa == True:
						world.blit(self.array_padelle[i], self.rect_padelle[i])	
					#world.blit(self.array_padelle[i], self.rect_padelle[i])
		elif (player.padella == "lunga"):
			world.blit(self.array_padelle[2], (self.rect_box.x + 160, self.rect_box.y))
			for i in range(len(self.array_padelle)):
				if i != 2:
					if i == 0 and player.havePadBase == True:
						world.blit(self.array_padelle[i], self.rect_padelle[i])
					elif i == 1 and player.havePadFuoco == True:
						world.blit(self.array_padelle[i], self.rect_padelle[i])
					elif i == 3 and player.havePadPala == True:
						world.blit(self.array_padelle[i], self.rect_padelle[i])
					elif i == 4 and player.havePadOssa == True:
						world.blit(self.array_padelle[i], self.rect_padelle[i])	
		elif (player.padella == "pala"):
			world.blit(self.array_padelle[3], (self.rect_box.x + 160, self.rect_box.y))
			for i in range(len(self.array_padelle)):
				if i != 3:
					if i == 0 and player.havePadBase == True:
						world.blit(self.array_padelle[i], self.rect_padelle[i])
					elif i == 1 and player.havePadFuoco == True:
						world.blit(self.array_padelle[i], self.rect_padelle[i])
					elif i == 2 and player.havePadLunga == True:
						world.blit(self.array_padelle[i], self.rect_padelle[i])
					elif i == 4 and player.havePadOssa == True:
						world.blit(self.array_padelle[i], self.rect_padelle[i])	
		elif (player.padella == "ossa"):
			world.blit(self.array_padelle[4], (self.rect_box.x + 160, self.rect_box.y))
			for i in range(len(self.array_padelle)):
				if i != 4:
					if i == 0 and player.havePadBase == True:
						world.blit(self.array_padelle[i], self.rect_padelle[i])
					elif i == 1 and player.havePadFuoco == True:
						world.blit(self.array_padelle[i], self.rect_padelle[i])
					elif i == 2 and player.havePadLunga == True:
						world.blit(self.array_padelle[i], self.rect_padelle[i])
					elif i == 3 and player.havePadPala == True:
						world.blit(self.array_padelle[i], self.rect_padelle[i])	
		world.blit(self.surf_exit, (self.rect_exit.x, self.rect_exit.y))
					
					#pygame.draw.rect(world, (1,0,0), self.rect_padelle[i] ) 
		
		
			
		
