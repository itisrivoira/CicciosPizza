import pygame, sys
import pygame_menu #libreria di pygame che permette una facile creazione del main menu di gioco
from pygame_menu import sound
from pygame.locals import *
import mappaLivelli
import time, datetime
import crazyPalace
import classPG
import Camminata
import Player
import gestioneCitta
import dialoghiNPC_secondari
import cittaLocaleTombolone
import turnoPlayer
import stradaPerTempio
import tempioBattagliaFinale
import dialoghiVito


miaArea = gestioneCitta.areaCiccios("Immagini_Gioco/ULTIMO_LIVELLO/stradaPrimaBoss.jpg")
camminiamo = Camminata.Camminata()
#player = Player.Player(camminiamo.getUpPath(), 550, 780)
#player = Player.Player(camminiamo.getUpPath(), 550, 780)
flagColl = 0
dialogo = dialoghiNPC_secondari.Dialogo()
dialogoV = dialoghiVito.DialoghiVito()


def ristampaMovi(world, x, y):
	
	path_stampa = camminiamo.ristampaMovi()
	surf_posizione= pygame.image.load(path_stampa)
	world.blit(surf_posizione, (x,y))
	return path_stampa
	
def settaCollsioni(flagUltimo = ""):
	miaArea.settaCollisione(pygame.Rect((1060, 740), (85, 85))) #rectBosco sopra
	miaArea.settaCollisione(pygame.Rect((610, 890), (45, 45)))
#	miaArea.settaCollisione(pygame.Rect((500, 650), (380, 50)))	#rect Albero in basso destra
#	miaArea.settaCollisione(pygame.Rect((500, 290), (40, 400))) # rect albero in basso sinistra
#	miaArea.settaCollisione(pygame.Rect((430, 370), (100, 210))) # rect albero vicino casa
#	miaArea.settaCollisione(pygame.Rect((550, 258), (300, 110))) # rect tronchetto
#	miaArea.settaCollisione(pygame.Rect((680, 158), (160, 110))) # rect pietra alto sinistra
#	miaArea.settaCollisione(pygame.Rect((125, 198), (120, 120))) # pietra vicino casa
#	miaArea.settaCollisione(pygame.Rect((175, 728), (110, 110))) # palo casa sinistra
#	miaArea.settaCollisione(pygame.Rect((1250, 430), (50, 50)))
#	
	
	
	miaArea.settaCollisione(pygame.Rect((1250, 430), (50, 50)))
	miaArea.settaCollisione(pygame.Rect((0, 0), (440, 900)))
	miaArea.settaCollisione(pygame.Rect((850, 0), (300, 700)))
	
def ristampa(world, x, y, PATH, player, flagUltimo = ""):
	world.blit(miaArea.getSurfArea(), (0, 0))	
	surf_area=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/cambiaAreaPiccola.jpg")
	xA=600
	yA=870
	world.blit(surf_area, (xA,yA))

	surf_Player=pygame.image.load(PATH)
	world.blit(surf_Player, (x,y))	
	
	if flagUltimo != "ananas":
		world.blit(pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/robaOcaViola/ocaViolaBatt.png"), (1020, 690))
	
	#rect1= pygame.Rect((610, 0), (45, 45))
	#pygame.draw.rect(world, (1,0,0), rect1 ) 
	#rect1= pygame.Rect((870, 280), (70, 420))
	#pygame.draw.rect(world, (1,0,0), rect1 ) 
	#pygame.draw.rect(world, (0,0,255), player.rect_player ) 
	#rect2= pygame.Rect((0, 0), (380, 900))
	#pygame.draw.rect(world, (1,0,0), rect2 )
	#rect3= pygame.Rect((900, 0), (300, 600))
	#pygame.draw.rect(world, (1,23,0), rect3 )	
	#rect4= pygame.Rect((430, 370), (100, 210))
	#pygame.draw.rect(world, (1,0,0), rect4 )
	#rect5= pygame.Rect((550, 258), (300, 110))
	#pygame.draw.rect(world, (1,0,0), rect5 )
	#rect6= pygame.Rect((680, 158), (160, 110))
	#pygame.draw.rect(world, (1,255,0), rect6 )


def main(player, inventario, flagUltimo = ""):
	global flagColl
	
	pygame.init()
	worldx = 1280
	worldy = 920
	fps = 40
	ani = 4
	world = pygame.display.set_mode((worldx, worldy))
	#backdrop = pygame.image.load("Immagini_Gioco/background_menu/rossa2.jpg").convert()
	clock = pygame.time.Clock()
	#backdropbox = world.get_rect()
	main = True
	muovix = 0

	#player = Player()  # spawn player
	#player.rect.x = 0  # go to x
	#player.rect.y = 0  # go to y
	steps = 10

	world.blit(miaArea.getSurfArea(), (0, 0))
	
	surf_area=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/cambiaAreaPiccola.jpg")
	xA=600
	yA=870
	world.blit(surf_area, (xA,yA))

	
	nuovaPoz = camminiamo.getUpPath()	
	player.settaPoz(world, 580, 750)
	world.blit(pygame.image.load(nuovaPoz), (player.getRectPlayer().x , player.getRectPlayer().y))	
	
	
	pygame.key.set_repeat(27,27)
	if(flagColl == 0):
		settaCollsioni(flagUltimo)
		flagColl = 1
		
	if flagUltimo == "ananas":
		miaArea.settaCollisione(pygame.Rect((610, 0), (45, 45)))
	if flagUltimo != "ananas":
		world.blit(pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/robaOcaViola/ocaViolaBatt.png"), (1020, 690))
		
	pygame.display.flip()
	
	while main:
		print(player.rect_player.x)
		clock.tick(27)
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				sys.exit()
			elif event.type == pygame.MOUSEBUTTONDOWN:
				click = event.pos
				print(click)
				
			if event.type == pygame.KEYDOWN:
				if event.key == pygame.K_LEFT:
					x2 = player.getRectPlayer().x - steps
					y2 = player.getRectPlayer().y
					prova = x2 - player.getRectPlayer().x
					prova2 = y2 - player.getRectPlayer().y
					rect_prova = player.getRectPlayer().move(prova, prova2)
					if(miaArea.verificaCollisione2(rect_prova) == False):
						if(rect_prova.x < 0):
							print("m")
						else:
							player.setRect(prova, prova2)
							camminiamo.settaLeft()
							nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
							ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player, flagUltimo)
							
								
						
				if (event.key == pygame.K_RIGHT):
					x2 = player.getRectPlayer().x + steps
					y2 = player.getRectPlayer().y
					prova = x2 - player.getRectPlayer().x
					prova2 = y2 - player.getRectPlayer().y
					rect_prova = player.getRectPlayer().move(prova, prova2)
					if(miaArea.verificaCollisione2(rect_prova) == False):
						if(rect_prova.x < 1210):
							player.setRect(prova, prova2)
							camminiamo.settaRight()
							nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
							ristampa(world, player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player, flagUltimo)
					
					
				if event.key == pygame.K_UP :
					x2 = player.getRectPlayer().x
					y2 = player.getRectPlayer().y - steps
					prova = x2 - player.getRectPlayer().x
					prova2 = y2 - player.getRectPlayer().y
					rect_prova = player.getRectPlayer().move(prova, prova2)
					if(miaArea.verificaCollisione2(rect_prova) == False):
						if(rect_prova.y > 0):
							player.setRect(prova, prova2)
							camminiamo.settaUP()
							nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
							ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player, flagUltimo)	
							

													
					
							
								
				if event.key == pygame.K_DOWN:
					x2 = player.getRectPlayer().x
					y2 = player.getRectPlayer().y + steps
					prova = x2 - player.getRectPlayer().x
					prova2 = y2 - player.getRectPlayer().y
					rect_prova = player.getRectPlayer().move(prova, prova2)
					if(miaArea.verificaCollisione2(rect_prova) == False):
						if(rect_prova.y < 790):
							player.setRect(prova, prova2)
							camminiamo.settaDOWN()
							nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
							ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player, flagUltimo)
							
				if event.key == pygame.K_DOWN or event.key == pygame.K_UP  or event.key == pygame.K_RIGHT or event.key == pygame.K_LEFT:
					if (miaArea.rectCollisioni[1].colliderect(rect_prova)):
						main = False
					if flagUltimo == "ananas":
						if(miaArea.rectCollisioni[5].colliderect(rect_prova)):
							tempioBattagliaFinale.main(player, inventario)
							
		#		if event.key == pygame.K_DOWN or event.key == pygame.K_UP  or event.key == pygame.K_RIGHT or event.key == pygame.K_LEFT:
		#			if (miaArea.rectCollisioni[0].colliderect(rect_prova)):
						#flagColl = 1
						#main = False
				if event.key  == pygame.K_RETURN:
					if flagUltimo != "ananas":
						if (miaArea.rectCollisioni[0].colliderect(rect_prova) and player.oca3 == False):
								vinto = turnoPlayer.main(player, "viola")		
								if vinto == 1:
									player.oca3 = True
									player.aumentaExp(2505)
									player.energy = player.PEP
									dialogoV.stampaDialoghi(world, 3)
									if (player.oca1 == True and player.oca2 == True and player.oca3 == True):
										main = False
								elif vinto == 0:
									player.energy = player.PEP
									player.HP = player.PP
									player.oca1 = False
									player.oca2 = False
									player.oca3 = False
									player.ricominciaDopoSconfitta = True
									main = False
									print("HAI PERSO RICOMINCIA DALLA PRIMA OCA")
								player.settaPoz(world, 500, 280)
								camminiamo.settaLeft()
								nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
								ristampa(world, player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player , flagUltimo)	
						print("dialoghi")
			#	if event.key == 105:
			#		inventario.stampaInventario(player, world)
			#		ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player)
				if event.key == 105:
					inventario.stampaInventario(player, world)
					ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player, flagUltimo)	
						
						
					
			pygame.display.flip()
			
#main()

