
import pygame
import time


class Dialogo():

	def __init__(self):
		pygame.font.init()
		self.interazioni = 0
		self.surf_next= pygame.image.load("Immagini_Gioco/ImmaginiMappa/next.png")
		self.rect_next = self.surf_next.get_rect()
		self.surf_dialogBox = pygame.image.load("Immagini_Gioco/DialoghiNPC/npc_secondari/dialogBase.jpg")
		self.text = ""
		self.fontVito = pygame.font.Font('Immagini_Gioco/DialoghiNPC/fontDialoghi/vito/vitoFont.ttf', 27, bold=True)
		
	def stampaDialoghi(self,world, personaggio, npc):
		
		if (personaggio == 1): #DOGGO CON ARMOR
			surf_immagine = pygame.image.load(npc)
			contatoreNext = 0
			self.settaText(personaggio, contatoreNext)
			#textSurface = self.fontVito.render(self.text, False, (0, 0, 0))
			ciclo = True
			world.blit(self.surf_dialogBox, (30, 600))	
			world.blit(surf_immagine, (5, 630))
			descriptioncounter = 0   
			for x in self.text:
				descriptioncounter += 0.5
				world.blit(self.fontVito.render(x, False, (255, 255, 255)) ,(230,630+75*descriptioncounter))
			descriptioncounter = 0  
			if(self.rect_next.x == 0 and self.rect_next.y == 0):
				self.rect_next.move_ip(1000, 800)
			world.blit(self.surf_next, (1000, 800))
			pygame.display.flip()  	
			while ciclo:
				print("ou")
				if(contatoreNext != 1):
					events = pygame.event.get() #lista eventi di una finestra
					for event in events:
						if event.type == pygame.QUIT:
							pygame.quit()
							
						elif event.type == pygame.MOUSEBUTTONDOWN:
							click = event.pos

							if self.rect_next.collidepoint(click) and event.button==1:
								contatoreNext += 1										
									
				else:
					ciclo = False
					contatoreNext = 0
					
		if (personaggio == 2): #DOGGO CON ARMOR
			surf_immagine = pygame.image.load(npc)
			contatoreNext = 0
			self.settaText(personaggio, contatoreNext)
			#textSurface = self.fontVito.render(self.text, False, (0, 0, 0))
			ciclo = True
			world.blit(self.surf_dialogBox, (30, 600))	
			world.blit(surf_immagine, (5, 630))
			descriptioncounter = 0   
			for x in self.text:
				descriptioncounter += 0.5
				world.blit(self.fontVito.render(x, False, (0, 255, 0)) ,(230,630+75*descriptioncounter))
			descriptioncounter = 0  
			if(self.rect_next.x == 0 and self.rect_next.y == 0):
				self.rect_next.move_ip(1000, 800)
			world.blit(self.surf_next, (1000, 800))
			pygame.display.flip()  	
			while ciclo:
				print("ou")
				if(contatoreNext != 2):
					events = pygame.event.get() #lista eventi di una finestra
					for event in events:
						if event.type == pygame.QUIT:
							pygame.quit()
							
						elif event.type == pygame.MOUSEBUTTONDOWN:
							click = event.pos

							if self.rect_next.collidepoint(click) and event.button==1:
								contatoreNext += 1	
								if(contatoreNext == 1):
									self.ristampa(world, surf_immagine)
									self.settaText(personaggio, contatoreNext)
									descriptioncounter = 0 
									for x in self.text:
										descriptioncounter += 0.5
										world.blit(self.fontVito.render(x, False, (0, 255, 0)) ,(250,630+75*descriptioncounter))
									descriptioncounter = 0  
									world.blit(self.surf_next, (1000, 800))
									pygame.display.flip()  										
									
				else:
					ciclo = False
					contatoreNext = 0
		if (personaggio == 3): #SANS
			surf_immagine = pygame.image.load(npc)
			contatoreNext = 0
			self.settaText(personaggio, contatoreNext)
			#textSurface = self.fontVito.render(self.text, False, (0, 0, 0))
			ciclo = True
			world.blit(self.surf_dialogBox, (30, 600))	
			world.blit(surf_immagine, (70, 650))
			descriptioncounter = 0   
			for x in self.text:
				descriptioncounter += 0.5
				world.blit(self.fontVito.render(x, False, (0, 255, 0)) ,(230,630+75*descriptioncounter))
			descriptioncounter = 0  
			if(self.rect_next.x == 0 and self.rect_next.y == 0):
				self.rect_next.move_ip(1000, 800)
			world.blit(self.surf_next, (1000, 800))
			pygame.display.flip()  	
			while ciclo:
				print("ou")
				if(contatoreNext != 2):
					events = pygame.event.get() #lista eventi di una finestra
					for event in events:
						if event.type == pygame.QUIT:
							pygame.quit()
							
						elif event.type == pygame.MOUSEBUTTONDOWN:
							click = event.pos

							if self.rect_next.collidepoint(click) and event.button==1:
								contatoreNext += 1	
								if(contatoreNext == 1):
									self.ristampaSans(world, surf_immagine)
									self.settaText(personaggio, contatoreNext)
									descriptioncounter = 0 
									for x in self.text:
										descriptioncounter += 0.5
										world.blit(self.fontVito.render(x, False, (0, 255, 0)) ,(250,630+75*descriptioncounter))
									descriptioncounter = 0  
									world.blit(self.surf_next, (1000, 800))
									pygame.display.flip()  										
									
				else:
					ciclo = False
					contatoreNext = 0		
			
			

	def settaText(self, numDialog, contatore):
		if(numDialog == 1):
			if(contatore == 0):
				#self.text = "VITO:    BELLA RAGA"
				self.text =["WOOF WOOF ? " , " Stai cercando le oche di crazy goose ? woof woof ", "Non ne ho viste passare di qui ma sicuramente nel loro quartier generale ", " troverai informazioni woof woof ... "]
		elif(numDialog == 2):
			if(contatore == 0):
				self.text = ["Ehy Piacere io sono Osvaldo !", "Quindi tu sei il nuovo aspirante pizzaiolo di Ciccio's Pizza ...", " spero solo tu non faccia la fine di Ciccio..." ]
			elif (contatore == 1):
				self.text = ["Oche ?", "No mi spiace non ne ho viste passare per di qui", "Prova ad andare al nuovo TOMBOL-ONE !", "Ormai il locale è diventato il punto di ritrovo di tutti !", "Li troverai sicuramente informazioni !, Vai verso giu per raggiungerlo !"]
		elif(numDialog == 3):
			if(contatore == 0):
				self.text = ["* YO", "Il mio nome è Sans lo scheletro." ]
			elif (contatore == 1):
				self.text = ["Sono qui per ordinare delle Pizze ovviamente. ", "Fammi una margherita, una pizza al prosciutto, una quattro stagioni, una ai funghi ... ", "E in fine una quattro formaggi... ", "SENZA GORGONZOLA, altrimenti passerai dei guai ... "]
				
	def ristampa(self, world, immagine):				
		world.blit(self.surf_dialogBox, (30, 600))	
		world.blit(immagine, (5, 630)) 
		
	def ristampaSans(self, world, immagine):				
		world.blit(self.surf_dialogBox, (30, 600))	
		world.blit(immagine, (70, 650)) 

			
