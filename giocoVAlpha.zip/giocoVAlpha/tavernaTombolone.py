import pygame, sys
import pygame_menu #libreria di pygame che permette una facile creazione del main menu di gioco
from pygame_menu import sound
from pygame.locals import *
import mappaLivelli
import time, datetime
import crazyPalace
import classPG
import Camminata
import Player
import gestioneCitta
import pianura1
import turnoPlayer

camminiamo = Camminata.Camminata()
#player = Player.Player(camminiamo.getUpPath(), 800, 780)
miaArea = gestioneCitta.areaCiccios("Immagini_Gioco/INVENTARIO/tavernaTombolone.jpg")
flagColl = 0


def settaCollisioni():
	miaArea.settaCollisione(pygame.Rect((90, 505), (390, 425))) #rectBosco sopra
	miaArea.settaCollisione(pygame.Rect((380, 60), (670, 300)))	#rect Albero in basso destra
	miaArea.settaCollisione(pygame.Rect((830, 905), (30, 30)))
	
	#dialoghi
	miaArea.settaCollisione( pygame.Rect((160, 250), (75, 45)))


def ristampaMovi(world, x, y):
	
	path_stampa = camminiamo.ristampaMovi()
	surf_posizione= pygame.image.load(path_stampa)
	world.blit(surf_posizione, (x,y))
	return path_stampa
	
def ristampa(world, x, y, PATH, player):
	surf_background = pygame.image.load("Immagini_Gioco/INVENTARIO/tavernaTombolone.jpg").convert()
	world.blit(surf_background, (0, 0))

	surf_area2=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/cambiaAreaPiccola.jpg")
	xA2=815
	yA2=865
	world.blit(surf_area2, (xA2,yA2))
		
	world.blit(pygame.image.load("Immagini_Gioco/INVENTARIO/ocaAntiPizzaDx.png"), (100, 190))
	
	surf_Player=pygame.image.load(PATH)
	world.blit(surf_Player, (x,y))
	#rect1= pygame.Rect((160, 250), (45, 45))
	#pygame.draw.rect(world, (1,0,0), rect1 ) 
	#ect2= pygame.Rect((830, 890), (30, 30))
	#pygame.draw.rect(world, (1,0,0), rect2 )
	#pygame.draw.rect(world, (0,255,255), player.rect_player ) 
	#rect3= pygame.Rect((380, 60), (670, 300))
	#pygame.draw.rect(world, (1,0,0), rect3 )	
	#rect4= pygame.Rect((430, 370), (100, 210))
	#pygame.draw.rect(world, (1,0,0), rect4 )
	#rect5= pygame.Rect((550, 258), (300, 110))
	#pygame.draw.rect(world, (1,0,0), rect5 )
	#rect6= pygame.Rect((680, 158), (160, 110))
	#pygame.draw.rect(world, (1,255,0), rect6 )
	#rect7= pygame.Rect((125, 198), (120, 120))
	#pygame.draw.rect(world, (1,255,0), rect7 )


def main(player, inventario):
	global flagColl
	
	pygame.init()
	worldx = 1280
	worldy = 920
	fps = 40
	ani = 4
	world = pygame.display.set_mode((worldx, worldy))
	#backdrop = pygame.image.load("Immagini_Gioco/background_menu/rossa2.jpg").convert()
	clock = pygame.time.Clock()
	#backdropbox = world.get_rect()
	main = True
	muovix = 0

	#player = Player()  # spawn player
	#player.rect.x = 0  # go to x
	#player.rect.y = 0  # go to y
	steps = 10
	
	surf_background = pygame.image.load("Immagini_Gioco/INVENTARIO/tavernaTombolone.jpg").convert()
	world.blit(surf_background, (0, 0))
	
	surf_area2=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/cambiaAreaPiccola.jpg")
	xA2=815
	yA2=865
	world.blit(surf_area2, (xA2,yA2))
		
	world.blit(pygame.image.load("Immagini_Gioco/INVENTARIO/ocaAntiPizzaDx.png"), (100, 190))

	nuovaPoz = camminiamo.getUpPath()	
	player.settaPoz(world, 800, 760)
	world.blit(pygame.image.load(nuovaPoz), (player.getRectPlayer().x , player.getRectPlayer().y))
	#rect1= pygame.Rect((160, 250), (45, 45))
	#pygame.draw.rect(world, (1,0,0), rect1 ) 
	if(flagColl == 0):
		settaCollisioni()
	pygame.key.set_repeat(27,27)
	pygame.display.flip()
	
	while main:
		#print(player.rect_player.x)
		clock.tick(27)
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				sys.exit()
			elif event.type == pygame.MOUSEBUTTONDOWN:
				click = event.pos
				print(click)
				
			if event.type == pygame.KEYDOWN:
				if event.key == pygame.K_LEFT:
					x2 = player.getRectPlayer().x - steps
					y2 = player.getRectPlayer().y
					prova = x2 - player.getRectPlayer().x
					prova2 = y2 - player.getRectPlayer().y
					rect_prova = player.getRectPlayer().move(prova, prova2)
					if(miaArea.verificaCollisione4(rect_prova) == False):
						if(rect_prova.x < 100):
							print("m")
						else:
							player.setRect(prova, prova2)
							camminiamo.settaLeft()
							nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
							ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player)
							
								
						
				if (event.key == pygame.K_RIGHT):
					x2 = player.getRectPlayer().x + steps
					y2 = player.getRectPlayer().y
					prova = x2 - player.getRectPlayer().x
					prova2 = y2 - player.getRectPlayer().y
					rect_prova = player.getRectPlayer().move(prova, prova2)
					if(miaArea.verificaCollisione4(rect_prova) == False):
						if(rect_prova.x < 1110):
							player.setRect(prova, prova2)
							camminiamo.settaRight()
							nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
							ristampa(world, player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player)
						
					
				if event.key == pygame.K_UP :
					x2 = player.getRectPlayer().x
					y2 = player.getRectPlayer().y - steps
					prova = x2 - player.getRectPlayer().x
					prova2 = y2 - player.getRectPlayer().y
					rect_prova = player.getRectPlayer().move(prova, prova2)
					if(miaArea.verificaCollisione4(rect_prova) == False):
						if(rect_prova.y > 100):
							player.setRect(prova, prova2)
							camminiamo.settaUP()
							nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
							ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player)	
							

													
					
							
								
				if event.key == pygame.K_DOWN:
					x2 = player.getRectPlayer().x
					y2 = player.getRectPlayer().y + steps
					prova = x2 - player.getRectPlayer().x
					prova2 = y2 - player.getRectPlayer().y
					rect_prova = player.getRectPlayer().move(prova, prova2)
					if(miaArea.verificaCollisione4(rect_prova) == False):
						if(rect_prova.y < 790):
							player.setRect(prova, prova2)
							camminiamo.settaDOWN()
							nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
							ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player)
						
				if event.key == pygame.K_DOWN or event.key == pygame.K_UP  or event.key == pygame.K_RIGHT or event.key == pygame.K_LEFT:
					if (miaArea.rectCollisioni[2].colliderect(rect_prova)):
						flagColl = 1
						main = False
				if event.key  == pygame.K_RETURN:
					if (miaArea.rectCollisioni[3].colliderect(rect_prova) and player.oca1 == False):
						vinto = turnoPlayer.main(player, "verde")		
						if vinto == 1:
							player.oca1 = True
							player.energy = player.PEP
							player.aumentaExp(605)
							player.havePadLunga = True
						elif vinto == 0:
							player.energy = player.PEP
							player.HP = player.PP
							player.oca1 = False
							player.oca2 = False
							player.oca3 = False
							player.ricominciaDopoSconfitta = True
							main = False
							print("HAI PERSO RICOMINCIA DALLA PRIMA OCA")
						player.settaPoz(world, 240, 150)
						camminiamo.settaLeft()
						nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
						ristampa(world, player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player)	
				if event.key == 105:
					inventario.stampaInventario(player, world)
					ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player)	
								
					
			pygame.display.flip()
		


	
