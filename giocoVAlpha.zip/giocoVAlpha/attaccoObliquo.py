import PiumaAttacco
import pygame
import random
import Player
import time

class AttaccoObli():

	def __init__(self): 
		self.arrayPiume = []
		self.arrayPiumeSx = []
		self.arrayPiumeUP = []
		self.arrayPiumeDOWN = []
		self.setAttacco = 0
		self.arrayID = []
		
	def attaccoObliquo(self, world, P1, P2, player, velocita):
				#pygame.time.set_timer(player.colpito(), 3000)
		
		clock1 = pygame.time.Clock()
		flagAttendi = True
		aaa = 0
		i = 0
		
		print(self.arrayPiume[1].getRectPiuma().x, self.arrayPiume[1].getRectPiuma().y)
		print(self.arrayPiume[0].getRectPiuma().x, self.arrayPiume[0].getRectPiuma().y)
		
		for i in range(len(self.arrayPiume)):
			
			if(	self.arrayPiume[i].getRectPiuma().colliderect(player.getRectPlayer()) and flagAttendi == True):
					flagAttendi = False
	
			self.arrayPiume[i].setta_x(velocita)
			self.arrayPiume[i].setta_y(velocita)

			if(self.arrayPiume[i].getRectPiuma().colliderect(player.getRectPlayer())):
				if self.arrayPiume[i].getId() in self.arrayID:
					print("ce")
				else:
					print("yooo")
					self.arrayID.append(self.arrayPiume[i].getId())
			else:
				if(self.arrayPiume[i].getId() in self.arrayID):
					print("nop")
				else:
					world.blit(self.arrayPiume[i].getSurfPiuma(), (self.arrayPiume[i].getRectPiuma().x, self.arrayPiume[i].getRectPiuma().y))
			#world.blit(self.arrayPiume[i].getSurfPiuma(),  (self.arrayPiume[i].getRectPiuma().x, self.arrayPiume[i].getRectPiuma().y))
			#pygame.draw.rect(world, (1,0,0), self.arrayPiume[i].getRectPiuma() ) 
			
		if self.arrayPiume[0].getRectPiuma().x < 100:
			self.arrayID = []					
		
		return flagAttendi 
		
	def attaccoObliquoSx(self, world, P1, P2, player, velocita):
		clock1 = pygame.time.Clock()
		flagAttendi = True
		aaa = 0
		i = 0
		
		print(self.arrayPiumeSx[1].getRectPiuma().x, self.arrayPiume[1].getRectPiuma().y)
		print(self.arrayPiumeSx[0].getRectPiuma().x, self.arrayPiume[0].getRectPiuma().y)
		
		for i in range(len(self.arrayPiumeSx)):
			
			if(	self.arrayPiumeSx[i].getRectPiuma().colliderect(player.getRectPlayer()) and flagAttendi == True):
					flagAttendi = False
	
			self.arrayPiumeSx[i].setta_x(velocita)
			self.arrayPiumeSx[i].setta_y(velocita)

			if(self.arrayPiumeSx[i].getRectPiuma().colliderect(player.getRectPlayer())):
				if self.arrayPiumeSx[i].getId() in self.arrayID:
					print("ce")
				else:
					print("yooo")
					self.arrayID.append(self.arrayPiume[i].getId())
			else:
				if(self.arrayPiumeSx[i].getId() in self.arrayID):
					print("nop")
				else:
					world.blit(self.arrayPiumeSx[i].getSurfPiuma(), (self.arrayPiumeSx[i].getRectPiuma().x, self.arrayPiumeSx[i].getRectPiuma().y))
			#world.blit(self.arrayPiume[i].getSurfPiuma(),  (self.arrayPiume[i].getRectPiuma().x, self.arrayPiume[i].getRectPiuma().y))
			#pygame.draw.rect(world, (1,0,0), self.arrayPiume[i].getRectPiuma() ) 
			
		if self.arrayPiumeSx[0].getRectPiuma().x > 1100:
			self.arrayID = []					
		
		return flagAttendi 
		
	def attaccoObliquoUP(self, world, P1, P2, player, velocita):
		clock1 = pygame.time.Clock()
		flagAttendi = True
		aaa = 0
		i = 0
		
		print(self.arrayPiumeSx[1].getRectPiuma().x, self.arrayPiume[1].getRectPiuma().y)
		print(self.arrayPiumeSx[0].getRectPiuma().x, self.arrayPiume[0].getRectPiuma().y)
		
		for i in range(len(self.arrayPiumeUP)):
			
			if(	self.arrayPiumeUP[i].getRectPiuma().colliderect(player.getRectPlayer()) and flagAttendi == True):
					flagAttendi = False
	
			self.arrayPiumeUP[i].setta_x(velocita)
			self.arrayPiumeUP[i].setta_y(velocita)

			if(self.arrayPiumeUP[i].getRectPiuma().colliderect(player.getRectPlayer())):
				if self.arrayPiumeUP[i].getId() in self.arrayID:
					print("ce")
				else:
					print("yooo")
					self.arrayID.append(self.arrayPiume[i].getId())
			else:
				if(self.arrayPiumeUP[i].getId() in self.arrayID):
					print("nop")
				else:
					world.blit(self.arrayPiumeUP[i].getSurfPiuma(), (self.arrayPiumeUP[i].getRectPiuma().x, self.arrayPiumeUP[i].getRectPiuma().y))
			#world.blit(self.arrayPiume[i].getSurfPiuma(),  (self.arrayPiume[i].getRectPiuma().x, self.arrayPiume[i].getRectPiuma().y))
			#pygame.draw.rect(world, (1,0,0), self.arrayPiume[i].getRectPiuma() ) 
			
		if self.arrayPiumeUP[0].getRectPiuma().x > 1100:
			self.arrayID = []					
		
		return flagAttendi 
		
	def attaccoObliquoDOWN(self, world, P1, P2, player, velocita):
		clock1 = pygame.time.Clock()
		flagAttendi = True
		aaa = 0
		i = 0
		
		print(self.arrayPiumeSx[1].getRectPiuma().x, self.arrayPiume[1].getRectPiuma().y)
		print(self.arrayPiumeSx[0].getRectPiuma().x, self.arrayPiume[0].getRectPiuma().y)
		
		for i in range(len(self.arrayPiumeDOWN)):
			
			if(	self.arrayPiumeDOWN[i].getRectPiuma().colliderect(player.getRectPlayer()) and flagAttendi == True):
					flagAttendi = False
	
			self.arrayPiumeDOWN[i].setta_x(velocita)
			self.arrayPiumeDOWN[i].setta_y(velocita)

			if(self.arrayPiumeDOWN[i].getRectPiuma().colliderect(player.getRectPlayer())):
				if self.arrayPiumeDOWN[i].getId() in self.arrayID:
					print("ce")
				else:
					print("yooo")
					self.arrayID.append(self.arrayPiume[i].getId())
			else:
				if(self.arrayPiumeDOWN[i].getId() in self.arrayID):
					print("nop")
				else:
					world.blit(self.arrayPiumeDOWN[i].getSurfPiuma(), (self.arrayPiumeDOWN[i].getRectPiuma().x, self.arrayPiumeDOWN[i].getRectPiuma().y))
			#world.blit(self.arrayPiume[i].getSurfPiuma(),  (self.arrayPiume[i].getRectPiuma().x, self.arrayPiume[i].getRectPiuma().y))
			#pygame.draw.rect(world, (1,0,0), self.arrayPiume[i].getRectPiuma() ) 
			
		if self.arrayPiumeDOWN[0].getRectPiuma().x < 100:
			self.arrayID = []					
		
		return flagAttendi 
			
		
	def pushPiuma(self, piuma):
		print(piuma)
		self.arrayPiume.append(piuma)
		
	def pushPiumaSx(self, piuma):
		print(piuma)
		self.arrayPiumeSx.append(piuma)
		
	def pushPiumaUP(self, piuma):
		print(piuma)
		self.arrayPiumeUP.append(piuma)

		
	def pushPiumaDOWN(self, piuma):
		print(piuma)
		self.arrayPiumeDOWN.append(piuma)
		
	def returnArrayPiuma(self):
		return self.arrayPiume
		


						
	def settingAttacco(self, val):
		self.setAttacco = val
