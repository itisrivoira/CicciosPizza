import pygame, sys
import pygame_menu #libreria di pygame che permette una facile creazione del main menu di gioco
from pygame_menu import sound
from pygame.locals import *
import mappaLivelli
import time, datetime
import crazyPalace
import sfida1
import classPG
import Camminata

'''
Variables

'''

camminiamo = Camminata.Camminata()
flag = 0
star = [0, 0, 0, 0 ,0]
ocaV = 0


PATH_DX = 'Immagini_Gioco/HUB/chefCammina.png'
PATH_SX = 'Immagini_Gioco/HUB/chef2sx.png'
boxGialla = "Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/dialogOcaGialla1.jpg"
boxVerde=  "Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/dialogSfida1.jpg"

'''
Objects
'''


#class Player(pygame.sprite.Sprite):
 #   """
  #  Spawn a player
   # """
#
 #   def __init__(self):
  #      pygame.sprite.Sprite.__init__(self)
   #     self.movex = 0
    #    self.movey = 0
     #   self.frame = 0
      #  self.images = []
       # for i in range(1, 5):
        #    img = pygame.image.load('Immagini_Gioco/chefCammina.png').convert()
         #   img.convert_alpha()  # optimise alpha
          #  img.set_colorkey(ALPHA)  # set alpha
           # self.images.append(img)
            #self.image = self.images[0]
            #self.rect = self.image.get_rect()

#    def control(self, x, y):
 #       """
  #      control player movement
   #     """
    #    self.movex += x
     #   self.movey += y

 #   def update(self):
  #      """
   #     Update sprite position
    #    """
#
 #       self.rect.x = self.rect.x + self.movex
  #      self.rect.y = self.rect.y + self.movey
#
 #       # moving left
  #      if self.movex < 0:
   #         self.frame += 1
    #        if self.frame > 3*ani:
     #           self.frame = 0
      #      self.image = pygame.transform.flip(self.images[self.frame // ani], True, False)
#
 #       # moving right
  #      if self.movex > 0:
   #         self.frame += 1
    #        if self.frame > 3*ani:
     #           self.frame = 0
      #      self.image = self.images[self.frame//ani]
#

'''
Setup

'''

#def crea_stanza():
#	print("cristo")
#	surf_background = pygame.image.load("Immagini_Gioco/HUB/pavimentociccio.png").convert()
#	world.blit(surf_background, (0, 0))
#	pygame.display.flip()

def ristampaMovi(world, x, y):
	
	path_stampa = camminiamo.ristampaMovi()
	surf_posizione= pygame.image.load(path_stampa)
	world.blit(surf_posizione, (x,y))
	return path_stampa


def colonnaSonora(volume,FLAGPAUSE):
	if(FLAGPAUSE == True):
		pygame.mixer.music.load("Suoni/hubOst.wav")
		pygame.mixer.music.play(-1)   #play della colonna sonora -1 ---> indica per tempo infinito
		pygame.mixer.music.set_volume(volume)
		pygame.mixer.music.pause()
	else:
		pygame.mixer.music.load("Suoni/hubOst.wav")
		pygame.mixer.music.play(-1)   #play della colonna sonora -1 ---> indica per tempo infinito
		pygame.mixer.music.set_volume(volume)
		
def dialogoOcaGialla(world, box):
	surf_dialoge = pygame.image.load(box)
	rect_dialoge = surf_dialoge.get_rect()
	xDia=30  
	yDia=600  
	rect_dialoge.move_ip(xDia, yDia) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_dialoge, (xDia,yDia))	
		
	surf_next= pygame.image.load("Immagini_Gioco/ImmaginiMappa/next.png")
	rect_next= surf_next.get_rect()
	x=1000
	y=800  
	rect_next.move_ip(x, y)
	world.blit(surf_next, (x,y))
	
	pygame.display.flip()
	
	DONE=False
	while not DONE:

		
		events = pygame.event.get() #lista eventi di una finestra
		for event in events:
			if event.type == pygame.QUIT:
				pygame.quit()
		        
			elif event.type == pygame.MOUSEBUTTONDOWN:
				click = event.pos

				if rect_next.collidepoint(click) and event.button==1:
					DONE = True											

def ristampa(font, poz, personaggio, world, x, y, prov, i, PATH):

	surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/pavimentoCrazy.png").convert()
	world.blit(surf_background, (0, 0))
	

	surf_area=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/cambiaArea.jpg")
	rect_area = surf_area.get_rect()
	xA=570 
	yA=820 
	rect_area.move_ip(xA, yA) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_area, (xA,yA))
	
	surf_oca1=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/pedina_gialla.png")
	rect_oca1 = surf_oca1.get_rect()
	xOc1=100
	yOc1=700  
	rect_oca1.move_ip(xOc1, yOc1) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_oca1, (xOc1,yOc1))
	
	surf_oca2=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/pedina_verdeSx.png")
	rect_oca2 = surf_oca2.get_rect()
	xOc2=800 
	yOc2=300  
	rect_oca2.move_ip(xOc2, yOc2) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_oca2, (xOc2,yOc2))
	
	surf_orologio= pygame.image.load("Immagini_Gioco/Immagini_Livello/orologio.png")
	rect_orologio = surf_orologio.get_rect()
	xOr=1100
	yOr=50  
	rect_orologio.move_ip(xOr, yOr)
	world.blit(surf_orologio, (xOr,yOr))
	world.blit(surf_orologio, (xOr,yOr))
	poz.fill((255, 255, 255))#serve per cancellare il contenuto della surface in modo da fare il timer decrescente
	poz = font.render(personaggio.getStringa(), True, (0, 187, 45), (255, 255, 255))
	world.blit(poz, (1155, 134))
	

	
	surf_chef=pygame.image.load(PATH)
	world.blit(surf_chef, (x,y))

	
	
		
def main(personaggio, FLAGPAUSE, volume, x, y):	
	#pygame.init()
	global ocaV
	ocaV
	worldx = 1280
	worldy = 920
	fps = 40
	ani = 4
	world = pygame.display.set_mode((worldx, worldy))
	global flag
	flag
	#backdrop = pygame.image.load("Immagini_Gioco/background_menu/rossa2.jpg").convert()
	clock = pygame.time.Clock()
	#backdropbox = world.get_rect()
	main = True
	muovix = 0

	#player = Player()  # spawn player
	#player.rect.x = 0  # go to x
	#player.rect.y = 0  # go to y
	steps = 10


	surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/pavimentoCrazy.png").convert()
	world.blit(surf_background, (0, 0))
	
	
	surf_area=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/cambiaArea.jpg")
	rect_area = surf_area.get_rect()
	xA=570 
	yA=820  
	rect_area.move_ip(xA, yA) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_area, (xA,yA))		
	
	surf_oca1=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/pedina_gialla.png")
	rect_oca1 = surf_oca1.get_rect()
	xOc1=100 
	yOc1=700  
	rect_oca1.move_ip(xOc1, yOc1) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_oca1, (xOc1,yOc1))
	
	surf_oca2=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/pedina_verdeSx.png")
	rect_oca2 = surf_oca2.get_rect()
	xOc2=800 
	yOc2=300  
	rect_oca2.move_ip(xOc2, yOc2) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_oca2, (xOc2,yOc2))


	surf_chef=pygame.image.load(camminiamo.getUpPath())
	rect_chef = surf_chef.get_rect()
	rect_chef.move_ip(x, y) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_chef, (x,y))

	surf_orologio= pygame.image.load("Immagini_Gioco/Immagini_Livello/orologio.png")
	rect_orologio = surf_orologio.get_rect()
	xOr=1100
	yOr=50  
	rect_orologio.move_ip(xOr, yOr)
	world.blit(surf_orologio, (xOr,yOr))
	
	font = pygame.font.SysFont("Verdana", 34, bold=True, italic=True)
	poz = font.render(personaggio.getStringa(), True,  (0, 187, 45), (255, 255, 0))



	pygame.display.flip()
	pygame.key.set_repeat(2,6)  #serve per lo spostamento
	
	pygame.time.set_timer(pygame.USEREVENT, 1000)

	'''
	Main Loop
	'''

	while main:
		#print(volume)
		
		if personaggio.getTimer() == 0:
			main = False
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				sys.exit()
		        
			if event.type == pygame.USEREVENT:
				personaggio.diminuisci()
				personaggio.setStringa(personaggio.getTimer())
				print(personaggio.getTimer())
				world.blit(surf_orologio, (xOr,yOr))
				poz.fill((255, 255, 255))#serve per cancellare il contenuto della surface in modo da fare il timer decrescente
				poz = font.render(personaggio.getStringa(), True, (0, 187, 45), (255, 255, 255))
				world.blit(poz, (1155, 134))
				
			if event.type == pygame.KEYDOWN:
				if event.key == pygame.K_LEFT:
					if(rect_chef.x > 10):
						#print ("ou")
						x2 = rect_chef.x - steps
						y2 = rect_chef.y
						#print(x)
						#print (rect_chef.x, rect_chef.y)
						#print(x2, y2)
						prova = x2 - rect_chef.x
						prova2 = y2 - rect_chef.y
						rect_prova = rect_chef.move(prova, prova2)
						
						if(rect_prova.colliderect(rect_oca1) or rect_prova.colliderect(rect_oca2)):
							print("mh")
						else:
							rect_chef.move_ip(prova, prova2)
							print("wat")
							print (rect_chef.x, rect_chef.y)	
							camminiamo.settaLeft()
							nuovaPoz = ristampaMovi(world, rect_chef.x, rect_chef.y)
							ristampa(font, poz, personaggio, world, rect_chef.x, rect_chef.y, -steps, 0, nuovaPoz)
						if (rect_chef.x >= 540 and rect_chef.x <=580) and (rect_chef.y <= 780 and rect_chef.y >= 745):
							time.sleep(1)
							main = False
												
				if event.key == pygame.K_RIGHT:
					if(rect_chef.x < 1120):
						#print ("ou")
						#print ("ou")
						x2 = rect_chef.x + steps
						y2 = rect_chef.y
						#print(x)
						#print (rect_chef.x, rect_chef.y)
						#print(x2, y2)
						prova = x2 - rect_chef.x
						prova2 = y2 - rect_chef.y
						rect_prova = rect_chef.move(prova, prova2)
						if(rect_prova.colliderect(rect_oca1) or rect_prova.colliderect(rect_oca2)):
							print("mh")
						else:
							rect_chef.move_ip(prova, prova2)
							print("wat")
							print (rect_chef.x, rect_chef.y)
							camminiamo.settaRight()
							nuovaPoz = ristampaMovi(world, rect_chef.x, rect_chef.y)
							ristampa(font, poz, personaggio, world, rect_chef.x, rect_chef.y, -steps, 0, nuovaPoz)
							pygame.display.flip()
						if (rect_chef.x >= 540 and rect_chef.x <=580) and (rect_chef.y <= 780 and rect_chef.y >= 745):
							time.sleep(1)
							main = False
													
					
				if event.key == pygame.K_UP:
					if ( rect_chef.y > 20 ):
						#print ("ou")
						#print ("ou")
						y2 = rect_chef.y - steps
						x2 = rect_chef.x
						#print(x)
						#print (rect_chef.x, rect_chef.y)
						#print(x2, y2)
						prova = x2 - rect_chef.x
						prova2 = y2 - rect_chef.y
						rect_prova = rect_chef.move(prova, prova2)
						if(rect_prova.colliderect(rect_oca1) or rect_prova.colliderect(rect_oca2)):
							print("mh")
						else:
							rect_chef.move_ip(prova, prova2)
							camminiamo.settaUP()
							nuovaPoz = ristampaMovi(world, rect_chef.x, rect_chef.y)
							ristampa(font, poz, personaggio, world, rect_chef.x, rect_chef.y, -steps, 0, nuovaPoz)
							pygame.display.flip()
						if (rect_chef.x >= 540 and rect_chef.x <=580) and (rect_chef.y <= 780 and rect_chef.y >= 745):
							time.sleep(1)
							main = False
					
								
				if event.key == pygame.K_DOWN:
					if(rect_chef.y < 780 ): 
						#print ("ou")
						#print ("ou")
						y2 = rect_chef.y + steps
						x2 = rect_chef.x
						#print(x)
						#print (rect_chef.x, rect_chef.y)
						#print(x2, y2)
						prova = x2 - rect_chef.x
						prova2 = y2 - rect_chef.y
						rect_prova = rect_chef.move(prova, prova2)
						if(rect_prova.colliderect(rect_oca1) or rect_prova.colliderect(rect_oca2)):
							print("mh")
						else:
							rect_chef.move_ip(prova, prova2)
							camminiamo.settaDOWN()
							nuovaPoz = ristampaMovi(world, rect_chef.x, rect_chef.y)
							ristampa(font, poz, personaggio, world, rect_chef.x, rect_chef.y, -steps, 0, nuovaPoz)
							pygame.display.flip()
						if (rect_chef.x >= 540 and rect_chef.x <=580) and (rect_chef.y <= 780 and rect_chef.y >= 745):
							time.sleep(0.5)
							main = False
							
				if event.key == pygame.K_RETURN:
					if((rect_chef.y >= 320 and rect_chef.y <= 670) and rect_chef.x == 170):
						dialogoOcaGialla(world, boxGialla)
						posFerma = camminiamo.stand()
						ristampa(font, poz, personaggio, world, rect_chef.x, rect_chef.y, -steps, 0, posFerma)
					elif((rect_chef.y >= 210 and rect_chef.y <= 290) and (rect_chef.x >= 650 and rect_chef.x <= 710)) and personaggio.getPrimaBat() != 1:
						dialogoOcaGialla(world, boxVerde)
						sfida1.main(personaggio, FLAGPAUSE, volume)
						colonnaSonora(volume, FLAGPAUSE)
						posFerma = camminiamo.stand()
						ristampa(font, poz, personaggio, world, rect_chef.x, rect_chef.y, -steps, 0, posFerma)
						pygame.display.flip()
				if event.key == pygame.K_ESCAPE:
					main = False

				
		pygame.display.flip()

