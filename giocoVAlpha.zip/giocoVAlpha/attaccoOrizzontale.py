import PiumaAttacco
import pygame
import random
import Player
import time

class AttaccoOri():

	def __init__(self): 
		self.arrayPiume = []
		self.setAttacco = 0
		self.arrayID = []
		
	def pushPiuma(self, piuma):
		self.arrayPiume.append(piuma)
		
	def returnArrayPiuma(self):
		return self.arrayPiume
		
	
	def attaccoOrizzontale(self, world, P1, player):
	
		#pygame.time.set_timer(player.colpito(), 3000)
		
		clock1 = pygame.time.Clock()
		flagAttendi = True
		aaa = 0

		for i in range(abs(self.setAttacco)):
			#self.listaRan.append(ran)
			
			if self.setAttacco > 0:
				prova1 = P1 - self.arrayPiume[i].getRectPiuma().x		
				self.arrayPiume[i].spostaPiuma(prova1)
					#print(arrayPiume[i].getRectPiuma().x)

					#pygame.display.flip()
					#attaccoOrizzontale(world, P1, P2, verti)
				#print(self.arrayPiume[i].getRectPiuma().y)
				#pygame.draw.rect(world, (255,0,0), self.arrayPiume[i].getRectPiuma()) 
				if(	self.arrayPiume[i].getRectPiuma().colliderect(player.getRectPlayer()) and flagAttendi == True):
					flagAttendi = False
				
				if(self.arrayPiume[i].getRectPiuma().colliderect(player.getRectPlayer())):
					if self.arrayPiume[i].getId() in self.arrayID:
						a = 10
					else:
						#print("yooo")
						self.arrayID.append(self.arrayPiume[i].getId())
				else:
					if(self.arrayPiume[i].getId() in self.arrayID):
						a = 12
					else:
						world.blit(self.arrayPiume[i].getSurfPiuma(), (self.arrayPiume[i].getRectPiuma().x, self.arrayPiume[i].getRectPiuma().y))
				#print(player.colpito_player)
				
				
		
					


			else:
				prova1 = P1 - self.arrayPiume[-(i +1)].getRectPiuma().x		
				self.arrayPiume[-(i +1)].spostaPiuma(prova1)
					#print(arrayPiume[i].getRectPiuma().x)

					#pygame.display.flip()
					#attaccoOrizzontale(world, P1, P2, verti)
				#print(self.arrayPiume[-(i +1)].getRectPiuma().y)
				#pygame.draw.rect(world, (255,0,0), self.arrayPiume[-(i +1)].getRectPiuma()) 
			#	world.blit(self.arrayPiume[-(i +1)].getSurfPiuma(), (self.arrayPiume[-(i +1)].getRectPiuma().x, self.arrayPiume[-(i +1)].getRectPiuma().y))		
				if(	self.arrayPiume[-(i +1)].getRectPiuma().colliderect(player.getRectPlayer()) and flagAttendi == True):
					flagAttendi = False
				if(	self.arrayPiume[-(i +1)].getRectPiuma().colliderect(player.getRectPlayer())):
					if (self.arrayPiume[-(i +1)].getId() in self.arrayID):
						print("ce")
					else:
						print("yooo")
						self.arrayID.append(self.arrayPiume[-(i +1)].getId())
				else:
					if(self.arrayPiume[-(i +1)].getId() in self.arrayID):
						print("nop")
					else:
						world.blit(self.arrayPiume[-(i +1)].getSurfPiuma(), (self.arrayPiume[-(i +1)].getRectPiuma().x, self.arrayPiume[-(i +1)].getRectPiuma().y))		
				print(self.arrayPiume[-(i+1)].getRectPiuma().x)
				print(self.arrayPiume[i].getRectPiuma().x)
		if(P1 < 120):
			self.arrayID = []			
		return flagAttendi

						
	def settingAttacco(self, val):
		self.setAttacco = val
		
		
		
		
		
