import pygame, sys
import pygame_menu #libreria di pygame che permette una facile creazione del main menu di gioco
from pygame_menu import sound
from pygame.locals import *
import mappaLivelli
import time, datetime
import crazyPalace
import classPG
import Camminata

'''
Variables

'''

camminiamo = Camminata.Camminata()
flag = 0
star = [0, 0, 0, 0 ,0]


PATH_DX = 'Immagini_Gioco/HUB/chefCammina.png'
PATH_SX = 'Immagini_Gioco/HUB/chef2sx.png'
box1 = "Immagini_Gioco/HUB/dialogBox1.jpg"
box2 = "Immagini_Gioco/HUB/dialogBox2.jpg"

'''
Objects
'''


#class Player(pygame.sprite.Sprite):
 #   """
  #  Spawn a player
   # """
#
 #   def __init__(self):
  #      pygame.sprite.Sprite.__init__(self)
   #     self.movex = 0
    #    self.movey = 0
     #   self.frame = 0
      #  self.images = []
       # for i in range(1, 5):
        #    img = pygame.image.load('Immagini_Gioco/chefCammina.png').convert()
         #   img.convert_alpha()  # optimise alpha
          #  img.set_colorkey(ALPHA)  # set alpha
           # self.images.append(img)
            #self.image = self.images[0]
            #self.rect = self.image.get_rect()

#    def control(self, x, y):
 #       """
  #      control player movement
   #     """
    #    self.movex += x
     #   self.movey += y

 #   def update(self):
  #      """
   #     Update sprite position
    #    """
#
 #       self.rect.x = self.rect.x + self.movex
  #      self.rect.y = self.rect.y + self.movey
#
 #       # moving left
  #      if self.movex < 0:
   #         self.frame += 1
    #        if self.frame > 3*ani:
     #           self.frame = 0
      #      self.image = pygame.transform.flip(self.images[self.frame // ani], True, False)
#
 #       # moving right
  #      if self.movex > 0:
   #         self.frame += 1
    #        if self.frame > 3*ani:
     #           self.frame = 0
      #      self.image = self.images[self.frame//ani]
#

'''
Setup

'''

#def crea_stanza():
#	print("cristo")
#	surf_background = pygame.image.load("Immagini_Gioco/HUB/pavimentociccio.png").convert()
#	world.blit(surf_background, (0, 0))
#	pygame.display.flip()

def ristampaMovi(world, x, y):
	
	path_stampa = camminiamo.ristampaMovi()
	surf_posizione= pygame.image.load(path_stampa)
	world.blit(surf_posizione, (x,y))
	return path_stampa

def colonnaSonora(volume,FLAGPAUSE):
	if(FLAGPAUSE == True):
		pygame.mixer.music.load("Suoni/colonnaSonora.ogg")
		pygame.mixer.music.play(-1)   #play della colonna sonora -1 ---> indica per tempo infinito
		pygame.mixer.music.set_volume(volume)
		pygame.mixer.music.pause()
	else:
		pygame.mixer.music.load("Suoni/colonnaSonora.ogg")
		pygame.mixer.music.play(-1)   #play della colonna sonora -1 ---> indica per tempo infinito
		pygame.mixer.music.set_volume(volume)
		
											

def ristampa(font, poz, personaggio, world, x, y, prov, i, PATH):

	surf_background = pygame.image.load("Immagini_Gioco/provaASSETT_mappa/provaCitta.png").convert()
	world.blit(surf_background, (0, 0))
	
	surf_ciccio=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/q.png")
	rect_ciccio = surf_ciccio.get_rect()
	xCic=270
	yCic=30  
	rect_ciccio.move_ip(xCic, yCic) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_ciccio, (xCic,yCic))	
	
	surf_crazy =pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/crazyPalazzo.png")
	rect_crazy = surf_crazy.get_rect()
	xCra=40
	yCra=560
	rect_crazy.move_ip(xCra, yCra) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_crazy, (xCra,yCra))	
	
	surf_albero =pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/alberello.png")
	rect_albero = surf_albero.get_rect()
	xAl=0
	yAl=30
	rect_albero.move_ip(xAl, yAl) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_albero, (xAl,yAl))	
	
	surf_area=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/cambiaArea.jpg")
	rect_area = surf_area.get_rect()
	xA=330
	yA=340 
	rect_area.move_ip(xA, yA) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_area, (xA,yA))
	
	surf_area2=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/cambiaArea.jpg")
	rect_area2 = surf_area2.get_rect()
	xA2=83 
	yA2=770  
	rect_area2.move_ip(xA2, yA2) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_area2, (xA2,yA2))
	
	surf_chef=pygame.image.load(PATH)
	world.blit(surf_chef, (x,y))
	
	surf_orologio= pygame.image.load("Immagini_Gioco/Immagini_Livello/orologio.png")
	rect_orologio = surf_orologio.get_rect()
	xOr=1100
	yOr=50  
	rect_orologio.move_ip(xOr, yOr)
	world.blit(surf_orologio, (xOr,yOr))
	world.blit(surf_orologio, (xOr,yOr))
	poz.fill((255, 255, 255))#serve per cancellare il contenuto della surface in modo da fare il timer decrescente
	poz = font.render(personaggio.getStringa(), True, (0, 187, 45), (255, 255, 255))
	world.blit(poz, (1155, 134))

	
	
		
def main(personaggio, FLAGPAUSE, volume, x, y):	
	#pygame.init()
	worldx = 1280
	worldy = 920
	fps = 40
	ani = 4
	world = pygame.display.set_mode((worldx, worldy))
	global flag
	flag
	#backdrop = pygame.image.load("Immagini_Gioco/background_menu/rossa2.jpg").convert()
	clock = pygame.time.Clock()
	#backdropbox = world.get_rect()
	main = True
	muovix = 0

	#player = Player()  # spawn player
	#player.rect.x = 0  # go to x
	#player.rect.y = 0  # go to y
	steps = 10


	surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/bgCitta1.jpg").convert()
	world.blit(surf_background, (0, 0))
	
	surf_ciccio=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/q.png")
	rect_ciccio = surf_ciccio.get_rect()
	xCic=270
	yCic=30  
	rect_ciccio.move_ip(xCic, yCic) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_ciccio, (xCic,yCic))
	
	surf_crazy =pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/crazyPalazzo.png")
	rect_crazy = surf_crazy.get_rect()
	xCra=40
	yCra=560  
	rect_crazy.move_ip(xCra, yCra) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	pygame.draw.rect(world, (255,0,0), rect_crazy) 
	world.blit(surf_crazy, (xCra,yCra))	
	
	surf_albero =pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/alberello.png")
	rect_albero = surf_albero.get_rect()
	xAl=0
	yAl=30  
	rect_albero.move_ip(xAl, yAl) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_albero, (xAl,yAl))	

	surf_area=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/cambiaArea.jpg")
	rect_area = surf_area.get_rect()
	xA=330 
	yA=340  
	rect_area.move_ip(xA, yA) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_area, (xA,yA))
	
	surf_area2=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/cambiaArea.jpg")
	rect_area2 = surf_area2.get_rect()
	xA2=83 
	yA2=770  
	rect_area2.move_ip(xA2, yA2) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_area2, (xA2,yA2))

	surf_orologio= pygame.image.load("Immagini_Gioco/Immagini_Livello/orologio.png")
	rect_orologio = surf_orologio.get_rect()
	xOr=1100
	yOr=50  
	rect_orologio.move_ip(xOr, yOr)
	world.blit(surf_orologio, (xOr,yOr))
	
		


	surf_chef=pygame.image.load(camminiamo.getDownPath())
	rect_chef = surf_chef.get_rect()
	rect_chef.move_ip(x, y) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_chef, (x,y))
	
	font = pygame.font.SysFont("Verdana", 34, bold=True, italic=True)
	poz = font.render(personaggio.getStringa(), True,  (0, 187, 45), (255, 255, 0))



	pygame.display.flip()
	pygame.key.set_repeat(10,10)  #serve per lo spostamento
	pygame.time.set_timer(pygame.USEREVENT, 1000)
	clock1 = pygame.time.Clock()
	'''
	Main Loop
	'''

	while main:
		clock1.tick(27)
		#print(personaggio.getStringa())
		if personaggio.getTimer() == 0:
			main = False
			
		#print(volume)
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				sys.exit()
				
			if event.type == pygame.USEREVENT:
				personaggio.diminuisci()
				personaggio.setStringa(personaggio.getTimer())
				print(personaggio.getTimer())
				world.blit(surf_orologio, (xOr,yOr))
				poz.fill((255, 255, 255))#serve per cancellare il contenuto della surface in modo da fare il timer decrescente
				poz = font.render(personaggio.getStringa(), True, (0, 187, 45), (255, 255, 255))
				world.blit(poz, (1155, 134))
		        
			if event.type == pygame.KEYDOWN:
				if event.key == pygame.K_LEFT:
					if(rect_chef.x > 10):
						print ("ou")
						x2 = rect_chef.x - steps
						y2 = rect_chef.y
						print(x)
						print (rect_chef.x, rect_chef.y)
						print(x2, y2)
						prova = x2 - rect_chef.x
						prova2 = y2 - rect_chef.y
						rect_prova = rect_chef.move(prova, prova2)
						if rect_prova.colliderect(rect_ciccio) or rect_prova.colliderect(rect_crazy):
							print("fermo")
						else:
						
							rect_chef.move_ip(prova, prova2)
							print("wat")
							print (rect_chef.x, rect_chef.y)	
							camminiamo.settaLeft()
							nuovaPoz = ristampaMovi(world, rect_chef.x, rect_chef.y)
							ristampa(font, poz, personaggio, world, rect_chef.x, rect_chef.y, -steps, 0, nuovaPoz)
							if((rect_chef.x >= 300 and rect_chef.x <=340) and (rect_chef.y <= 320 and rect_chef.y >= 270)):
								time.sleep(1)
								main = False	
							elif((rect_chef.x >= 60 and rect_chef.x <=90) and (rect_chef.y >= 720 and rect_chef.y <= 740)):
								time.sleep(1)
								crazyPalace.main(personaggio, FLAGPAUSE, volume, 570 , 660)		
								posFerma = camminiamo.stand()
								rect_chef.move_ip(60, 40)
								ristampa(font, poz, personaggio, world, 160, 730, -steps, 0, posFerma)
								pygame.display.flip()					
				if event.key == pygame.K_RIGHT:
					if(rect_chef.x < 1120):
						print ("ou")
						print ("ou")
						x2 = rect_chef.x + steps
						y2 = rect_chef.y
						print(x)
						print (rect_chef.x, rect_chef.y)
						print(x2, y2)
						prova = x2 - rect_chef.x
						prova2 = y2 - rect_chef.y
						rect_prova = rect_chef.move(prova, prova2)
						if rect_prova.colliderect(rect_ciccio)  or rect_prova.colliderect(rect_crazy):
							print("fermo")
						else:
							rect_chef.move_ip(prova, prova2)
							print("wat")
							print (rect_chef.x, rect_chef.y)
							camminiamo.settaRight()
							nuovaPoz = ristampaMovi(world, rect_chef.x, rect_chef.y)
							ristampa(font, poz, personaggio, world, rect_chef.x, rect_chef.y, -steps, 0, nuovaPoz)
							pygame.display.flip()
							if((rect_chef.x >= 300 and rect_chef.x <=340) and (rect_chef.y <= 320 and rect_chef.y >= 270)):
								time.sleep(1)
								main = False
							elif((rect_chef.x >= 60 and rect_chef.x <=90) and (rect_chef.y >= 720 and rect_chef.y <= 740)):
								time.sleep(1)
								crazyPalace.main(personaggio, FLAGPAUSE, volume, 570 , 660)	
								posFerma = camminiamo.stand()
								rect_chef.move_ip(60, 40)
								ristampa(font, poz, personaggio, world, 160, 730, -steps, 0, posFerma)		
								pygame.display.flip()				
					
				if event.key == pygame.K_UP:
					if ( rect_chef.y > 20 ):
						print ("ou")
						print ("ou")
						y2 = rect_chef.y - steps
						x2 = rect_chef.x
						print(x)
						print (rect_chef.x, rect_chef.y)
						print(x2, y2)
						prova = x2 - rect_chef.x
						prova2 = y2 - rect_chef.y
						rect_prova = rect_chef.move(prova, prova2)
						if rect_prova.colliderect(rect_ciccio)  or rect_prova.colliderect(rect_crazy):
							print("fermo")
						else:
							rect_chef.move_ip(prova, prova2)
							camminiamo.settaUP()
							nuovaPoz = ristampaMovi(world, rect_chef.x, rect_chef.y)
							ristampa(font, poz, personaggio, world, rect_chef.x, rect_chef.y, -steps, 0, nuovaPoz)
							pygame.display.flip()
							if((rect_chef.x >= 300 and rect_chef.x <=340) and (rect_chef.y <= 320 and rect_chef.y >= 270)):
								time.sleep(1)
								main = False
							elif((rect_chef.x >= 60 and rect_chef.x <=90) and (rect_chef.y >= 720 and rect_chef.y <= 740)):
								time.sleep(1)
								crazyPalace.main(personaggio, FLAGPAUSE, volume, 570 , 660)	
								posFerma = camminiamo.stand()
								rect_chef.move_ip(60, 40)
								ristampa(font, poz, personaggio, world, 160, 730, -steps, 0, posFerma)
								pygame.display.flip()
								
				if event.key == pygame.K_DOWN:
					if(rect_chef.y < 780 ): 
						print ("ou")
						print ("ou")
						y2 = rect_chef.y + steps
						x2 = rect_chef.x
						print(x)
						print (rect_chef.x, rect_chef.y)
						print(x2, y2)
						prova = x2 - rect_chef.x
						prova2 = y2 - rect_chef.y
						rect_prova = rect_chef.move(prova, prova2)
						if rect_prova.colliderect(rect_ciccio)  or rect_prova.colliderect(rect_crazy):
							print("fermo")
						else:
							rect_chef.move_ip(prova, prova2)
							camminiamo.settaDOWN()
							nuovaPoz = ristampaMovi(world, rect_chef.x, rect_chef.y)
							ristampa(font, poz, personaggio, world, rect_chef.x, rect_chef.y, -steps, 0, nuovaPoz)
							pygame.display.flip()
							if((rect_chef.x >= 300 and rect_chef.x <=340) and (rect_chef.y <= 320 and rect_chef.y >= 270)):
								time.sleep(1)
								main = False
							elif((rect_chef.x >= 60 and rect_chef.x <=90) and (rect_chef.y >= 720 and rect_chef.y <= 740)):
								time.sleep(1)
								crazyPalace.main(personaggio, FLAGPAUSE, volume, 570 , 660)	
								posFerma = camminiamo.stand()
								rect_chef.move_ip(40, 40)
								ristampa(font, poz, personaggio, world, 160, 730, -steps, 0, posFerma)
								pygame.display.flip()
					
				if event.key == pygame.K_ESCAPE:
					main = False
			
				
		pygame.display.flip()

