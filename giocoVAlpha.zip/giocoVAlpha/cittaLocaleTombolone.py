import pygame, sys
import pygame_menu #libreria di pygame che permette una facile creazione del main menu di gioco
from pygame_menu import sound
from pygame.locals import *
import mappaLivelli
import time, datetime
import crazyPalace
import classPG
import Camminata
import Player
import gestioneCitta
import dialoghiNPC_secondari
import tavernaTombolone

camminiamo = Camminata.Camminata()
miaArea = gestioneCitta.areaCiccios("Immagini_Gioco/provaASSETT_mappa/mappaTombola.jpg")
#player = Player.Player(camminiamo.getUpPath(), 550, 780)
#camminiamo = Camminata.Camminata()
#player = Player.Player(camminiamo.getUpPath(), 550, 780)
flagColl = 0
dialogo = dialoghiNPC_secondari.Dialogo()


def ristampaMovi(world, x, y):
	
	path_stampa = camminiamo.ristampaMovi()
	surf_posizione= pygame.image.load(path_stampa)
	world.blit(surf_posizione, (x,y))
	return path_stampa
	
def settaCollsioni():
	miaArea.settaCollisione(pygame.Rect((590, 0), (700, 270))) #rectBosco sopra
	miaArea.settaCollisione(pygame.Rect((890, 270), (400, 90)))	#rect Albero in basso destra
	miaArea.settaCollisione(pygame.Rect((700, 535), (980, 570))) # rect albero in basso sinistra
	miaArea.settaCollisione(pygame.Rect((0, 0), (200, 900))) # rect albero vicino casa
	miaArea.settaCollisione(pygame.Rect((0, 0), (200, 900))) # rect tronchetto
	miaArea.settaCollisione(pygame.Rect((200, 0), (240, 320))) # rect pietra alto sinistra
	miaArea.settaCollisione( pygame.Rect((155, 450), (100, 100))) # pietra vicino casa
	miaArea.settaCollisione(pygame.Rect((465, 510), (60, 62))) # palo casa sinistra
	miaArea.settaCollisione(pygame.Rect((155, 580), (185, 160)))
	miaArea.settaCollisione(pygame.Rect((450, 590), (30, 70)))
	miaArea.settaCollisione(pygame.Rect((590, 728), (40, 40)))

	
	#### RECT PER CAMBIO AREA ####
	miaArea.settaCollisione(pygame.Rect((490, 0), (40, 30)) ) #cambioAreaSopra (11 rect)
	miaArea.settaCollisione(pygame.Rect((680, 235), (70, 70)))
	
def ristampa(world, x, y, PATH, player):
	world.blit(miaArea.getSurfArea(), (0, 0))	
	surf_area2=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/cambiaAreaPiccola.jpg")
	xA2=480
	yA2=0
	world.blit(surf_area2, (xA2,yA2))
	surf_Player=pygame.image.load(PATH)
	world.blit(surf_Player, (x,y))	
	
	surf_area24=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/cambiaAreaPiccola.jpg")
	xA2=682
	yA2= 350
	world.blit(surf_area24, (xA2,yA2))
	
	surf_Player=pygame.image.load(PATH)
	world.blit(surf_Player, (x,y))
	#pygame.draw.rect(world, (1,0,0), rect1 ) 	
#	rect1= pygame.Rect((590, 0), (700, 270))
#	pygame.draw.rect(world, (1,0,0), rect1 ) 
#	rect2= pygame.Rect((890, 270), (400, 90))
#	pygame.draw.rect(world, (255,0,0), rect2 )
#	rect3= pygame.Rect((700, 535), (980, 570))
#	pygame.draw.rect(world, (0,0,255), rect3 ) 
#	rect4= pygame.Rect((0, 0), (200, 900))
#	pygame.draw.rect(world, (0,0,255), rect4 )
#	rect5= pygame.Rect((0, 0), (200, 900))
#	pygame.draw.rect(world, (0,0,255), rect5 )  
#	rect6= pygame.Rect((200, 0), (240, 320))
#	pygame.draw.rect(world, (0,255,255), rect6 )  
#	rect7= pygame.Rect((155, 450), (100, 100))
#	pygame.draw.rect(world, (0,255,255), rect7 ) 
#	rect8= pygame.Rect((465, 510), (50, 50))
#	pygame.draw.rect(world, (255,255,255), rect8 )  
#	rect9= pygame.Rect((155, 580), (185, 160))
	#pygame.draw.rect(world, (0,255,255), rect9 )
#	rect10= pygame.Rect((450, 590), (30, 70))
#	pygame.draw.rect(world, (0,100,255), rect10 )
#	rect11= pygame.Rect((590, 728), (40, 40))
#	pygame.draw.rect(world, (0,100,255), rect11 )       
	#pygame.draw.rect(world, (0,0,255), player.rect_player ) 
	#rect2= pygame.Rect((500, 650), (380, 50))
	#pygame.draw.rect(world, (1,0,0), rect2 )
	#rect3= pygame.Rect((500, 290), (40, 400))
	#pygame.draw.rect(world, (1,0,0), rect3 )	
	#rect4= pygame.Rect((430, 370), (100, 210))
	#pygame.draw.rect(world, (1,0,0), rect4 )
	#rect5= pygame.Rect((550, 258), (300, 110))
	#pygame.draw.rect(world, (1,0,0), rect5 )
	#rect6= pygame.Rect((680, 158), (160, 110))
	#pygame.draw.rect(world, (1,255,0), rect6 )
	#rect7= pygame.Rect((125, 198), (120, 120))
	#pygame.draw.rect(world, (1,255,0), rect7 )
	#rect8= pygame.Rect((175, 728), (110, 110))
	#pygame.draw.rect(world, (1,255,0), rect8 )
	#rect1= pygame.Rect((1250, 430), (50, 50))
	#pygame.draw.rect(world, (1,0,0), rect1 ) 
	#pygame.draw.rect(world, (0,0,255), player.rect_player ) 
	#rect13= pygame.Rect((490, 0), (40, 30))
	#pygame.draw.rect(world, (0,100,255), rect13 )
	

def main(player, inventario):
	global flagColl
	
	pygame.init()
	worldx = 1280
	worldy = 920
	fps = 40
	ani = 4
	world = pygame.display.set_mode((worldx, worldy))
	#backdrop = pygame.image.load("Immagini_Gioco/background_menu/rossa2.jpg").convert()
	clock = pygame.time.Clock()
	#backdropbox = world.get_rect()
	main = True
	muovix = 0

	#player = Player()  # spawn player
	#player.rect.x = 0  # go to x
	#player.rect.y = 0  # go to y
	steps = 10

	world.blit(miaArea.getSurfArea(), (0, 0))	
	
	surf_area2=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/cambiaAreaPiccola.jpg")
	xA2=480
	yA2=0
	world.blit(surf_area2, (xA2,yA2))
	
	surf_area24=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/cambiaAreaPiccola.jpg")
	xA2=682
	yA2= 350
	world.blit(surf_area24, (xA2,yA2))
	
	

	
	nuovaPoz = camminiamo.getDownPath()	
	player.settaPoz(world, 470, 80)
	world.blit(pygame.image.load(nuovaPoz), (player.getRectPlayer().x , player.getRectPlayer().y))
	#rect1= pygame.Rect((580, 0), (340, 320))
	#pygame.draw.rect(world, (1,0,0), rect1 ) 
	
	pygame.key.set_repeat(27,27)
	if(flagColl == 0):
		settaCollsioni()
	pygame.display.flip()
	
	while main:
		print(player.rect_player.x)
		clock.tick(27)
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				sys.exit()
			elif event.type == pygame.MOUSEBUTTONDOWN:
				click = event.pos
				print(click)
				
			if event.type == pygame.KEYDOWN:
				if event.key == pygame.K_LEFT:
					x2 = player.getRectPlayer().x - steps
					y2 = player.getRectPlayer().y
					prova = x2 - player.getRectPlayer().x
					prova2 = y2 - player.getRectPlayer().y
					rect_prova = player.getRectPlayer().move(prova, prova2)
					if(miaArea.verificaCollisione3(rect_prova) == False):
						if(rect_prova.x < 0):
							print("m")
						else:
							player.setRect(prova, prova2)
							camminiamo.settaLeft()
							nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
							ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player)
							
								
						
				if (event.key == pygame.K_RIGHT):
					x2 = player.getRectPlayer().x + steps
					y2 = player.getRectPlayer().y
					prova = x2 - player.getRectPlayer().x
					prova2 = y2 - player.getRectPlayer().y
					rect_prova = player.getRectPlayer().move(prova, prova2)
					if(miaArea.verificaCollisione3(rect_prova) == False):
						if(rect_prova.x < 1210):
							player.setRect(prova, prova2)
							camminiamo.settaRight()
							nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
							ristampa(world, player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player)
					
					
				if event.key == pygame.K_UP :
					x2 = player.getRectPlayer().x
					y2 = player.getRectPlayer().y - steps
					prova = x2 - player.getRectPlayer().x
					prova2 = y2 - player.getRectPlayer().y
					rect_prova = player.getRectPlayer().move(prova, prova2)
					if(miaArea.verificaCollisione3(rect_prova) == False):
						if(rect_prova.y > 0):
							player.setRect(prova, prova2)
							camminiamo.settaUP()
							nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
							ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player)	
							

													
					
							
								
				if event.key == pygame.K_DOWN:
					x2 = player.getRectPlayer().x
					y2 = player.getRectPlayer().y + steps
					prova = x2 - player.getRectPlayer().x
					prova2 = y2 - player.getRectPlayer().y
					rect_prova = player.getRectPlayer().move(prova, prova2)
					if(miaArea.verificaCollisione3(rect_prova) == False):
						if(rect_prova.y < 790):
							player.setRect(prova, prova2)
							camminiamo.settaDOWN()
							nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
							ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player)
								
				if event.key == pygame.K_DOWN or event.key == pygame.K_UP  or event.key == pygame.K_RIGHT or event.key == pygame.K_LEFT:
					if (miaArea.rectCollisioni[11].colliderect(rect_prova)):
						flagColl = 1
						main = False
					if (miaArea.rectCollisioni[12].colliderect(rect_prova)):
						tavernaTombolone.main(player, inventario)
						if(player.ricominciaDopoSconfitta == True):
							main = False
						player.settaPoz(world, 690, 330)
						camminiamo.settaDOWN()
						nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
						ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player)
				if event.key == 105:
					inventario.stampaInventario(player, world)
					ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player)
				
				#if event.key  == pygame.K_RETURN:
				#	if (miaArea.rectCollisioni[6].colliderect(rect_prova)):
				#		print("parlo con doggo ")
				#		dialogo.stampaDialoghi(world, 1, "Immagini_Gioco/DialoghiNPC/npc_secondari/doggoArmor.png")
				#		ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player)
				#	elif (miaArea.rectCollisioni[7].colliderect(rect_prova)):
				#		dialogo.stampaDialoghi(world, 2, "Immagini_Gioco/DialoghiNPC/npc_secondari/osvaldo.png")
				#		ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player)
				#		print("parlo con omino ")
					
			pygame.display.flip()

