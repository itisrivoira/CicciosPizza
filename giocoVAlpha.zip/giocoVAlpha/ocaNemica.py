import pygame, sys

class Oca():

	def __init__ (self, pathOca):
		
		self.surfOca = pygame.image.load(pathOca)
		self.rectOca = pygame.Rect((830, 425), (200, 200))
		self.PP = 0
		self.HP = self.PP
		self.pizzaBar = [pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/pizzaBar/healthBarFullPizza.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/pizzaBar/PizzaBarFull90.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/pizzaBar/pizzaBar80.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/pizzaBar/pizzaBar70.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/pizzaBar/pizzaBar60.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/pizzaBar/pizzaBar50.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/pizzaBar/pizzaBar40.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/pizzaBar/pizzaBar30.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/pizzaBar/pizzaBar20.png") , pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/barreVita/pizzaBar/pizzaBar10.png") ]
		self.colore = ""
		
		
		
	def getSurfOca(self):
		
		return self.surfOca
		
	def getRectOca(self):
		
		return self.rectOca 
		
	def colpita(self, val):
		self.HP = self.HP - val
		print(self.HP)
		
	def ritornaPizzaBar(self):
		if (self.HP <= (self.PP / 100) * 90 and self.HP > (self.PP / 100) * 80):
			return self.pizzaBar[1]
		elif (self.HP <= (self.PP / 100) * 80 and self.HP > (self.PP / 100) * 70):
			return self.pizzaBar[2]		
		elif (self.HP <= (self.PP / 100) * 70 and self.HP > (self.PP / 100) * 60):
			return self.pizzaBar[3]
		elif (self.HP <= (self.PP / 100) * 60 and self.HP > (self.PP / 100) * 50):
			return self.pizzaBar[4]
		elif (self.HP <= (self.PP / 100) * 50 and self.HP > (self.PP / 100) * 40):
			return self.pizzaBar[5]
		elif (self.HP <= (self.PP / 100) * 40 and self.HP > (self.PP / 100) * 30):
			return self.pizzaBar[6]			
		elif (self.HP <= (self.PP / 100) * 30 and self.HP > (self.PP / 100) * 20):
			return self.pizzaBar[7]	
		elif (self.HP <= (self.PP / 100) * 20 and self.HP > (self.PP / 100) * 10):
			return self.pizzaBar[8]	
		elif (self.HP <= (self.PP / 100) * 10):
			return self.pizzaBar[9]
		else:
			return self.pizzaBar[0]
