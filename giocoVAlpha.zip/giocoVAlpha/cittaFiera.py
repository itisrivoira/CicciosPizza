import pygame, sys
import pygame_menu #libreria di pygame che permette una facile creazione del main menu di gioco
from pygame_menu import sound
from pygame.locals import *
import mappaLivelli
import time, datetime
import crazyPalace
import classPG
import Camminata
import Player
import gestioneCitta
import pianura1


flagColl = 0
miaArea = gestioneCitta.areaCiccios("Immagini_Gioco/provaASSETT_mappa/ciccioMappa.jpg")
camminiamo = Camminata.Camminata()
#player = Player.Player(camminiamo.getUpPath(), 800, 700)


def ristampaMovi(world, x, y):
	
	path_stampa = camminiamo.ristampaMovi()
	surf_posizione= pygame.image.load(path_stampa)
	world.blit(surf_posizione, (x,y))
	return path_stampa
	
def settaCollsioni():
	miaArea.settaCollisione(pygame.Rect((0, 0), (1280, 280))) #rectBosco sopra
	miaArea.settaCollisione(pygame.Rect((950, 600), (380, 550)))	#rect Albero in basso destra
	miaArea.settaCollisione(pygame.Rect((50, 655), (230, 320))) # rect albero in basso sinistra
	miaArea.settaCollisione(pygame.Rect((470, 420), (200, 200))) # rect albero vicino casa
	miaArea.settaCollisione(pygame.Rect((540, 270), (100, 100))) # rect tronchetto
	miaArea.settaCollisione(pygame.Rect((120, 255), (100, 100))) # rect pietra alto sinistra
	miaArea.settaCollisione(pygame.Rect((540, 630), (100, 100))) # pietra vicino casa
	miaArea.settaCollisione(pygame.Rect((630, 440), (65, 220))) # palo casa sinistra
	miaArea.settaCollisione(pygame.Rect((870, 440), (65, 220)))# palo casa destra
	miaArea.settaCollisione(pygame.Rect((720, 550), (100, 100)))	 #rect per entrare in casa
	miaArea.settaCollisione(pygame.Rect((0, 450), (30, 100)))
	
def ristampa(world, x, y, PATH, player):
	world.blit(miaArea.getSurfArea(), (0, 0))	
	surf_area=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/cambiaArea.jpg")
	xA=742
	yA=720 
	world.blit(surf_area, (xA,yA))
	surf_area2=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/cambiaArea.jpg")
	xA2=0
	yA2=450
	world.blit(surf_area2, (xA2,yA2))
	surf_Player=pygame.image.load(PATH)
	world.blit(surf_Player, (x,y))	
	#pygame.draw.rect(world, (0,0,255), player.rect_player ) 

def main(player, inventario, flagUltimo = ""):
	global flagColl
	
	pygame.display.set_caption("MAPPA CICCIOS")
	pygame.init()
	worldx = 1280
	worldy = 920
	fps = 40
	ani = 4
	world = pygame.display.set_mode((worldx, worldy))
	#backdrop = pygame.image.load("Immagini_Gioco/background_menu/rossa2.jpg").convert()
	clock = pygame.time.Clock()
	#backdropbox = world.get_rect()
	main = True
	muovix = 0

	#player = Player()  # spawn player
	#player.rect.x = 0  # go to x
	#player.rect.y = 0  # go to y
	steps = 10

	world.blit(miaArea.getSurfArea(), (0, 0))
	
	#pygame.draw.rect(world, (1,0,0), rect1 ) 
	#pygame.draw.rect(world, (1,0,0), rect2 ) 
	#pygame.draw.rect(world, (1,222,0), rect3 ) 
	#pygame.draw.rect(world, (1,0,0), rect4 ) 
	#pygame.draw.rect(world, (200,0,0), rect5 ) 
	#pygame.draw.rect(world, (0,0,255), rect6 ) 
	#pygame.draw.rect(world, (0,0,255), rect7 ) 
	#pygame.draw.rect(world, (0,0,255), rect8 ) 
	#pygame.draw.rect(world, (0,0,255), rect9 ) 
	
	
	surf_area=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/cambiaArea.jpg")
	xA=742
	yA=720
	world.blit(surf_area, (xA,yA))
	
	surf_area2=pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/cambiaArea.jpg")
	xA2=0
	yA2=450
	world.blit(surf_area2, (xA2,yA2))

	player.settaPoz(world, 750, 700)
	nuovaPoz = camminiamo.getDownPath()
	world.blit(pygame.image.load(nuovaPoz), (player.getRectPlayer().x , player.getRectPlayer().y))
	
	if(flagColl == 0):
		settaCollsioni()
		flagColl = 1
	
	pygame.key.set_repeat(32,32)
	pygame.display.flip()
	
	while main:
		if (player.oca1 == True and player.oca2 == True and player.oca3 == True):
			main = False
		print(player.rect_player.x)
		clock.tick(27)
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				sys.exit()
			elif event.type == pygame.MOUSEBUTTONDOWN:
				click = event.pos
				print(click)
				
			if event.type == pygame.KEYDOWN:
				if event.key == pygame.K_LEFT:
					x2 = player.getRectPlayer().x - steps
					y2 = player.getRectPlayer().y
					prova = x2 - player.getRectPlayer().x
					prova2 = y2 - player.getRectPlayer().y
					rect_prova = player.getRectPlayer().move(prova, prova2)
					if(miaArea.verificaCollisione(rect_prova) == False):
						if(rect_prova.x > 0):
							if(miaArea.cambiaArea(rect_prova)):
								pianura1.main(player, inventario, flagUltimo)
								if(player.ricominciaDopoSconfitta == True):
									main = False
									flagColl = 1
								#player.setRect(110, prova2)
								player.settaPoz(world, 20, 440)
								camminiamo.settaRight()
								nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
								ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player)
							else:
								player.setRect(prova, prova2)
								camminiamo.settaLeft()
								nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
								ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player)
							
								
						
				if (event.key == pygame.K_RIGHT):
					x2 = player.getRectPlayer().x + steps
					y2 = player.getRectPlayer().y
					prova = x2 - player.getRectPlayer().x
					prova2 = y2 - player.getRectPlayer().y
					rect_prova = player.getRectPlayer().move(prova, prova2)
					if(miaArea.verificaCollisione(rect_prova) == False):
						player.setRect(prova, prova2)
						camminiamo.settaRight()
						nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
						ristampa(world, player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player)
					
					
				if event.key == pygame.K_UP :
					x2 = player.getRectPlayer().x
					y2 = player.getRectPlayer().y - steps
					prova = x2 - player.getRectPlayer().x
					prova2 = y2 - player.getRectPlayer().y
					rect_prova = player.getRectPlayer().move(prova, prova2)
					if(miaArea.verificaCollisione(rect_prova) == False):
						if(miaArea.verificaEntrata(player.getRectPlayer()) == True):
							flagColl = 1
							main = False
						else:	
							player.setRect(prova, prova2)
							camminiamo.settaUP()
							nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
							ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player)	

													
					
							
								
				if event.key == pygame.K_DOWN:
					x2 = player.getRectPlayer().x
					y2 = player.getRectPlayer().y + steps
					prova = x2 - player.getRectPlayer().x
					prova2 = y2 - player.getRectPlayer().y
					rect_prova = player.getRectPlayer().move(prova, prova2)
					if(miaArea.verificaCollisione(rect_prova) == False):
						if(rect_prova.y < 790):
							player.setRect(prova, prova2)
							camminiamo.settaDOWN()
							nuovaPoz = ristampaMovi(world, player.getRectPlayer().x, player.getRectPlayer().y)
							ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player)
				if event.key == 105:
					inventario.stampaInventario(player, world)
					ristampa(world,  player.getRectPlayer().x, player.getRectPlayer().y, nuovaPoz, player)
					
			pygame.display.flip()

#main()
