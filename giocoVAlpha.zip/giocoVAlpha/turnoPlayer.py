import pygame, sys
import pygame_menu #libreria di pygame che permette una facile creazione del main menu di gioco
from pygame_menu import sound
from pygame.locals import *
#import mappaLivelli
import time, datetime
#import crazyPalace
import classPG
import PiumaAttacco
import attaccoOrizzontale
import random
import Camminata
import Player
import ocaNemica
import battagliaUndertaleStile
import attacchiPlayer





pygame.font.init()
font = pygame.font.Font('Immagini_Gioco/DialoghiNPC/fontDialoghi/vito/Crashnumberinggothic-MAjp.ttf', 40, bold=True)
camminiamo = Camminata.Camminata()
#layer = Player.Player(camminiamo.getUpPath(), 200, 475)
attack = attacchiPlayer.Attacco()

def colonnaSonora(volume, oca):

	if oca.colore == "pizza":
		print("e")
		pygame.mixer.music.load("Suoni/finalBattle.ogg")
		pygame.mixer.music.play(-1)   #play della colonna sonora -1 ---> indica per tempo infinito
		pygame.mixer.music.set_volume(0.3)#volume)		

def cana(world, camminiamo, player, oca):
	for i in range(6):
		ristampa(world, player, 2, oca, 1)
		world.blit(pygame.image.load(camminiamo.array_canalizza[i]), (200,475))
		pygame.display.flip()
		time.sleep(0.25)
	world.blit(pygame.image.load("Immagini_Gioco/pizze/pizzeDaLancio/buffPizza.png"), (174, 310))
	pygame.display.flip()
	time.sleep(1.2)
	
def colpoPizza(world, player, oca):
	if(player.padella == "base"):
		for i in range(5):
			ristampa(world, player, 2, oca, 1)
			world.blit(pygame.image.load(player.colpi[i]), (200,475))
			pygame.display.flip()
			time.sleep(0.01)
		#time.sleep(0.01)
		x = 300
		y = 475
		ripetion = True
		while ripetion :
			for i in range(7):
				ristampa(world, player, 2, oca, 1)
				world.blit(pygame.image.load(player.colpi[4]), (200,475))
				world.blit(attack.ritornaMargherita()[i], (x,y))
				x = x + 20
				pygame.display.flip()
				time.sleep(0.01)
				print(x)
			if x > 720:
				ripetion = False
		time.sleep(0.8)
	elif (player.padella == "fiamma"):
		for i in range(5):
			ristampa(world, player, 2, oca, 1)
			world.blit(pygame.image.load(player.colpiFiamma[i]), (200,475))
			pygame.display.flip()
			time.sleep(0.01)
		#time.sleep(0.01)
		x = 300
		y = 475
		ripetion = True
		while ripetion :
			for i in range(7):
				ristampa(world, player, 2, oca, 1)
				world.blit(pygame.image.load(player.colpiFiamma[4]), (200,475))
				world.blit(attack.ritornaMargherita()[i], (x,y))
				x = x + 20
				pygame.display.flip()
				time.sleep(0.01)
				print(x)
			if x > 720:
				ripetion = False
		time.sleep(0.8)	
	elif (player.padella == "lunga"):
		for i in range(5):
			ristampa(world, player, 2, oca, 1)
			world.blit(pygame.image.load(player.colpiLunga[i]), (200,475))
			pygame.display.flip()
			time.sleep(0.01)
		#time.sleep(0.01)
		x = 300
		y = 475
		ripetion = True
		while ripetion :
			for i in range(7):
				ristampa(world, player, 2, oca, 1)
				world.blit(pygame.image.load(player.colpiLunga[4]), (200,475))
				world.blit(attack.ritornaMargherita()[i], (x,y))
				x = x + 20
				pygame.display.flip()
				time.sleep(0.01)
				print(x)
			if x > 720:
				ripetion = False
		time.sleep(0.8)	
		time.sleep(0.8)	
	elif (player.padella == "pala"):
		for i in range(5):
			ristampa(world, player, 2, oca, 1)
			world.blit(pygame.image.load(player.colpiPala[i]), (200,475))
			pygame.display.flip()
			time.sleep(0.01)
		#time.sleep(0.01)
		x = 300
		y = 475
		ripetion = True
		while ripetion :
			for i in range(7):
				ristampa(world, player, 2, oca, 1)
				world.blit(pygame.image.load(player.colpiPala[4]), (200,475))
				world.blit(attack.ritornaMargherita()[i], (x,y))
				x = x + 20
				pygame.display.flip()
				time.sleep(0.01)
				print(x)
			if x > 720:
				ripetion = False
		time.sleep(0.8)	
		
def colpoFinale(world, player, oca):
	x = 130
	y = 305
	
	
	for i in range(6):
		ristampaFinale(world, oca)
		world.blit(pygame.image.load(camminiamo.array_canalizza[i]), (200,655))
		pygame.display.flip()
		time.sleep(0.25)
	world.blit(attack.ritornaMargheritaGrossa()[0], (130,350))
	pygame.display.flip()
	time.sleep(2)

	ripetion = True
	while ripetion :
		for j in range(10):
			ristampaFinale(world, oca)
			world.blit(attack.ritornaMargheritaGrossa()[j], (x,y))
			world.blit(pygame.image.load(camminiamo.array_canalizza[5]), (200,655))
			x = x + 25
			pygame.display.flip()
			time.sleep(0.01)
			print(x)
		if x > 720:
			ripetion = False
			
	
def pizzaRotante(world, oca):
	x = 420
	y = 495
	ripetion = True
	while ripetion: 
		for i in range(10):
			ristampa(world, player, 2, oca, 1)
			world.blit(pygame.image.load(attack.arrayPizzettina[i]), (x,y))
			pygame.display.flip()
			time.sleep(0.01)
			x = x + 20
			if x > 1000:
				i = 99
		print(x)
		if x > 1000:
			ripetion = False
	time.sleep(0.8)
		
		
def ristampaFinale(world, oca):
	surf_background = pygame.image.load("Immagini_Gioco/ULTIMO_LIVELLO/scontroF.jpg").convert()
	world.blit(surf_background, (0, 0))
	
	world.blit(oca.getSurfOca(), (oca.getRectOca().x , oca.getRectOca().y))
		

def ristampa(world, player, flag, oca, noMovimento = 0):

	if oca.colore == "verde":
		surf_background = pygame.image.load("Immagini_Gioco/INVENTARIO/tavernaG.jpg").convert()
		world.blit(surf_background, (0, 0))
	elif oca.colore == "rossa":
		surf_background = pygame.image.load("Immagini_Gioco/ULTIMO_LIVELLO/sfondoRossa.png").convert()
		world.blit(surf_background, (0, 0))
	elif oca.colore == "viola":
		surf_background = pygame.image.load("Immagini_Gioco/ULTIMO_LIVELLO/sfondoForest.png").convert()
		world.blit(surf_background, (0, 0))
	elif oca.colore == "pizza":
		surf_background = pygame.image.load("Immagini_Gioco/ULTIMO_LIVELLO/scontroF.jpg").convert()
		world.blit(surf_background, (0, 0))	
		

	
	surf_azioni = pygame.image.load("Immagini_Gioco/HUB/dialogBatt.jpg")
	world.blit(surf_azioni , (50, 660))
	
	if(flag == 0):
		surf_fight = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/fightTrasp.png")
		rect_fight =pygame.Rect((100, 735), (200, 200))
		
		surf_item = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/itemTrasp.png")
		rect_item =pygame.Rect((950, 735), (200, 200))
		
		world.blit(surf_fight , (rect_fight.x, rect_fight.y))
		world.blit(surf_item , (rect_item.x, rect_item.y))
	
	
	surf_box = pygame.image.load("Immagini_Gioco/INVENTARIO/box.jpg")
	world.blit(surf_box , (0, 0))
	world.blit(surf_box , (855, 0)) 
	
	vita = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/PuntiPizzaSegnale.png")
	world.blit(vita , (25, 100))
	world.blit(player.ritornaPizzaEnergy() , (125, 150))
	
	world.blit(player.ritornaPizzaBar(), (125, 50))
	
	
	
	world.blit(font.render(str(player.HP), False, (255, 255, 255)) ,(250, 60))
	world.blit(font.render(str(player.energy), False, (0, 0, 0)) ,(250, 160))
	
	world.blit(oca.getSurfOca(), (oca.getRectOca().x , oca.getRectOca().y))
	
	if oca.colore != "pizza":
		if( player.padella == "base"):
			nuovaPoz = "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpi/conPadella/colpoPad.png"
		elif(player.padella == "fiamma"):
			#nuovaPoz = "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpi/conFiamma/colpoFiamma1.png"
			nuovaPoz =  "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpi/conFiamma/colpoFiamma1.png"
		elif(player.padella == "lunga"):
			nuovaPoz =  "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpi/conPalona/colpoPalona1.png"
		elif(player.padella == "pala"):
			nuovaPoz =  "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpi/conPala/colpoPalina1.png"	
	else:
		nuovaPoz =  "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDX/fermoDX.png"	
		#world.blit(pygame.image.load(nuovaPoz), (player.getRectPlayer().x , player.getRectPlayer().y))		
	
	if(flag != 2):
		world.blit(pygame.image.load(nuovaPoz), (200, 475))
	
	world.blit(oca.ritornaPizzaBar(), (935, 175))
	if oca.HP >= 0:
		world.blit(font.render(str(oca.HP), False, (255, 255, 255)) ,(1050, 190))
	else:
		world.blit(font.render("0", False, (255, 255, 255)) ,(1050, 190))
		
	if oca.colore == "rossa":
		world.blit(pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/robaOcaRossa/ocaRossaDanni.png") , (1005, 40))
	elif oca.colore == "viola":
		world.blit(pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/robaOcaViola/ocaViolaDanni.png") , (1005, 40))
	elif oca.colore == "verde":
		world.blit(pygame.image.load("Immagini_Gioco/INVENTARIO/ocaVerdeDanni.png") , (1005, 40))
	elif oca.colore == "pizza":
		world.blit(pygame.image.load("Immagini_Gioco/ULTIMO_LIVELLO/attaccoPizzaP.png") , (1045, 40))
		

def stampaPoterePizze(world, player):
	if(player.attaccoFinale == 1):
		i=0
		x = 270
		y = 495
		for i in range(7):
			world.blit(attack.ritornaMargherita()[i], (x,y))
			pygame.display.flip()
			time.sleep(0.01)		
			i= i+1	
	elif(player.attaccoFinale == 2):
		x = 270
		y = 495
		for i in range(7):
			world.blit(attack.ritornaMargherita()[i], (x,y))
			world.blit(attack.ritornaMargherita()[i], (270,550))
			pygame.display.flip()
			time.sleep(0.01)		
			i= i+1	
	elif(player.attaccoFinale == 3):
		x = 270
		y = 495
		for i in range(7):
			world.blit(attack.ritornaMargherita()[i], (x,y))
			world.blit(attack.ritornaMargherita()[i], (270,550))
			world.blit(attack.ritornaMargherita()[i], (150,550))
			pygame.display.flip()
			time.sleep(0.01)		
			i= i+1	
	elif(player.attaccoFinale == 4):
		x = 270
		y = 495
		for i in range(7):
			world.blit(attack.ritornaMargherita()[i], (x,y))
			world.blit(attack.ritornaMargherita()[i], (270,550))
			world.blit(attack.ritornaMargherita()[i], (150,550))
			world.blit(attack.ritornaMargherita()[i], (150,495))
			pygame.display.flip()
			time.sleep(0.01)		
			i= i+1
	elif(player.attaccoFinale == 5):
		x = 270
		y = 495
		for i in range(7):
			world.blit(attack.ritornaMargherita()[i], (x,y))
			world.blit(attack.ritornaMargherita()[i], (270,550))
			world.blit(attack.ritornaMargherita()[i], (150,550))
			world.blit(attack.ritornaMargherita()[i], (150,495))
			world.blit(attack.ritornaMargherita()[i], (180,605))
			pygame.display.flip()
			time.sleep(0.01)		
			i= i+1
	elif(player.attaccoFinale == 6):
		x = 270
		y = 495
		for i in range(7):
			world.blit(attack.ritornaMargherita()[i], (x,y))
			world.blit(attack.ritornaMargherita()[i], (270,550))
			world.blit(attack.ritornaMargherita()[i], (150,550))
			world.blit(attack.ritornaMargherita()[i], (150,495))
			world.blit(attack.ritornaMargherita()[i], (180,605))
			world.blit(attack.ritornaMargherita()[i], (235,605))
			pygame.display.flip()
			time.sleep(0.01)		
			i= i+1	
	elif(player.attaccoFinale == 7):
		x = 270
		y = 495
		for i in range(7):
			world.blit(attack.ritornaMargherita()[i], (x,y))
			world.blit(attack.ritornaMargherita()[i], (270,550))
			world.blit(attack.ritornaMargherita()[i], (150,550))
			world.blit(attack.ritornaMargherita()[i], (150,495))
			world.blit(attack.ritornaMargherita()[i], (180,605))
			world.blit(attack.ritornaMargherita()[i], (235,605))
			world.blit(attack.ritornaMargherita()[i], (235,430))
			pygame.display.flip()
			time.sleep(0.01)		
			i= i+1		
	elif(player.attaccoFinale == 8):
		x = 270
		y = 495
		for i in range(7):
			world.blit(attack.ritornaMargherita()[i], (x,y))
			world.blit(attack.ritornaMargherita()[i], (270,550))
			world.blit(attack.ritornaMargherita()[i], (150,550))
			world.blit(attack.ritornaMargherita()[i], (150,495))
			world.blit(attack.ritornaMargherita()[i], (180,605))
			world.blit(attack.ritornaMargherita()[i], (235,605))
			world.blit(attack.ritornaMargherita()[i], (245,430))
			world.blit(attack.ritornaMargherita()[i], (180,430))
			pygame.display.flip()
			time.sleep(0.01)		
			i= i+1			
		

def main(player, coloreOca):
	if(coloreOca == "verde"):
		oca = ocaNemica.Oca("Immagini_Gioco/INVENTARIO/ocaAntiPizza.png")
		oca.PP = 100
		oca.HP = oca.PP
		oca.colore = "verde"
	elif(coloreOca == "rossa"):
		oca = ocaNemica.Oca("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/robaOcaRossa/ocaRossaBattaglia.png")
		oca.PP = 500
		oca.HP = oca.PP
		oca.colore = "rossa"
	elif(coloreOca == "viola"):
		oca = ocaNemica.Oca("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/robaOcaViola/ocaViolaBatt.png")
		oca.PP = 1000
		oca.HP = oca.PP
		oca.colore = "viola"
	elif(coloreOca == "pizza"):
		oca = ocaNemica.Oca("Immagini_Gioco/ULTIMO_LIVELLO/pizzaAnanasG.png")
		oca.PP = 9999999
		oca.HP = oca.PP
		oca.colore = "pizza"	
		oca.rectOca.x = 610
		oca.rectOca.y = 190
	worldx = 1280
	worldy = 920
	fps = 40
	ani = 4
	world = pygame.display.set_mode((worldx, worldy))
	colonnaSonora(1, oca)
	
	if coloreOca == "verde":
		surf_background = pygame.image.load("Immagini_Gioco/INVENTARIO/tavernaG.jpg").convert()
		world.blit(surf_background, (0, 0))
	elif coloreOca == "rossa":
		surf_background = pygame.image.load("Immagini_Gioco/ULTIMO_LIVELLO/sfondoRossa.png").convert()
		world.blit(surf_background, (0, 0))
	elif coloreOca == "viola":
		surf_background = pygame.image.load("Immagini_Gioco/ULTIMO_LIVELLO/sfondoForest.png").convert()
		world.blit(surf_background, (0, 0))
	
	surf_azioni = pygame.image.load("Immagini_Gioco/HUB/dialogBatt.jpg")
	world.blit(surf_azioni , (50, 660))
	
	surf_fight = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/fightTrasp.png")
	rect_fight =pygame.Rect((100, 735), (200, 200))
	
	surf_item = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/itemTrasp.png")
	rect_item =pygame.Rect((950, 735), (200, 200))
	
	world.blit(surf_fight , (rect_fight.x, rect_fight.y))
	world.blit(surf_item , (rect_item.x, rect_item.y))
	
	
	surf_box = pygame.image.load("Immagini_Gioco/INVENTARIO/box.jpg")
	world.blit(surf_box , (0, 0))
	world.blit(surf_box , (855, 0)) 
	
	vita = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/PuntiPizzaSegnale.png")
	world.blit(vita , (25, 100))
	
	world.blit(player.ritornaPizzaBar(), (125, 50))
	world.blit(player.ritornaPizzaEnergy(), (125, 150))
	
	world.blit(oca.ritornaPizzaBar(), (985, 50))
	
	world.blit(font.render(str(player.HP), False, (255, 255, 255)) ,(250, 60))
	world.blit(font.render(str(player.energy), False, (255, 255, 255)) ,(250, 160))
	world.blit(oca.getSurfOca(), (oca.getRectOca().x , oca.getRectOca().y))
	if oca.colore != "pizza":
		if( player.padella == "base"):
			nuovaPoz = "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpi/conPadella/colpoPad.png"
			world.blit(pygame.image.load(nuovaPoz), (player.getRectPlayer().x , player.getRectPlayer().y))
		elif(player.padella == "fiamma"):
			nuovaPoz = "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpi/conFiamma/colpoFiamma1.png"
			world.blit(pygame.image.load(nuovaPoz), (player.getRectPlayer().x , player.getRectPlayer().y))
		elif(player.padella == "lunga"):
			nuovaPoz =  "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpi/conPalona/colpoPalona1.png"	
			world.blit(pygame.image.load(nuovaPoz), (player.getRectPlayer().x , player.getRectPlayer().y))
		elif(player.padella == "pala"):
			nuovaPoz =  "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpi/conPala/colpoPalina1.png"	
			world.blit(pygame.image.load(nuovaPoz), (player.getRectPlayer().x , player.getRectPlayer().y))
	else:
		nuovaPoz =  "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDX/fermoDX.png"	
		world.blit(pygame.image.load(nuovaPoz), (player.getRectPlayer().x , player.getRectPlayer().y))		
		
	world.blit(oca.ritornaPizzaBar(), (935, 175))
	if oca.HP >= 0:
		world.blit(font.render(str(oca.HP), False, (255, 255, 255)) ,(1050, 190))
	else:
		world.blit(font.render("0", False, (255, 255, 255)) ,(1050, 190))
		
	if oca.colore == "rossa":
		world.blit(pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/robaOcaRossa/ocaRossaDanni.png") , (1005, 40))
	elif oca.colore == "viola":
		world.blit(pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/robaOcaViola/ocaViolaDanni.png") , (1005, 40))
	elif oca.colore == "pizza":
		world.blit(pygame.image.load("Immagini_Gioco/ULTIMO_LIVELLO/attaccoPizzaP.png") , (1005, 40))
	
	pygame.display.flip()
	
	turno = 0
	rit = 0
	val = 0
	
	risultato = 0
	
	ripeti = True
	
	while ripeti:
		if(player.HP <= 0):
			ripeti = False
			risultato = 0
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				sys.exit()
				
			if event.type == pygame.MOUSEBUTTONDOWN:
				click = event.pos
				
				if rect_fight.collidepoint(pygame.mouse.get_pos()) and event.button == 1:	
					#combatti(world, player)
					ristampa(world, player, 1, oca)
					if oca.colore != "pizza":
						val = attack.ritornaListaAttacchi(world, player , oca)
					else:
						val = attack.ritornaListaAttacchi(world, player , oca, "final")
						if val != 99:
							if(player.attaccoFinale != 8):
								player.attaccoFinale += 1
						print(val)
					ristampa(world, player, 0, oca)
					print(oca.HP)
					turno = 1
		if (turno == 1 and val != 0):
			if(oca.HP <= 0 and val != 99):
				colpoPizza(world, player, oca)
				print (oca.HP)
				print("HAI VINTO")
				risultato = 1
				ripeti = False
			else:
				print(val)
			#	time.sleep(5)
				if val == 5 or val == 555:
					print ("gg")
					cana(world, camminiamo, player, oca)
				if val == 2:
					colpoPizza(world, player, oca)
				#ristampa(world, player, 0)
				print("ou")
				if val != 555:
					o = random.randint(2, 5)
					v = random.randint(2, 10)
					print(o, v)
					if oca.colore == "pizza":
						battagliaUndertaleStile.main(random.randint(5, 10), random.randint(5, 10), player, random.randint(0, 4), random.randint(6, 10), coloreOca, random.randint(5, 10))
					else:
						battagliaUndertaleStile.main(random.randint(5, 10), random.randint(5, 10), player, random.randint(0, 1), random.randint(6, 10), coloreOca, random.randint(5, 10))
					player.settaPoz(world, 200, 475)
					ristampa(world, player, 0, oca)
				#	pygame.display.flip()
					turno = 0
				elif val == 555:
					colpoFinale(world, player, oca)
					ripeti = False
					print("aioooo")
					time.sleep(3)
					risultato = 9999
					
		if (val == 0):
			ristampa(world, player, 0, oca)
	#	if(oca.HP <= 0):
	#		print("HAI VINTO")
	#		ripeti = False
		if(	ripeti != False):	
			stampaPoterePizze(world, player)
			pygame.display.flip()
	
	return risultato
			
		
		



