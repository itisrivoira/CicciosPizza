import pygame
import Player
import ocaNemica
import faiPizza
import random


class Attacco():
	
	def __init__(self):
	
		self.attacchi = [pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/canalizzaPizza.png"),   pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/attaccoMargherita.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/attaccoProsciutto.png")]
		self.attacchiFiamma = [pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/button_pizza-salame.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/button_pizza-salsiccia.png")]
		self.attacchiLunga = [pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/button_americana.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/button_boscaiola.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/button_olive.png")]
		self.attacchiPala = [pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/button_funghi.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/button_prosciuttoOlive.png") , pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/button_quattro.png")]
		self.attacchiSans = []
		self.attaccoFinale = [pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/button_attaccoFinale.png"), pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/button_ciccios.png")]
		self.arrayPathPizza = ["Immagini_Gioco/Immagini_Livello/pizzaMargherita.png", 'Immagini_Gioco/pizze/pizzaProsciutto.png', 'Immagini_Gioco/pizze/pizzaSalame.png', 'Immagini_Gioco/pizze/pizzaSalsiccia.png', 'Immagini_Gioco/pizze/pizzaAmericana.png', 'Immagini_Gioco/pizze/pizzaSalsiccia_Funghi.png',  'Immagini_Gioco/pizze/pizzaOlive.png', 'Immagini_Gioco/pizze/pizzaQuattroStagioni.png', 'Immagini_Gioco/pizze/pizzaProsciutto_Olive.png', 'Immagini_Gioco/pizze/pizzaFunghi.png']
		self.rectAttacchi = []
		self.arrayPizzettina = []
		self.rectSettati = 0
		
		
	def ritornaListaAttacchi(self, world, player, oca, finale = ""):
		
		if(finale != "final"):
			world.blit(self.attacchi[0], (510, 750))
			if(player.padella == "base"):
			
				if(self.rectSettati == 0):
					self.rectAttacchi = [self.attacchi[0].get_rect(), self.attacchi[1].get_rect(), self.attacchi[2].get_rect()]
					
					self.rectAttacchi[0].move_ip((510, 750))
					self.rectAttacchi[1].move_ip((140, 700))
					self.rectAttacchi[2].move_ip((140, 800))
					self.rectSettati = 1
				
				
				world.blit(self.attacchi[1], (self.rectAttacchi[1].x,  self.rectAttacchi[1].y))
				world.blit(self.attacchi[2], (140, 800))
				surf_indietro = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/indietro.png")
				rect_indietro= surf_indietro.get_rect()
				rect_indietro.move_ip((1040, 830))
				world.blit(surf_indietro, (1040, 830))
				
				pygame.display.flip()

				ritorna = 0
				ripeti = True
				
				while ripeti:
					for event in pygame.event.get():
						if event.type == pygame.QUIT:
							pygame.quit()
							sys.exit()		
					
						if event.type == pygame.MOUSEBUTTONDOWN:
							click = event.pos
							
							if self.rectAttacchi[1].collidepoint(pygame.mouse.get_pos()) and event.button == 1 and player.energy >= 5:	
								makePizza = faiPizza.Pizza("Immagini_Gioco/Immagini_Livello/pizzaMargherita.png")
								riuscito = makePizza.makeAttaccoPizza(world)
								if riuscito != 99:
									#print("a")
									flag = player.dimEnergy(5)
									if flag :
										oca.colpita(10)
										flag = False
										ritorna = 2
									else:
										print("RICARICA ENERGIA !!!")
										ritorna = 0
									ripeti = False
								else:
									flag = player.dimEnergy(5)
									ritorna = 99
									ripeti = False
							if self.rectAttacchi[2].collidepoint(pygame.mouse.get_pos()) and event.button == 1 and player.energy >= 10:	
								makePizza = faiPizza.Pizza('Immagini_Gioco/pizze/pizzaProsciutto.png')
								riuscito = makePizza.makeAttaccoPizza(world)
								#print("a")
								flag = player.dimEnergy(10)
								if riuscito != 99:
									if flag :
										oca.colpita(20)
										flag = False
										ritorna = 2
									else:
										print("RICARICA ENERGIA !!!")
										ritorna = 0
									ripeti = False
								else:
									ritorna = 99
									ripeti = False
							if self.rectAttacchi[0].collidepoint(pygame.mouse.get_pos()) and event.button == 1:	
								flag = player.recuperaEnergy(15)
								if flag:
									ritorna = 5
								else:
									print("HAI GIA ENERGIA !!!")
									ritorna = 0
								ripeti = False
								
							if rect_indietro.collidepoint(pygame.mouse.get_pos()) and event.button == 1:	
								ripeti = False
				print(ritorna)
				return ritorna 
			if(player.padella == "fiamma"):	
				self.rectAttacchi = [self.attacchi[0].get_rect(), self.attacchiFiamma[0].get_rect(), self.attacchiFiamma[1].get_rect()]
				
				self.rectAttacchi[0].move_ip((510, 750))
				self.rectAttacchi[1].move_ip((140, 700))
				self.rectAttacchi[2].move_ip((140, 800))
				
				
				world.blit(self.attacchiFiamma[0], (self.rectAttacchi[1].x,  self.rectAttacchi[1].y))
				world.blit(self.attacchiFiamma[1], (140, 800))
				surf_indietro = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/indietro.png")
				rect_indietro= surf_indietro.get_rect()
				rect_indietro.move_ip((1040, 830))
				world.blit(surf_indietro, (1040, 830))
				
				pygame.display.flip()

				ritorna = 0
				ripeti = True
				
				while ripeti:
					for event in pygame.event.get():
						if event.type == pygame.QUIT:
							pygame.quit()
							sys.exit()		
					
						if event.type == pygame.MOUSEBUTTONDOWN:
							click = event.pos
							
							if self.rectAttacchi[1].collidepoint(pygame.mouse.get_pos()) and event.button == 1 and player.energy >= 20:	
								makePizza = faiPizza.Pizza('Immagini_Gioco/pizze/pizzaSalame.png')
								riuscito = makePizza.makeAttaccoPizza(world)
								#print("a")
								flag = player.dimEnergy(20)
								if riuscito != 99:
									if flag :
										oca.colpita(50)
										flag = False
										ritorna = 2
									else:
										print("RICARICA ENERGIA !!!")
										ritorna = 0
									ripeti = False
								else:
									ritorna = 99
									ripeti = False
							if self.rectAttacchi[2].collidepoint(pygame.mouse.get_pos()) and event.button == 1 and player.energy >= 10:	
								makePizza = faiPizza.Pizza('Immagini_Gioco/pizze/pizzaSalsiccia.png')
								riuscito = makePizza.makeAttaccoPizza(world)
								#print("a")
								flag = player.dimEnergy(10)
								if riuscito != 99:
									if flag :
										player.flagNoDanno = True
										flag = False
										ritorna = 5
									else:
										print("RICARICA ENERGIA !!!")
										ritorna = 0
									ripeti = False
								else:
									ritorna = 99
									ripeti = False
							if self.rectAttacchi[0].collidepoint(pygame.mouse.get_pos()) and event.button == 1:	
								flag = player.recuperaEnergy(15)
								if flag:
									ritorna = 5
								else:
									print("HAI GIA ENERGIA !!!")
									ritorna = 0
								ripeti = False
								
							if rect_indietro.collidepoint(pygame.mouse.get_pos()) and event.button == 1:	
								ripeti = False
				return ritorna 	
			if(player.padella == "lunga"):	
				self.rectAttacchi = [self.attacchi[0].get_rect(), self.attacchiLunga[0].get_rect(), self.attacchiLunga[1].get_rect(), self.attacchiLunga[2].get_rect()]
				
				self.rectAttacchi[0].move_ip((510, 750))
				self.rectAttacchi[1].move_ip((140, 700))
				self.rectAttacchi[2].move_ip((140, 800))
				self.rectAttacchi[3].move_ip((900, 700))
				
				world.blit(self.attacchiLunga[0], (self.rectAttacchi[1].x,  self.rectAttacchi[1].y))
				world.blit(self.attacchiLunga[1], (140, 800))
				world.blit(self.attacchiLunga[2], (900, 700))
				surf_indietro = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/indietro.png")
				rect_indietro= surf_indietro.get_rect()
				rect_indietro.move_ip((1040, 830))
				world.blit(surf_indietro, (1040, 830))
				
				pygame.display.flip()

				ritorna = 0
				ripeti = True
				
				while ripeti:
					for event in pygame.event.get():
						if event.type == pygame.QUIT:
							pygame.quit()
							sys.exit()		
					
						if event.type == pygame.MOUSEBUTTONDOWN:
							click = event.pos
							
							if self.rectAttacchi[1].collidepoint(pygame.mouse.get_pos()) and event.button == 1 and player.energy >= 25:	
								makePizza = faiPizza.Pizza('Immagini_Gioco/pizze/pizzaAmericana.png')
								riuscito = 	makePizza.makeAttaccoPizza(world)
								print("a")
								flag = player.dimEnergy(25)
								if riuscito != 99:
									if flag :
										if(player.raddoppiaDanno == True):
											oca.colpita(100 * 2)
											flag = False
											player.raddoppiaDanno = False
											ritorna = 2
										else:
											oca.colpita(100)
											flag = False
											ritorna = 2
									else:
										print("RICARICA ENERGIA !!!")
										ritorna = 0
									ripeti = False
								else:
									ritorna = 99
									return ritorna
							if self.rectAttacchi[2].collidepoint(pygame.mouse.get_pos()) and event.button == 1 and player.energy >= 15:	
								makePizza = faiPizza.Pizza('Immagini_Gioco/pizze/pizzaSalsiccia_Funghi.png')
								riuscito = makePizza.makeAttaccoPizza(world)
								#print("a")
								flag = player.dimEnergy(15)
								if riuscito != 99:
									if flag :
										if(player.raddoppiaDanno == True):
											player.flagNoDanno = True
											player.recuperaHP(25 * 1.3)
											flag = False
											player.raddioppiaDanno = False
											ritorna = 5
										else:
											player.flagNoDanno = True
											player.recuperaHP(25 )
											flag = False
											ritorna = 5										
									else:
										print("RICARICA ENERGIA !!!")
										ritorna = 0
										
									ripeti = False
								else:
									ritorna = 99
									return ritorna
									
							if self.rectAttacchi[3].collidepoint(pygame.mouse.get_pos()) and event.button == 1 and player.energy >= 12:	
								makePizza = faiPizza.Pizza('Immagini_Gioco/pizze/pizzaOlive.png')
								riuscito = makePizza.makeAttaccoPizza(world)
								#print("a")
								flag = player.dimEnergy(12)
								if riuscito != 99:
									if flag :
										player.raddoppiaDanno = True
										flag = False
										ritorna = 5
									else:
										print("RICARICA ENERGIA !!!")
										ritorna = 0
										
									ripeti = False
								else:
									ritorna = 99
									return ritorna
															
							if self.rectAttacchi[0].collidepoint(pygame.mouse.get_pos()) and event.button == 1:	
								flag = player.recuperaEnergy(15)
								if flag:
									ritorna = 5
								else:
									print("HAI GIA ENERGIA !!!")
									ritorna = 0
								ripeti = False
								
							if rect_indietro.collidepoint(pygame.mouse.get_pos()) and event.button == 1:	
								ripeti = False
				return ritorna
				
			if(player.padella == "pala"):	
				self.rectAttacchi = [self.attacchi[0].get_rect(), self.attacchiPala[0].get_rect(), self.attacchiPala[1].get_rect(), self.attacchiPala[2].get_rect()]
				
				self.rectAttacchi[0].move_ip((510, 750))
				self.rectAttacchi[1].move_ip((140, 700))
				self.rectAttacchi[2].move_ip((140, 800))
				self.rectAttacchi[3].move_ip((880, 700))
				
				
				world.blit(self.attacchiPala[0], (self.rectAttacchi[1].x,  self.rectAttacchi[1].y))
				world.blit(self.attacchiPala[1], (140, 800))
				world.blit(self.attacchiPala[2], (880, 700))
				surf_indietro = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/indietro.png")
				rect_indietro= surf_indietro.get_rect()
				rect_indietro.move_ip((1040, 830))
				world.blit(surf_indietro, (1040, 830))
				
				pygame.display.flip()

				ritorna = 0
				ripeti = True
				
				while ripeti:
					for event in pygame.event.get():
						if event.type == pygame.QUIT:
							pygame.quit()
							sys.exit()		
					
						if event.type == pygame.MOUSEBUTTONDOWN:
							click = event.pos
							
							if self.rectAttacchi[1].collidepoint(pygame.mouse.get_pos()) and event.button == 1 and player.energy >= 20:	
								makePizza = faiPizza.Pizza('Immagini_Gioco/pizze/pizzaFunghi.png')
								riuscito = makePizza.makeAttaccoPizza(world)
								print("riuscito")
								#print("a")
								flag = player.dimEnergy(20)
								if riuscito != 99:
									if flag :
										player.recuperaHP(40)
										flag = False
										ritorna = 5
									else:
										print("RICARICA ENERGIA !!!")
										ritorna = 0
									ripeti = False
								else:
									ritorna = 99
									ripeti = False
							if self.rectAttacchi[2].collidepoint(pygame.mouse.get_pos()) and event.button == 1 and player.energy >= 30:	
								makePizza = faiPizza.Pizza('Immagini_Gioco/pizze/pizzaProsciutto_Olive.png')
								riuscito = makePizza.makeAttaccoPizza(world)
								#print("a")
								flag = player.dimEnergy(30)
								if riuscito != 99:
									if flag :
										player.raddoppiaDanno = True
										oca.colpita(100)
										flag = False
										ritorna = 2
									else:
										print("RICARICA ENERGIA !!!")
										ritorna = 0
									ripeti = False
								else:
									ritorna = 99
									ripeti = False
									
							if self.rectAttacchi[3].collidepoint(pygame.mouse.get_pos()) and event.button == 1 and player.energy >= 50:	
								makePizza = faiPizza.Pizza( 'Immagini_Gioco/pizze/pizzaQuattroStagioni.png')
								riuscito = makePizza.makeAttaccoPizza(world)
								#print("a")
								flag = player.dimEnergy(50)
								if riuscito != 99:
									if flag :
										if player.raddoppiaDanno == True:
											oca.colpita(250 * 2)
											flag = False
											player.raddoppiDanno = False
											ritorna = 2
										else:
											oca.colpita(250)
											flag = False
											ritorna = 2
									else:
										print("RICARICA ENERGIA !!!")
										ritorna = 0
									ripeti = False
								else:
									ritorna = 99
									ripeti = False
									
							if self.rectAttacchi[0].collidepoint(pygame.mouse.get_pos()) and event.button == 1:	
								flag = player.recuperaEnergy(15)
								if flag:
									ritorna = 5
								else:
									print("HAI GIA ENERGIA !!!")
									ritorna = 0
								ripeti = False
								
							if rect_indietro.collidepoint(pygame.mouse.get_pos()) and event.button == 1:	
								ripeti = False
				return ritorna  
		else:
			if player.attaccoFinale != 8:
				self.rectAttacchi = [self.attaccoFinale[0].get_rect()]
				self.rectAttacchi[0].move_ip((360, 725))
				world.blit(self.attaccoFinale[0], (self.rectAttacchi[0].x,  self.rectAttacchi[0].y))
				pygame.display.flip()

				ritorna = 0
				ripeti = True
					
				while ripeti:
					for event in pygame.event.get():
						if event.type == pygame.QUIT:
							pygame.quit()
							sys.exit()		
						
						if event.type == pygame.MOUSEBUTTONDOWN:
							click = event.pos
								
							if self.rectAttacchi[0].collidepoint(pygame.mouse.get_pos()) and event.button == 1 and player.energy >= 1:	
								ran = random.randint(0, len(self.arrayPathPizza) - 1)
								for i in range(len(self.arrayPathPizza)):
									makePizza = faiPizza.Pizza( self.arrayPathPizza[ran])
									riuscito = makePizza.makeAttaccoPizza(world)
									if(riuscito != 99):
										ran = random.randint(0, len(self.arrayPathPizza) -1 )
									else:
										ripeti = False
										return 99
								return 5
			else:
				self.rectAttacchi = [self.attaccoFinale[1].get_rect()]
				self.rectAttacchi[0].move_ip((360, 725))
				world.blit(self.attaccoFinale[1], (self.rectAttacchi[0].x,  self.rectAttacchi[0].y))
				pygame.display.flip()

				ritorna = 0
				ripeti = True
					
				while ripeti:
					for event in pygame.event.get():
						if event.type == pygame.QUIT:
							pygame.quit()
							sys.exit()		
						
						if event.type == pygame.MOUSEBUTTONDOWN:
							click = event.pos
								
							if self.rectAttacchi[0].collidepoint(pygame.mouse.get_pos()) and event.button == 1 and player.energy >= 1:	
								return 555			
								
								
	def ritornaMargherita(self):
		self.arrayPizzettina = [pygame.image.load("Immagini_Gioco/pizze/pizzeDaLancio/margherita/pizzettina.png"), pygame.image.load("Immagini_Gioco/pizze/pizzeDaLancio/margherita/pizzettina2.png"), pygame.image.load("Immagini_Gioco/pizze/pizzeDaLancio/margherita/pizzettina4.png"), pygame.image.load("Immagini_Gioco/pizze/pizzeDaLancio/margherita/pizzettina5.png"), pygame.image.load("Immagini_Gioco/pizze/pizzeDaLancio/margherita/pizzettina6.png"), pygame.image.load("Immagini_Gioco/pizze/pizzeDaLancio/margherita/pizzettina8.png"), pygame.image.load("Immagini_Gioco/pizze/pizzeDaLancio/margherita/pizzettina9.png"), pygame.image.load("Immagini_Gioco/pizze/pizzeDaLancio/margherita/pizzettina10.png")]
		return self.arrayPizzettina
		
	def ritornaMargheritaGrossa(self):
		self.arrayPizzettina = [pygame.image.load("Immagini_Gioco/pizze/pizzeDaLancio/attaccoFinale/pizzaMargheritaRuota1.png"), pygame.image.load("Immagini_Gioco/pizze/pizzeDaLancio/attaccoFinale/pizzaMargheritaRuota2.png"), pygame.image.load("Immagini_Gioco/pizze/pizzeDaLancio/attaccoFinale/pizzaMargheritaRuota3.png"), pygame.image.load("Immagini_Gioco/pizze/pizzeDaLancio/attaccoFinale/pizzaMargheritaRuota4.png"), pygame.image.load("Immagini_Gioco/pizze/pizzeDaLancio/attaccoFinale/pizzaMargheritaRuota5.png"), pygame.image.load("Immagini_Gioco/pizze/pizzeDaLancio/attaccoFinale/pizzaMargheritaRuota6.png"), pygame.image.load("Immagini_Gioco/pizze/pizzeDaLancio/attaccoFinale/pizzaMargheritaRuota7.png"), pygame.image.load("Immagini_Gioco/pizze/pizzeDaLancio/attaccoFinale/pizzaMargheritaRuota8.png"), pygame.image.load("Immagini_Gioco/pizze/pizzeDaLancio/attaccoFinale/pizzaMargheritaRuota9.png"), pygame.image.load("Immagini_Gioco/pizze/pizzeDaLancio/attaccoFinale/pizzaMargheritaRuota10.png"), pygame.image.load("Immagini_Gioco/pizze/pizzeDaLancio/attaccoFinale/pizzaMargheritaRuota11.png")]
		return self.arrayPizzettina
