import pygame, sys
import pygame_menu #libreria di pygame che permette una facile creazione del main menu di gioco
from pygame_menu import sound
import livello_prova
import livello_tutorial
import ordine1
import ordine_lvl3
import livello4HUB
import Player
import livello3_conSans
import livello5HUB
from pygame.locals import *


pygame.init()
	


def start_the_game1(screen, colonna, player, dialogo):

    flag = livello_prova.main(colonna)
    if ( flag == 1):
        pygame.quit()
        sys.exit() #SENZA QUESTO DA ERRORE PERCHE' RIPROVEREBBE A DISEGNARE SULLO SCHERMO CAUSANDO UN ERRORE
    print(flag)
    print(flag)
    print(flag)
    print(flag)
    if(flag == 99 and player.livello1 == False):
    	#dialogo.stampaDialoghi(screen, 1)
    	player.aumentaExp(151)
    	player.livello1 = True
    	#print(player.havePadFuoco)
    	#player.havePadFuoco = True
    	#print(player.havePadFuoco)
    return flag
    
def start_the_game2(colonna, player):
    flag = ordine1.main(colonna)
    if ( flag == 1):
        pygame.quit()
        sys.exit() #SENZA QUESTO DA ERRORE PERCHE' RIPROVEREBBE A DISEGNARE SULLO SCHERMO CAUSANDO UN ERRORE
    if(flag == 99 and player.livello2 == False):
    	dialogo.stampaDialoghi(screen, 1)
    	player.aumentaExp(205)
    	player.livello2 = True
    return flag
    
def start_the_game3(screen, colonna, player, dialogo):

	livello3_conSans.main()
	flag = ordine_lvl3.main(colonna)
	if ( flag == 1):
		pygame.quit()
		sys.exit() #SENZA QUESTO DA ERRORE PERCHE' RIPROVEREBBE A DISEGNARE SULLO SCHERMO CAUSANDO UN ERRORE
	print(flag)
	if(flag == 99 and player.livello3 == False):
		dialogo.stampaDialoghi(screen, 1)
		player.aumentaExp(405)
		player.livello3 = True
		player.havePadFuoco = True
		print(player.exp)
			#dialogo.stampaDialoghi(screen, 1)
	return flag   
    
def start_the_game4(colonna, player, inventario):
    livello4HUB.main(colonna, player, inventario)  
    print("ue")
    return 0
    
def start_the_game5(colonna, player, inventario):
    livello5HUB.main(colonna, player, inventario) 
        
def crea_mappa():


	screen = pygame.display.set_mode((1280, 920)) #CREAZIONE SCHERMO DI GIOCO
	pygame.display.set_caption("MAPPA DEI LIVELLI ")

		
	surf_background = pygame.image.load("Immagini_Gioco/ImmaginiMappa/sfondoCICCIOS2.jpg").convert()
	screen.blit(surf_background, (0, 0))

	#font_scegli=pygame.font.SysFont("Verdana",34,bold=True,italic=True)   
	#surf_scegli=font_scegli.render("SCEGLI IL LIVELLO!!",True,(0,0,255))	
	#x=450
	#y=30
	#screen.blit(surf_scegli,(x,y))	
	pygame.display.flip()
	surf_icon1= pygame.image.load("Immagini_Gioco/ImmaginiMappa/livello1.png")
	rect_icon1 = surf_icon1.get_rect()
	x=50
	y=175  
	rect_icon1.move_ip(x, y)
	screen.blit(surf_icon1, (x,y))

	surf_icon2= pygame.image.load("Immagini_Gioco/ImmaginiMappa/livello2.png")
	rect_icon2 = surf_icon1.get_rect()
	x=250
	y=500  
	rect_icon2.move_ip(x, y)
	screen.blit(surf_icon2, (x,y))

	surf_icon3= pygame.image.load("Immagini_Gioco/ImmaginiMappa/livello3.png")
	rect_icon3 = surf_icon1.get_rect()
	x=525
	y=175  
	rect_icon3.move_ip(x, y)
	screen.blit(surf_icon3, (x,y))

	surf_icon4= pygame.image.load("Immagini_Gioco/ImmaginiMappa/livello4.png")
	rect_icon4 = surf_icon1.get_rect()
	x=800
	y=500  
	rect_icon4.move_ip(x, y)
	screen.blit(surf_icon4, (x,y))

	surf_icon5= pygame.image.load("Immagini_Gioco/ImmaginiMappa/livello5.png")
	rect_icon5 = surf_icon1.get_rect()
	x=1050
	y=175  
	rect_icon5.move_ip(x, y)
	screen.blit(surf_icon5, (x,y))
		
	surf_menu= pygame.image.load("Immagini_Gioco/Immagini_Livello/menu.png")
	rect_menu = surf_menu.get_rect()
	x=1050  
	y=700  
	rect_menu.move_ip(x, y)
	screen.blit(surf_menu, (x,y))
		
	surf_tutorial= pygame.image.load("Immagini_Gioco/ImmaginiMappa/tutorial2.png")
	rect_tutorial = surf_tutorial.get_rect()
	x=10
	y=745 
	rect_tutorial.move_ip(x, y)
	screen.blit(surf_tutorial, (x,y))

		

	pygame.display.flip()	


   
def main(colonna, player, inventario, dialogo):

    


    screen = pygame.display.set_mode((1280, 920)) #CREAZIONE SCHERMO DI GIOCO
    pygame.display.set_caption("MAPPA DEI LIVELLI ")

    
    surf_background = pygame.image.load("Immagini_Gioco/ImmaginiMappa/sfondoCICCIOS4.jpg").convert()
    screen.blit(surf_background, (0, 0))

   # font_scegli=pygame.font.SysFont("Verdana",34,bold=True,italic=True)   
   # surf_scegli=font_scegli.render("SCEGLI IL LIVELLO!!",True,(0,0,255))	
    #x=450
    #y=30
    #screen.blit(surf_scegli,(x,y))	
    pygame.display.flip()

    surf_icon1= pygame.image.load("Immagini_Gioco/ImmaginiMappa/livello1.png")
    rect_icon1 = surf_icon1.get_rect()
    x=50
    y=175  
    rect_icon1.move_ip(x, y)
    screen.blit(surf_icon1, (x,y))

    surf_icon2= pygame.image.load("Immagini_Gioco/ImmaginiMappa/livello2.png")
    rect_icon2 = surf_icon1.get_rect()
    x=250
    y=500  
    rect_icon2.move_ip(x, y)
    screen.blit(surf_icon2, (x,y))

    surf_icon3= pygame.image.load("Immagini_Gioco/ImmaginiMappa/livello3.png")
    rect_icon3 = surf_icon1.get_rect()
    x=525
    y=175  
    rect_icon3.move_ip(x, y)
    screen.blit(surf_icon3, (x,y))

    surf_icon4= pygame.image.load("Immagini_Gioco/ImmaginiMappa/livello4.png")
    rect_icon4 = surf_icon1.get_rect()
    x=800
    y=500  
    rect_icon4.move_ip(x, y)
    screen.blit(surf_icon4, (x,y))

    surf_icon5= pygame.image.load("Immagini_Gioco/ImmaginiMappa/livello5.png")
    rect_icon5 = surf_icon1.get_rect()
    x=1050
    y=175  
    rect_icon5.move_ip(x, y)
    screen.blit(surf_icon5, (x,y))
    
    surf_menu= pygame.image.load("Immagini_Gioco/Immagini_Livello/menu.png")
    rect_menu = surf_menu.get_rect()
    x=1050  
    y=700  
    rect_menu.move_ip(x, y)
    screen.blit(surf_menu, (x,y))
    
    surf_tutorial= pygame.image.load("Immagini_Gioco/ImmaginiMappa/tutorial2.png")
    rect_tutorial = surf_tutorial.get_rect()
    x=10
    y=745 
    rect_tutorial.move_ip(x, y)
    screen.blit(surf_tutorial, (x,y))

    

    pygame.display.flip()

    flag=1
    DONE=False
    while not DONE:

	
        events = pygame.event.get() #lista eventi di una finestra
        for event in events:
            if event.type == pygame.QUIT:
            	pygame.quit()
            	sys.exit()
            
            elif event.type == MOUSEBUTTONDOWN:
                click = event.pos

                if rect_icon1.collidepoint(click) and event.button==1:
                    flag=start_the_game1(screen, colonna, player, dialogo)

                if rect_icon2.collidepoint(click) and event.button==1:
                     flag=start_the_game2(colonna, player)

                if rect_icon3.collidepoint(click) and event.button==1:
                    flag = start_the_game3(screen, colonna, player, dialogo)

                if rect_icon4.collidepoint(click) and event.button==1:
                   flag = start_the_game4(colonna, player, inventario)

                if rect_icon5.collidepoint(click) and event.button==1:
                   flag = start_the_game5(colonna, player, inventario)
                    
                if rect_menu.collidepoint(click) and event.button==1:
                    flag=0
                    
                if rect_tutorial.collidepoint(click) and event.button == 1: 
                	#xxx =pygame.image.load("Immagini_Gioco/dialoghi/dialogo1.jpg").convert()
                	#screen.blit(xxx, (0, 0))
                	#pygame.display.flip()
                	flag = livello_tutorial.main(FLAGPAUSE,VOLUMESETTATO)
                	print(flag)
                	#pygame.display.flip()

        if flag==0:
            DONE=True
        elif flag == -1:
        	crea_mappa()
        	flag = 1

    return flag
