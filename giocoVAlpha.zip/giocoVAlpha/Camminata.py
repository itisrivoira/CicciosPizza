import pygame
import time
class Camminata():


	def __init__(self):
		self.right = False
		self.left = False
		self.up = False
		self.down = False
		self.LAST = 0
		self.LAST2 = 4
		self.walkCount = 0
		self.array_path_dx = [ "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDX/DX1.png", "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDX/DX2.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDX/DX3.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDX/DX4.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDX/DX5.png" ,"Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDX/DX6.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDX/DX7.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDX/DX8.png"]
		self.array_path_sx = [ "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDX/SX1.png", "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDX/SX2.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDX/SX3.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDX/SX4.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDX/SX5.png" ,"Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDX/SX6.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDX/SX7.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDX/SX8.png"]
		self.array_path_up = [ "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEUP/UP1.png", "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEUP/UP2.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEUP/UP3.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEUP/UP4.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEUP/UP5.png" ,"Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEUP/UP6.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEUP/UP7.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEUP/UP8.png"]
		self.array_path_down = [ "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDOWN/DOWN1.png", "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDOWN/DOWN2.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDOWN/DOWN3.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDOWN/DOWN4.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDOWN/DOWN5.png" ,"Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDOWN/DOWN6.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDOWN/DOWN7.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDOWN/DOWN8.png"]
		
		self.array_path_dxColpito = [ "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTEDX/DX1.png", "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTEDX/DX2.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTEDX/DX3.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTEDX/DX4.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTEDX/DX5.png" ,"Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTEDX/DX6.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTEDX/DX7.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTEDX/DX8.png"]
		
		self.array_path_sxColpito =[ "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTESX/SX1.png", "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTESX/SX2.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTESX/SX3.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTESX/SX4.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTESX/SX5.png" ,"Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTESX/SX6.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTESX/SX7.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTESX/SX8.png"]
		
		self.array_path_upColpito = [ "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTEUP/UP1.png", "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTEUP/UP2.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTEUP/UP3.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTEUP/UP4.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTEUP/UP5.png" ,"Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTEUP/UP6.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTEUP/UP7.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTEUP/UP8.png"]
		
		self.array_path_downColpito = [ "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTEDOWN/DOWN1.png", "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTEDOWN/DOWN2.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTEDOWN/DOWN3.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTEDOWN/DOWN4.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTEDOWN/DOWN5.png" ,"Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTEDOWN/DOWN6.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTEDOWN/DOWN7.png" , "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/colpito/GIUSTEROSSE/GIUSTEDOWN/DOWN8.png"]
		
		self.pathStandDx = "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDX/fermoDX.png"
		self.pathStandSx = "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDX/fermoSX.png"
		self.pathStandUp = "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEUP/UPFERMO.png"
		self.pathStandDown = "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDOWN/DOWNFERMO.png"
		self.lastPath = ""
		self.lastPos = 0
		self.array_canalizza = ["Immagini_Gioco/HUB/CHEF/pg_ridimensionare/GIUSTEDOWN/DOWN1.png", "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/canalizza/giuste/cana1.png", "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/canalizza/giuste/cana2.png", "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/canalizza/giuste/cana3.png", "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/canalizza/giuste/cana4.png", "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/canalizza/giuste/cana5.png"] # "Immagini_Gioco/HUB/CHEF/pg_ridimensionare/canalizza/giuste/cana6.png"]
		self.contatore = 0
		self.canLast = 0
		
		
	def ristampaMovi(self):
		if self.walkCount + 1 >= 24:
			self.walkCount = 0
			
			
		
		if self.right:
			
			path_daStampare = self.array_path_dx[self.walkCount // 3]
			self.lastPos = self.walkCount // 3
			#print(path_daStampare)
			self.walkCount += 1
			self.LAST = 1
			self.lastPath = path_daStampare
			return path_daStampare
			
		if self.left:
			path_daStampare = self.array_path_sx[self.walkCount // 3]
			self.lastPos = self.walkCount // 3
			#print(path_daStampare)
			self.walkCount += 1
			self.LAST = 2
			self.lastPath = path_daStampare
			return path_daStampare
			
		if self.up:
			path_daStampare = self.array_path_up[self.walkCount // 3]
			self.lastPos = self.walkCount // 3
			#print(path_daStampare)
			self.walkCount += 1
			self.LAST = 3
			self.lastPath = path_daStampare
			return path_daStampare	
					
		if self.down:
			path_daStampare = self.array_path_down[self.walkCount // 3]
			self.lastPos = self.walkCount // 3
			#print(path_daStampare)
			self.walkCount += 1
			self.LAST = 4
			self.lastPath = path_daStampare
			return path_daStampare	
			
					
			
			
	
	def settaRight(self):
		self.right = True
		self.left = False
		self.up = False
		self.down = False
		
	def settaLeft(self):
		self.right = False
		self.left = True
		self.up = False
		self.down = False

	def settaUP(self):
		self.right = False
		self.left = False
		self.up = True
		self.down = False

	def settaDOWN(self):
		self.right = False
		self.left = False
		self.up = False
		self.down = True
		
	def stand(self):
		self.right = False
		self.left = False
		self.up = False
		self.down = False
		self.walkCount = 0
		if(self.LAST == 1):
			self.LAST = 0
			self.LAST2 = 1
			return self.pathStandDx
		elif(self.LAST == 2):
			self.LAST = 0
			self.LAST2 = 2
			return self.pathStandSx
		elif(self.LAST == 3):
			self.LAST = 0
			self.LAST2 = 4
			return self.pathStandUp
		elif(self.LAST == 4):
			self.LAST = 0
			self.LAST2 = 3
			return self.pathStandDown
		elif(self.LAST == 0):
			if(self.LAST2 == 1):
				return self.pathStandDx
			elif(self.LAST2 == 2):
				return self.pathStandSx
			elif(self.LAST2 == 3):
				return self.pathStandDown
			elif(self.LAST2 == 4):
				return self.pathStandUp
				
	def dialogo(self):
		if(self.LAST == 1):
			self.LAST = 0
			self.LAST2 = 1
			return self.pathStandDx
		elif(self.LAST == 2):
			self.LAST = 0
			self.LAST2 = 2
			return self.pathStandSx
		elif(self.LAST == 3):
			self.LAST = 0
			self.LAST2 = 4
			return self.pathStandUp
		elif(self.LAST == 4):
			self.LAST = 0
			self.LAST2 = 3
			return self.pathStandDown
		elif(self.LAST == 0):
			if(self.LAST2 == 1):
				return self.pathStandDx
			elif(self.LAST2 == 2):
				return self.pathStandSx
			elif(self.LAST2 == 3):
				return self.pathStandDown
			elif(self.LAST2 == 4):
				return self.pathStandUp		
			
	
		
		
	def getRight(self):
		return self.right
		
	def getLeft(self):
		return self.left
		
	def getUp(self):
		return self.up

	def getDown(self):
		return self.down
		
	def getUpPath(self):
		return self.pathStandUp

	def getDownPath(self):
		return self.pathStandDown
		
	def getLeftPath(self):
		return self.pathStandSx

	def getRightPath(self):
		return self.pathStandDx
		
	def getRightColpito(self):
		return self.array_path_dxColpito
		
	def getLeftColpito(self):
		return self.array_path_sxColpito

	def getUpColpito(self):
		return self.array_path_upColpito
		
	def getDownColpito(self):
		return self.array_path_downColpito
		
	def getLast(self):
		return self.lastPath
		
	def inDX(self):
		if self.lastPath in self.array_path_dx:
			return True
			
	def inSX(self):
		if self.lastPath in self.array_path_sx:
			return True
	
	def inUP(self):
		if self.lastPath in self.array_path_up:
			return True
			
	def inDOWN(self):
		if self.lastPath in self.array_path_down:
			return True
		
	
		
		
		
		
		

