const fs = require("fs");
let express = require("express");
const session = require("express-session")
let bodyParser = require("body-parser");
let jsdom = require("jsdom");
let sound = require("sound-play")

let app = express();
const { JSDOM } = jsdom

let htmlOpen, timer, flgTimer;
let ricettaCorretta, ricettaUtente, pizzeLvl = [];
let maxTempo, secondi, f, nmPizza = 0;

let server = app.listen("3000", function(req, resp) {
    console.log("Server Connesso");
});

app.use(session({
    secret: 'secret',
    resave: true,
    saveUninitialized: false
}));

app.use(bodyParser.urlencoded());
app.use(bodyParser.json());

app.use(express.static("public"));

app.get("/", function(req, resp, next) {
    fs.readFile("./html/menuIniziale/menuIniziale.html", "utf-8", function(err, data) {
        resp.write(data);
        resp.end();
    });
});

/*app.post("/registrazione", (req, res) => {
    // qui posso fare anche i controlli
    req.session.flagLoggato = true;
    req.session.nomeUtente = req.body.nomeUtente;
    req.session.password = req.body.password;

    res.redirect("/");
});*/

app.get("/tutorial", function(req, resp, next) {
    fs.readFile("./html/tutorial/tutorial.html", "utf-8", function(err, data) {
        resp.write(data);
        resp.end();
    });
});

app.get("/livello1", function(req, resp, next) {
    let listaIngredienti = ["pomodoro", "mozzarella", "salame"];
    pizzeLvl = ['margherita', 'salame'];
    nmPizza = 0;
    maxTempo = 60;

    let lvl_html = fs.readFileSync("./html/livello/lvl.html", "utf-8");
    let jsDom = new JSDOM(lvl_html);

    let div_ingredienti = jsDom.window.document.getElementById("ingredienti");

    listaIngredienti.forEach(function(ing) {
        let imgIng = jsDom.window.document.createElement("img");

        imgIng.setAttribute("src", "/img/ingredienti/" + ing + ".png");
        imgIng.setAttribute("id", ing);
        imgIng.setAttribute("ondragstart", "drag(event)");

        div_ingredienti.appendChild(imgIng);
    });

    jsDom.window.document.getElementById("formRigioca").setAttribute("action", "http://127.0.0.1:3000/livello1");

    htmlOpen = jsDom.window.document;

    resp.send(htmlOpen.documentElement.outerHTML);
});

app.get("/livello2", function(req, resp, next) {
    resp.send("IL LIVELLO ARRIVERA' PRESTO");
    resp.end();
});

app.get("/livello3", function(req, resp, next) {
    resp.send("IL LIVELLO ARRIVERA' PRESTO");
    resp.end();
});

app.get("/livello4", function(req, resp, next) {
    resp.send("IL LIVELLO ARRIVERA' PRESTO");
    resp.end();
});

app.get("/livello5", function(req, resp, next) {
    resp.send("IL LIVELLO ARRIVERA' PRESTO");
    resp.end();
});

app.get("/giroPizza", function(req, resp, next) {
    resp.send("COMING SOON");
    resp.end();
});

app.get("/startLvl", function(req, resp, next) {
    htmlOpen.getElementById("startLvl").style.display = "none";
    htmlOpen.getElementById("containerLvl").style.opacity = 1;

    htmlOpen.getElementById('secondiV').setAttribute("value", secondi);
    htmlOpen.body.setAttribute("onload", "startTimer(document.getElementById('secondiV').value, document.getElementById('secondiEnd').value, " + maxTempo + ")");

    secondi = maxTempo;

    if (secondi != maxTempo) {
        clearInterval(timer);
    }

    timer = setInterval(function(params) {
        secondi = secondi - 1;
    }, 1000);

    resp.redirect("/createPizza");
});

app.get("/pause", function(req, resp, next) {
    clearInterval(timer);

    htmlOpen.getElementById('secondiEnd').setAttribute("value", "end");

    htmlOpen.getElementById('secondiV').setAttribute("value", secondi);
    htmlOpen.getElementById("menuPausa").style.display = "block";
    htmlOpen.getElementById("containerLvl").style.opacity = 1;

    resp.send(htmlOpen.documentElement.outerHTML);
    resp.end();
});

app.get("/unPause", function(req, resp, next) {
    timer = setInterval(function() {
        secondi = secondi - 1;
    }, 1000);

    htmlOpen.getElementById('secondiEnd').setAttribute("value", "notEnd");

    htmlOpen.getElementById('secondiV').setAttribute("value", secondi);
    htmlOpen.getElementById("menuPausa").style.display = "none";
    htmlOpen.getElementById("containerLvl").style.opacity = 1;

    resp.send(htmlOpen.documentElement.outerHTML);
    resp.end();
});

app.get("/createPizza", function(req, resp, next) {

    if (nmPizza != pizzeLvl.length) {
        switch (pizzeLvl[nmPizza]) {
            case "margherita":
                ricettaCorretta = ["pomodoro", "mozzarella"];
                ricettaUtente = [];
                f = 0;

                htmlOpen.getElementById('pizzaImg').src = "/img/pizze/impasto.png";
                htmlOpen.getElementById("pizzaImg").style.display = "block";

                htmlOpen.getElementById('imgOrdinazione').src = "/img/ordinazioni/lavagnaMargherita.png";

                htmlOpen.getElementById("mozzarella").style.display = "block";
                htmlOpen.getElementById("pomodoro").style.display = "block";
                htmlOpen.getElementById("salame").style.display = "none";
                break;
            case "salame":
                ricettaCorretta = ["pomodoro", "mozzarella", "salame"];
                ricettaUtente = [];
                f = 0;

                htmlOpen.getElementById('pizzaImg').src = "/img/pizze/impasto.png";
                htmlOpen.getElementById("pizzaImg").style.display = "block";

                htmlOpen.getElementById('imgOrdinazione').src = "/img/ordinazioni/lavagnaSalame.png";

                htmlOpen.getElementById("mozzarella").style.display = "block";
                htmlOpen.getElementById("pomodoro").style.display = "block";
                htmlOpen.getElementById("salame").style.display = "block";
                break;
        }

        htmlOpen.getElementById('secondiV').setAttribute("value", secondi);

    } else {

        htmlOpen.getElementById("stella1").style.display = "block";
        if (secondi > (maxTempo * 33.33) / 100) {
            htmlOpen.getElementById("stella2").style.display = "block";
            if (secondi > (maxTempo * 66.66) / 100) {
                htmlOpen.getElementById("stella3").style.display = "block";
            }
        }

        clearInterval(timer);

        htmlOpen.getElementById("menuVit").style.display = "block";

        htmlOpen.getElementById('secondiV').setAttribute("value", secondi);
        htmlOpen.getElementById('secondiEnd').setAttribute("value", "end");
    }

    resp.send(htmlOpen.documentElement.outerHTML);
    resp.end();
});

app.get("/addIngrediente", function(req, resp, next) {
    var ing = req.query.ing;
    let giusto;

    switch (ing) {
        case "pomodoro":
            if (ricettaCorretta[f] == ing) {
                giusto = true;

                htmlOpen.getElementById(ing).style.display = "none";
                htmlOpen.getElementById('pizzaImg').setAttribute("src", "/img/pizze/marinara.png");

                f = f + 1;
                ricettaUtente.push(ing);
            } else {
                giusto = false;
                //sndErrore.play();
            }
            break;
        case "mozzarella":
            if (ricettaCorretta[f] == ing) {
                giusto = true;

                htmlOpen.getElementById('pizzaImg').setAttribute("src", "/img/pizze/margherita.png");
                htmlOpen.getElementById(ing).style.display = "none";

                f = f + 1;
                ricettaUtente.push(ing);
            } else {
                giusto = false;
                //sndErrore.play();
            }
            break;
        case "salame":
            if (ricettaCorretta[f] == ing) {
                giusto = true;

                htmlOpen.getElementById('pizzaImg').setAttribute("src", "/img/pizze/pizzaSalame.png");
                htmlOpen.getElementById(ing).style.display = "none";

                f = f + 1;
                ricettaUtente.push(ing);
            } else {
                giusto = false;
                //sndErrore.play();
            }
            break;
        default:
            break;
    }

    if (giusto) {
        if (ricettaCorretta.length == ricettaUtente.length) {
            nmPizza = nmPizza + 1;
            resp.redirect("/createPizza");
        } else {
            htmlOpen.getElementById('secondiV').setAttribute("value", secondi);
            resp.send(htmlOpen.documentElement.outerHTML);
        }
    }
});