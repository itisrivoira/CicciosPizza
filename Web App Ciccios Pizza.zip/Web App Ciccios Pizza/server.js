const http = require("http");
const fs = require("fs");
const express = require("express");

let app = express();

let server = app.listen("3000", function(req, resp) {

    app.get("/", (req, resp, next) => {
        fs.readFile("./html/menuIniziale/menuIniziale.html", "utf-8", function(err, data) {
            resp.write(data);
            resp.end();
        });
    });

    app.get("/carriera", function(req, resp, next) {
        fs.readFile("./html/livello/lvl.html", "utf-8", function(err, data) {
            resp.write(data);
            resp.end();
        });
    });

    app.get("/giroPizza", function(req, resp, next) {
        resp.write("Coming soon")
        resp.end();
    });

    app.use("*", function(req, res, next){
        res.send("Errore 404, Pagina non trovata")
        console.log("Pathname non gestito");
        next();
    });

    
});