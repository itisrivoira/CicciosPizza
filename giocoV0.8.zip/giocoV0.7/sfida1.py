import pygame, sys
import pygame_menu #libreria di pygame che permette una facile creazione del main menu di gioco
from pygame_menu import sound
from pygame.locals import *
import mappaLivelli
import time, datetime
import crazyPalace
import classPG


flagOggetti = 0
flagCombatti = 0
flagBattagliaCompletata = 0
startBattle = 'Suoni/startBattle.wav'
suonoColpo = 'Suoni/colpo.wav'

def colonnaSonora(volume,FLAGPAUSE):
	if(FLAGPAUSE == True):
		pygame.mixer.music.load("Suoni/bonetrousle.wav")
		pygame.mixer.music.play(-1)   #play della colonna sonora -1 ---> indica per tempo infinito
		pygame.mixer.music.set_volume(volume)
		pygame.mixer.music.pause()
	else:
		pygame.mixer.music.load("Suoni/bonetrousle.wav")
		pygame.mixer.music.play(-1)   #play della colonna sonora -1 ---> indica per tempo infinito
		pygame.mixer.music.set_volume(volume)
		
def effettoSonoro(volume, suono):
	effect = pygame.mixer.Sound(suono)
	effect.play()
		
def dialogAct(world):
	surf_dialoge = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/dialogAct.jpg")
	rect_dialoge = surf_dialoge.get_rect()
	xDia=30  
	yDia=600  
	rect_dialoge.move_ip(xDia, yDia) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_dialoge, (xDia,yDia))	
		
	surf_next= pygame.image.load("Immagini_Gioco/ImmaginiMappa/next.png")
	rect_next= surf_next.get_rect()
	x=1000
	y=800  
	rect_next.move_ip(x, y)
	world.blit(surf_next, (x,y))
	
	pygame.display.flip()
	
	DONE=False
	while not DONE:

		
		events = pygame.event.get() #lista eventi di una finestra
		for event in events:
			if event.type == pygame.QUIT:
				pygame.quit()
		        
			elif event.type == pygame.MOUSEBUTTONDOWN:
				click = event.pos

				if rect_next.collidepoint(click) and event.button==1:
					DONE = True
def auch(world):
	surf_dialoge = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/colpita.jpg")

	world.blit(surf_dialoge, (0,0))	
		
	surf_next= pygame.image.load("Immagini_Gioco/ImmaginiMappa/next.png")
	rect_next= surf_next.get_rect()
	x=1000
	y=800  
	rect_next.move_ip(x, y)
	world.blit(surf_next, (x,y))
	
	pygame.display.flip()
	
	DONE=False
	while not DONE:

		
		events = pygame.event.get() #lista eventi di una finestra
		for event in events:
			if event.type == pygame.QUIT:
				pygame.quit()
		        
			elif event.type == pygame.MOUSEBUTTONDOWN:
				click = event.pos

				if rect_next.collidepoint(click) and event.button==1:
					DONE = True
					
def dam(world):
	surf_dialoge = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/pgColpito.jpg")

	world.blit(surf_dialoge, (0,0))	
		
	surf_next= pygame.image.load("Immagini_Gioco/ImmaginiMappa/next.png")
	rect_next= surf_next.get_rect()
	x=1000
	y=800  
	rect_next.move_ip(x, y)
	world.blit(surf_next, (x,y))
	
	pygame.display.flip()
	
	DONE=False
	while not DONE:

		
		events = pygame.event.get() #lista eventi di una finestra
		for event in events:
			if event.type == pygame.QUIT:
				pygame.quit()
		        
			elif event.type == pygame.MOUSEBUTTONDOWN:
				click = event.pos

				if rect_next.collidepoint(click) and event.button==1:
					DONE = True
					
					
def slurp(world):
	surf_dialoge = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/slurp.jpg")

	world.blit(surf_dialoge, (0,0))	
		
	surf_next= pygame.image.load("Immagini_Gioco/ImmaginiMappa/next.png")
	rect_next= surf_next.get_rect()
	x=1000
	y=800  
	rect_next.move_ip(x, y)
	world.blit(surf_next, (x,y))
	
	pygame.display.flip()
	
	DONE=False
	while not DONE:

		
		events = pygame.event.get() #lista eventi di una finestra
		for event in events:
			if event.type == pygame.QUIT:
				pygame.quit()
		        
			elif event.type == pygame.MOUSEBUTTONDOWN:
				click = event.pos

				if rect_next.collidepoint(click) and event.button==1:
					DONE = True
					
def aiutoVito(world):
	surf_dialoge = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/aiutoVito.jpg")

	world.blit(surf_dialoge, (0,0))	
		
	surf_next= pygame.image.load("Immagini_Gioco/ImmaginiMappa/next.png")
	rect_next= surf_next.get_rect()
	x=1000
	y=800  
	rect_next.move_ip(x, y)
	world.blit(surf_next, (x,y))
	
	pygame.display.flip()
	
	DONE=False
	while not DONE:

		
		events = pygame.event.get() #lista eventi di una finestra
		for event in events:
			if event.type == pygame.QUIT:
				pygame.quit()
		        
			elif event.type == pygame.MOUSEBUTTONDOWN:
				click = event.pos

				if rect_next.collidepoint(click) and event.button==1:
					DONE = True	
					
def aiutoVito2(world):
	surf_dialoge = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/benFatto.jpg")

	world.blit(surf_dialoge, (0,0))	
		
	surf_next= pygame.image.load("Immagini_Gioco/ImmaginiMappa/next.png")
	rect_next= surf_next.get_rect()
	x=1000
	y=800  
	rect_next.move_ip(x, y)
	world.blit(surf_next, (x,y))
	
	pygame.display.flip()
	
	DONE=False
	while not DONE:

		
		events = pygame.event.get() #lista eventi di una finestra
		for event in events:
			if event.type == pygame.QUIT:
				pygame.quit()
		        
			elif event.type == pygame.MOUSEBUTTONDOWN:
				click = event.pos

				if rect_next.collidepoint(click) and event.button==1:
					DONE = True		
	
def makePizza(world):
	
	flagZ = 0

	surf_pomodoro=pygame.image.load('Immagini_Gioco/Immagini_Livello/pomodoro.png')
	rect_pomodoro = surf_pomodoro.get_rect()
	xP=650 
	yP=350 
	rect_pomodoro.move_ip(xP, yP) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_pomodoro, (xP,yP))	
	
	surf_mozzarella=pygame.image.load('Immagini_Gioco/Immagini_Livello/mozzarella.png')
	rect_mozzarella = surf_mozzarella.get_rect()
	xM=750 
	yM=150
	rect_mozzarella.move_ip(xM, yM)
	world.blit(surf_mozzarella, (xM,yM))
	
	pygame.display.flip()
	
	ripeti2 = True
	
	while ripeti2:
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				sys.exit()
			elif event.type == pygame.MOUSEBUTTONDOWN:
				click = event.pos

				if rect_pomodoro.collidepoint(click) and event.button==1:
					flagZ = flagZ + 1
				if  rect_mozzarella.collidepoint(click) and event.button==1:
					flagZ = flagZ + 1
			if flagZ == 2:
				ripeti2 = False
				
def attaccoDelOca(world, volume):
	global suonoColpo
	suonoColpo

	surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/lancioPiume1.jpg").convert()
	world.blit(surf_background, (0, 0))
	time.sleep(0.1)
	pygame.display.flip()
	surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/lancioPiume2.jpg").convert()
	world.blit(surf_background, (0, 0))
	time.sleep(0.1)
	pygame.display.flip()						
	surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/lancioPiume3.jpg").convert()
	world.blit(surf_background, (0, 0))
	time.sleep(0.1)	
	pygame.display.flip()					
	surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/lancioPiume4.jpg").convert()
	world.blit(surf_background, (0, 0))
	time.sleep(0.1)	
	pygame.display.flip()
	surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/lancioPiume5.jpg").convert()
	world.blit(surf_background, (0, 0))
	time.sleep(0.1)
	pygame.display.flip()
	surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/lancioPiume6.jpg").convert()
	world.blit(surf_background, (0, 0))
	time.sleep(0.1)
	pygame.display.flip()
	effettoSonoro(volume, suonoColpo)
	time.sleep(1)
	dam(world)
		
					
def combatti(world, flagCombatti, volume):
	global suonoColpo
	suonoColpo
	surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/combattimento1_0.jpg").convert()
	world.blit(surf_background, (0, 0))
	
	if(flagCombatti == 0):
		surf_pade= pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/button_padellata.png")
		rect_pade= surf_pade.get_rect()
		xPad=150
		yPad=690  
		rect_pade.move_ip(xPad, yPad)
		world.blit(surf_pade, (xPad,yPad))
		
		surf_dife= pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/button_difesa.png")
		rect_dife= surf_dife.get_rect()
		xDif=550
		yDif=690  
		rect_dife.move_ip(xDif, yDif)
		world.blit(surf_dife, (xDif,yDif))
		
		ripeti = True
		while ripeti:
#print(volume)
			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					pygame.quit()
					sys.exit()
				elif event.type == pygame.MOUSEBUTTONDOWN:
					click = event.pos

					if rect_pade.collidepoint(click) and event.button==1:
						surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/lancio1.jpg").convert()
						world.blit(surf_background, (0, 0))
						time.sleep(0.1)
						pygame.display.flip()
						surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/lancio2.jpg").convert()
						world.blit(surf_background, (0, 0))
						time.sleep(0.1)
						pygame.display.flip()						
						surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/lancio3.jpg").convert()
						world.blit(surf_background, (0, 0))
						time.sleep(0.1)	
						pygame.display.flip()					
						surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/lancio4.jpg").convert()
						world.blit(surf_background, (0, 0))
						time.sleep(0.1)	
						pygame.display.flip()
						surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/lancio5.jpg").convert()
						world.blit(surf_background, (0, 0))
						time.sleep(0.1)
						pygame.display.flip()
						effettoSonoro(volume, suonoColpo)
						time.sleep(1)
						auch(world)
						flagCombatti = 1
						ripeti = False
							
			pygame.display.flip()
		aiutoVito(world)
		return flagCombatti
	
	elif flagCombatti == 2:
	
		surf_pade= pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/button_lancio-margherita.png")
		rect_pade= surf_pade.get_rect()
		xPad=150
		yPad=690  
		rect_pade.move_ip(xPad, yPad)
		world.blit(surf_pade, (xPad,yPad))
		

		
		ripeti = True
		while ripeti:
#print(volume)
			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					pygame.quit()
					sys.exit()
				elif event.type == pygame.MOUSEBUTTONDOWN:
					click = event.pos

					if rect_pade.collidepoint(click) and event.button==1:
						surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/lancioPiz1.jpg").convert()
						world.blit(surf_background, (0, 0))
						time.sleep(0.1)
						pygame.display.flip()
						surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/lancioPiz2.jpg").convert()
						world.blit(surf_background, (0, 0))
						time.sleep(0.1)
						pygame.display.flip()						
						surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/lancioPiz3.jpg").convert()
						world.blit(surf_background, (0, 0))
						time.sleep(0.1)	
						pygame.display.flip()					
						surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/lancioPiz4.jpg").convert()
						world.blit(surf_background, (0, 0))
						time.sleep(0.1)	
						pygame.display.flip()
						surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/lancioPiz5.jpg").convert()
						world.blit(surf_background, (0, 0))
						time.sleep(0.1)
						pygame.display.flip()
						surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/lancioPiz6.jpg").convert()
						world.blit(surf_background, (0, 0))
						time.sleep(0.1)
						pygame.display.flip()
						surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/lancioPiz7.jpg").convert()
						world.blit(surf_background, (0, 0))
						time.sleep(0.1)
						pygame.display.flip()
						surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/lancioPiz8.jpg").convert()
						world.blit(surf_background, (0, 0))
						time.sleep(0.1)
						pygame.display.flip()
						effettoSonoro(volume, suonoColpo)
						time.sleep(1)
						slurp(world)
						print("gay")
						flagCombatti = 3
						ripeti = False
							
			pygame.display.flip()
		print("eaea")
		return flagCombatti		
		
					
def dialogItemVuoti(world):
	surf_dialoge = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/dialogNoOgg.jpg")
	rect_dialoge = surf_dialoge.get_rect()
	xDia=30  
	yDia=600  
	rect_dialoge.move_ip(xDia, yDia) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_dialoge, (xDia,yDia))	
		
	surf_next= pygame.image.load("Immagini_Gioco/ImmaginiMappa/next.png")
	rect_next= surf_next.get_rect()
	x=1000
	y=800  
	rect_next.move_ip(x, y)
	world.blit(surf_next, (x,y))
	
	pygame.display.flip()
	
	DONE=False
	while not DONE:

		
		events = pygame.event.get() #lista eventi di una finestra
		for event in events:
			if event.type == pygame.QUIT:
				pygame.quit()
		        
			elif event.type == pygame.MOUSEBUTTONDOWN:
				click = event.pos

				if rect_next.collidepoint(click) and event.button==1:
					DONE = True			
	
def menuItem(VOLUMESETTATO, FLAGPAUSE, world):
	surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/combattimento1_0.jpg").convert()
	world.blit(surf_background, (0, 0))

	surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/impasto.png')
	rect_pizzaVuota = surf_pizzaVuota.get_rect()
	x=475  
	y=250  
	rect_pizzaVuota.move_ip(x, y)
	world.blit(surf_pizzaVuota, (x,y))
	
	surf_pomodoro=pygame.image.load('Immagini_Gioco/Immagini_Livello/pomodoro.png')
	rect_pomodoro = surf_pomodoro.get_rect()
	xPom=150 
	yPom=690 
	rect_pomodoro.move_ip(xPom, yPom) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
	world.blit(surf_pomodoro, (xPom,yPom))	

	surf_mozzarella=pygame.image.load('Immagini_Gioco/Immagini_Livello/mozzarella.png')
	rect_mozzarella = surf_mozzarella.get_rect()
	xMoz=850 
	yMoz=690
	rect_mozzarella.move_ip(xMoz, yMoz)
	world.blit(surf_mozzarella, (xMoz,yMoz))
	
	pygame.display.flip()

	ripeti = True
	dragPomodoro = False
	dragMozzarella = False
	eliminaMozzarella = False
	eliminaPomodoro = False
	flagIng = 0
	ifYouHaveDrag = False
		
	while ripeti:
		print("a")		
		for ev in pygame.event.get():
			if ev.type == pygame.QUIT:
				ripeti = False
			
			if ev.type == MOUSEBUTTONDOWN:
				click = ev.pos
				
				if rect_pomodoro.collidepoint(click) and ev.button==1:
					dragPomodoro = True
					mouse_x1, mouse_y1 = ev.pos
					offset_x1 = rect_pomodoro.x - mouse_x1
					offset_y1 = rect_pomodoro.y - mouse_y1
				
				if rect_mozzarella.collidepoint(click) and ev.button==1:
					dragMozzarella = True
					mouse_x2, mouse_y2 = ev.pos
					offset_x2 = rect_mozzarella.x - mouse_x2
					offset_y2 = rect_mozzarella.y - mouse_y2
				
				if rect_pizzaVuota.collidepoint(click) and flagIng == 2:
					ripeti = False
					
	
							
			if ev.type == pygame.MOUSEBUTTONUP:
				if ev.button == 1:
					if rect_pomodoro.colliderect(rect_pizzaVuota):
						eliminaPomodoro = True
						surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/marinara.png')
						rect_pizzaVuota = surf_pizzaVuota.get_rect()
						x=475  #coordinata centro
						y=250  #coordinata centro
						world.blit(surf_pizzaVuota, (x,y))
						rect_pizzaVuota.move_ip(x, y)
						flagIng=1
					if dragPomodoro:
						print(eliminaPomodoro)
						dragPomodoro = False
						print(xPom, yPom)
						rect_pomodoro.x = xPom
						rect_pomodoro.y = yPom
						ristampaMenuItem(world, flagIng, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella)
					if rect_mozzarella.colliderect(rect_pizzaVuota):
						if(flagIng == 1):
							print("eaeae")
							eliminaMozzarella = True
							surf_pizzaVuota= pygame.image.load('Immagini_Gioco/Immagini_Livello/pizzaMargherita.png')
							rect_pizzaVuota = surf_pizzaVuota.get_rect()
							x=475
							y=250
							world.blit(surf_pizzaVuota, (x,y))
							rect_pizzaVuota.move_ip(x, y)				   						    				
							pygame.display.flip()						    										    				    			
							flagIng = 2
							ripeti = False
						else:
							suonoErrore = False
							pygame.mixer.music.load("Suoni/erroreSelezione.ogg")
							pygame.mixer.music.set_volume(0.5)
							pygame.mixer.music.play()
							pygame.time.wait(500)
							colonnaSonora(VOLUMESETTATO, FLAGPAUSE)
							flag = 0 
							eliminaMozzarella = False 
							eliminaPomodoro = False	
							
					if dragMozzarella:
						dragMozzarella = False
						rect_mozzarella.x = xMoz
						rect_mozzarella.y = yMoz
						ristampaMenuItem(world, flagIng, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella)
														
					
			if ev.type == pygame.MOUSEMOTION:
				if dragPomodoro: 
					print("ciao")
					mouse_x1, mouse_y1 = ev.pos
					rect_pomodoro.x = mouse_x1 + offset_x1
					rect_pomodoro.y = mouse_y1 + offset_y1
					ifYouHaveDrag = True
                     
				if dragMozzarella:
					mouse_x2, mouse_y2 = ev.pos
					rect_mozzarella.x = mouse_x2 + offset_x2
					rect_mozzarella.y = mouse_y2 + offset_y2
					ifYouHaveDrag = True

					
							
		if ifYouHaveDrag:
			ristampaMenuItem(world, flagIng, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella)
	
	
			
		ifYouHaveDrag = False
		if(eliminaPomodoro == False):
			#print("dad")
			world.blit(surf_pomodoro, rect_pomodoro)
		if(eliminaMozzarella == False):
			world.blit(surf_mozzarella, rect_mozzarella)

		pygame.display.flip()	

def ristampaMenuItem(world, flagIngredienti, dragPomodoro, eliminaPomodoro, dragMozzarella, eliminaMozzarella ):
	
	surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/combattimento1_0.jpg").convert()
	world.blit(surf_background, (0, 0))
	
	
	if flagIngredienti == 0:
		surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/impasto.png')
		rect_pizzaVuota = surf_pizzaVuota.get_rect()
		x=475  
		y=250  
		rect_pizzaVuota.move_ip(x, y)
		world.blit(surf_pizzaVuota, (x,y))
	elif flagIngredienti == 1:
		surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/marinara.png')
		rect_pizzaVuota = surf_pizzaVuota.get_rect()
		x=475  #coordinata centro
		y=250  #coordinata centro
		world.blit(surf_pizzaVuota, (x,y))
	else:
		print("fatto")
		surf_pizzaVuota=pygame.image.load('Immagini_Gioco/Immagini_Livello/pizzaMargherita.png')
		rect_pizzaVuota = surf_pizzaVuota.get_rect()
		x=475  #coordinata centro		
		y=250  #coordinata centro
		world.blit(surf_pizzaVuota, (x,y))	
		
	if dragPomodoro == False and eliminaPomodoro == False :	
		surf_pomodoro=pygame.image.load('Immagini_Gioco/Immagini_Livello/pomodoro.png')
		rect_pomodoro = surf_pomodoro.get_rect()
		xP=150 
		yP=690 
		rect_pomodoro.move_ip(xP, yP) #MOVE IP MUOVE IL RECT NELLE CORDINATE DECISE DA UTENTE
		world.blit(surf_pomodoro, (xP,yP))	

	if dragMozzarella == False and eliminaMozzarella == False:	
		surf_mozzarella=pygame.image.load('Immagini_Gioco/Immagini_Livello/mozzarella.png')
		rect_mozzarella = surf_mozzarella.get_rect()
		xM=850 
		yM=690
		rect_mozzarella.move_ip(xM, yM)
		world.blit(surf_mozzarella, (xM,yM))
	
	pygame.display.flip()	
		

def ristampa(font, poz, personaggio, world):
	surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/combattimento1_0.jpg").convert()
	world.blit(surf_background, (0, 0))
	
	surf_fight= pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/fight.png")
	rect_fight= surf_fight.get_rect()
	xF=150
	yF=690  
	rect_fight.move_ip(xF, yF)
	world.blit(surf_fight, (xF,yF))
	
	surf_act= pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/act.png")
	rect_act= surf_act.get_rect()
	xAc=550
	yAc=690  
	rect_act.move_ip(xAc, yAc)
	world.blit(surf_act, (xAc,yAc))
	
	surf_item= pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/item.png")
	rect_item= surf_item.get_rect()
	xI=950
	yI=690  
	rect_item.move_ip(xI, yI)
	world.blit(surf_item, (xI,yI))
	
	surf_orologio= pygame.image.load("Immagini_Gioco/Immagini_Livello/orologio.png")
	rect_orologio = surf_orologio.get_rect()
	xOr=1100
	yOr=50  
	rect_orologio.move_ip(xOr, yOr)
	world.blit(surf_orologio, (xOr,yOr))
	world.blit(surf_orologio, (xOr,yOr))
	poz.fill((255, 255, 255))#serve per cancellare il contenuto della surface in modo da fare il timer decrescente
	poz = font.render(personaggio.getStringa(), True, (0, 187, 45), (255, 255, 255))
	world.blit(poz, (1155, 134))

		
		
def main(personaggio, FLAGPAUSE, volume):
	global startBattle
	startBattle
	effettoSonoro(volume, startBattle)
	time.sleep(1)
	colonnaSonora(volume,FLAGPAUSE)
	global flagOggetti, flagCombatti
	flagCombatti
	flagOggetti	
	#pygame.init()
	worldx = 1280
	worldy = 920
	fps = 40
	ani = 4
	world = pygame.display.set_mode((worldx, worldy))
	#backdrop = pygame.image.load("Immagini_Gioco/background_menu/rossa2.jpg").convert()
	clock = pygame.time.Clock()
	#backdropbox = world.get_rect()
	main = True
	muovix = 0

	#player = Player()  # spawn player
	#player.rect.x = 0  # go to x
	#player.rect.y = 0  # go to y
	steps = 10

	surf_background = pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/combattimento1_0.jpg").convert()
	world.blit(surf_background, (0, 0))
	
	surf_fight= pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/fight.png")
	rect_fight= surf_fight.get_rect()
	xF=150
	yF=690  
	rect_fight.move_ip(xF, yF)
	world.blit(surf_fight, (xF,yF))
	
	surf_act= pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/act.png")
	rect_act= surf_act.get_rect()
	xAc=550
	yAc=690  
	rect_act.move_ip(xAc, yAc)
	world.blit(surf_act, (xAc,yAc))
	
	surf_item= pygame.image.load("Immagini_Gioco/HUB/onlyLevel4/ocheCrazy/combattimenti/item.png")
	rect_item= surf_item.get_rect()
	xI=950
	yI=690  
	rect_item.move_ip(xI, yI)
	world.blit(surf_item, (xI,yI))
	
	surf_orologio= pygame.image.load("Immagini_Gioco/Immagini_Livello/orologio.png")
	rect_orologio = surf_orologio.get_rect()
	xOr=1100
	yOr=50  
	rect_orologio.move_ip(xOr, yOr)
	world.blit(surf_orologio, (xOr,yOr))
	
	font = pygame.font.SysFont("Verdana", 34, bold=True, italic=True)
	poz = font.render(personaggio.getStringa(), True,  (0, 187, 45), (255, 255, 0))

	
	
	pygame.time.set_timer(pygame.USEREVENT, 1000)

	pygame.display.flip()
	pygame.key.set_repeat(2,6)  #serve per lo spostamento
	
	attaccoOca = 0
	clock = pygame.time.Clock()

	'''
	Main Loop
	'''

	while main:
		if personaggio.getTimer() == 0:
			main = False	
		attackOca = clock.tick()
		attaccoOca = attackOca + attaccoOca
		#print(volume)
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				sys.exit()
			elif event.type == pygame.MOUSEBUTTONDOWN:
				click = event.pos

				if rect_act.collidepoint(click) and event.button==1:
					dialogAct(world)
					ristampa(font, poz, personaggio, world)
					pygame.display.flip()
					print("ehy")
				if rect_item.collidepoint(click) and event.button==1 and flagOggetti != 1:
					dialogItemVuoti(world)
					ristampa(font, poz, personaggio, world)
					pygame.display.flip()
					print("ehy")
					pygame.display.flip()
				elif (rect_item.collidepoint(click) and event.button==1 and flagOggetti == 1):
					menuItem(volume, FLAGPAUSE, world)
					time.sleep(1.2)
					aiutoVito2(world)
					ristampa(font, poz, personaggio, world)
					flagOggetti = 2
					flagCombatti = 2
				if rect_fight.collidepoint(click) and event.button == 1 and flagOggetti != 1:
					flagCombatti = combatti(world, flagCombatti, volume)
					if(flagCombatti == 1):
						flagOggetti = 1
						ristampa(font, poz, personaggio, world)
						pygame.display.flip()
						print("ehy")
						makePizza(world)
						ristampa(font, poz, personaggio, world)
						pygame.display.flip()
					elif (flagCombatti == 3):
						print("ehix")
						print ("ou")
						main = False
						print ("ou")
			if event.type == pygame.USEREVENT:
				#personaggio.diminuisci()
				print(personaggio.getTimer())
				personaggio.diminuisci()
				personaggio.setStringa(personaggio.getTimer())
				print(personaggio.getTimer())
				world.blit(surf_orologio, (xOr,yOr))
				poz.fill((255, 255, 255))#serve per cancellare il contenuto della surface in modo da fare il timer decrescente
				poz = font.render(personaggio.getStringa(), True, (0, 187, 45), (255, 255, 255))
				world.blit(poz, (1155, 134))
			if(attaccoOca > 2500):
				attaccoDelOca(world, volume)
				personaggio.attaccoOca(10)
				clock.tick()
				ristampa(font, poz, personaggio, world)
				print("colpito")
				print("attaccoOca")
				attaccoOca = 0 
				attaccoOca = 0 
				
		pygame.display.flip()
	print("fuori")
	personaggio.vinto1()
