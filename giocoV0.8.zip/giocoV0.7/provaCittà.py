import pygame
import pygame_menu #libreria di pygame che permette una facile creazione del main menu di gioco
from pygame_menu import sound
from pygame.locals import *


def main():
	pygame.init()
	screen = pygame.display.set_mode((1280, 920)) #CREAZIONE SCHERMO DI GIOCO
		    
	surf_background = pygame.image.load("livello2Ciccios/tovagliablu.jpg").convert()        




main()
