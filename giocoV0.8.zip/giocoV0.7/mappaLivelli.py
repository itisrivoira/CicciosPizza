import pygame, sys
import pygame_menu #libreria di pygame che permette una facile creazione del main menu di gioco
from pygame_menu import sound
import livello_prova
import livello_tutorial
import ordine1
import ordine_lvl3
import livello4HUB
from pygame.locals import *


pygame.init()

def colonnaSonora(volume,FLAGPAUSE):
	if(FLAGPAUSE == True):
		pygame.mixer.music.load("Suoni/colonnaSonora.ogg")
		pygame.mixer.music.play(-1)   #play della colonna sonora -1 ---> indica per tempo infinito
		pygame.mixer.music.set_volume(volume)
		pygame.mixer.music.pause()
	else:
		pygame.mixer.music.load("Suoni/colonnaSonora.ogg")
		pygame.mixer.music.play(-1)   #play della colonna sonora -1 ---> indica per tempo infinito
		pygame.mixer.music.set_volume(volume)		


def start_the_game1(FLAGPAUSE,VOLUMESETTATO):
    print(FLAGPAUSE)
    flag = livello_prova.main(FLAGPAUSE, VOLUMESETTATO)
    if ( flag == 1):
        pygame.quit()
        sys.exit() #SENZA QUESTO DA ERRORE PERCHE' RIPROVEREBBE A DISEGNARE SULLO SCHERMO CAUSANDO UN ERRORE
    print(VOLUMESETTATO)
    colonnaSonora(VOLUMESETTATO,FLAGPAUSE)
    return flag
    
def start_the_game2(FLAGPAUSE,VOLUMESETTATO):
    print(FLAGPAUSE)
    flag = ordine1.main(FLAGPAUSE, VOLUMESETTATO)
    if ( flag == 1):
        pygame.quit()
        sys.exit() #SENZA QUESTO DA ERRORE PERCHE' RIPROVEREBBE A DISEGNARE SULLO SCHERMO CAUSANDO UN ERRORE
    print(VOLUMESETTATO)
    colonnaSonora(VOLUMESETTATO,FLAGPAUSE)
    return flag
    
def start_the_game3(FLAGPAUSE,VOLUMESETTATO):
    print(FLAGPAUSE)
    flag = ordine_lvl3.main(FLAGPAUSE, VOLUMESETTATO)
    if ( flag == 1):
        pygame.quit()
        sys.exit() #SENZA QUESTO DA ERRORE PERCHE' RIPROVEREBBE A DISEGNARE SULLO SCHERMO CAUSANDO UN ERRORE
    print(VOLUMESETTATO)
    colonnaSonora(VOLUMESETTATO,FLAGPAUSE)
    return flag    
    
def start_the_game4(FLAGPAUSE,VOLUMESETTATO):
    print(FLAGPAUSE)
    livello4HUB.main(FLAGPAUSE, VOLUMESETTATO)  
        
def crea_mappa():


	screen = pygame.display.set_mode((1280, 920)) #CREAZIONE SCHERMO DI GIOCO
	pygame.display.set_caption("MAPPA DEI LIVELLI ")

		
	surf_background = pygame.image.load("Immagini_Gioco/ImmaginiMappa/mappaBG.png").convert()
	screen.blit(surf_background, (0, 0))

	font_scegli=pygame.font.SysFont("Verdana",34,bold=True,italic=True)   
	surf_scegli=font_scegli.render("SCEGLI IL LIVELLO!!",True,(0,0,255))	
	x=450
	y=30
	screen.blit(surf_scegli,(x,y))	
	pygame.display.flip()
	surf_icon1= pygame.image.load("Immagini_Gioco/ImmaginiMappa/livello1.png")
	rect_icon1 = surf_icon1.get_rect()
	x=50
	y=175  
	rect_icon1.move_ip(x, y)
	screen.blit(surf_icon1, (x,y))

	surf_icon2= pygame.image.load("Immagini_Gioco/ImmaginiMappa/livello2.png")
	rect_icon2 = surf_icon1.get_rect()
	x=250
	y=500  
	rect_icon2.move_ip(x, y)
	screen.blit(surf_icon2, (x,y))

	surf_icon3= pygame.image.load("Immagini_Gioco/ImmaginiMappa/livello3.png")
	rect_icon3 = surf_icon1.get_rect()
	x=525
	y=175  
	rect_icon3.move_ip(x, y)
	screen.blit(surf_icon3, (x,y))

	surf_icon4= pygame.image.load("Immagini_Gioco/ImmaginiMappa/livello4.png")
	rect_icon4 = surf_icon1.get_rect()
	x=800
	y=500  
	rect_icon4.move_ip(x, y)
	screen.blit(surf_icon4, (x,y))

	surf_icon5= pygame.image.load("Immagini_Gioco/ImmaginiMappa/livello5.png")
	rect_icon5 = surf_icon1.get_rect()
	x=1050
	y=175  
	rect_icon5.move_ip(x, y)
	screen.blit(surf_icon5, (x,y))
		
	surf_menu= pygame.image.load("Immagini_Gioco/Immagini_Livello/menu.png")
	rect_menu = surf_menu.get_rect()
	x=1050  
	y=700  
	rect_menu.move_ip(x, y)
	screen.blit(surf_menu, (x,y))
		
	surf_tutorial= pygame.image.load("Immagini_Gioco/ImmaginiMappa/tutorial2.png")
	rect_tutorial = surf_tutorial.get_rect()
	x=10
	y=745 
	rect_tutorial.move_ip(x, y)
	screen.blit(surf_tutorial, (x,y))

		

	pygame.display.flip()	


   
def main(FLAGPAUSE, VOLUMESETTATO):

    


    screen = pygame.display.set_mode((1280, 920)) #CREAZIONE SCHERMO DI GIOCO
    pygame.display.set_caption("MAPPA DEI LIVELLI ")

    
    surf_background = pygame.image.load("Immagini_Gioco/ImmaginiMappa/mappaBG.png").convert()
    screen.blit(surf_background, (0, 0))

    font_scegli=pygame.font.SysFont("Verdana",34,bold=True,italic=True)   
    surf_scegli=font_scegli.render("SCEGLI IL LIVELLO!!",True,(0,0,255))	
    x=450
    y=30
    screen.blit(surf_scegli,(x,y))	
    pygame.display.flip()

    surf_icon1= pygame.image.load("Immagini_Gioco/ImmaginiMappa/livello1.png")
    rect_icon1 = surf_icon1.get_rect()
    x=50
    y=175  
    rect_icon1.move_ip(x, y)
    screen.blit(surf_icon1, (x,y))

    surf_icon2= pygame.image.load("Immagini_Gioco/ImmaginiMappa/livello2.png")
    rect_icon2 = surf_icon1.get_rect()
    x=250
    y=500  
    rect_icon2.move_ip(x, y)
    screen.blit(surf_icon2, (x,y))

    surf_icon3= pygame.image.load("Immagini_Gioco/ImmaginiMappa/livello3.png")
    rect_icon3 = surf_icon1.get_rect()
    x=525
    y=175  
    rect_icon3.move_ip(x, y)
    screen.blit(surf_icon3, (x,y))

    surf_icon4= pygame.image.load("Immagini_Gioco/ImmaginiMappa/livello4.png")
    rect_icon4 = surf_icon1.get_rect()
    x=800
    y=500  
    rect_icon4.move_ip(x, y)
    screen.blit(surf_icon4, (x,y))

    surf_icon5= pygame.image.load("Immagini_Gioco/ImmaginiMappa/livello5.png")
    rect_icon5 = surf_icon1.get_rect()
    x=1050
    y=175  
    rect_icon5.move_ip(x, y)
    screen.blit(surf_icon5, (x,y))
    
    surf_menu= pygame.image.load("Immagini_Gioco/Immagini_Livello/menu.png")
    rect_menu = surf_menu.get_rect()
    x=1050  
    y=700  
    rect_menu.move_ip(x, y)
    screen.blit(surf_menu, (x,y))
    
    surf_tutorial= pygame.image.load("Immagini_Gioco/ImmaginiMappa/tutorial2.png")
    rect_tutorial = surf_tutorial.get_rect()
    x=10
    y=745 
    rect_tutorial.move_ip(x, y)
    screen.blit(surf_tutorial, (x,y))

    

    pygame.display.flip()

    flag=1
    DONE=False
    while not DONE:

	
        events = pygame.event.get() #lista eventi di una finestra
        for event in events:
            if event.type == pygame.QUIT:
            	pygame.quit()
            	sys.exit()
            
            elif event.type == MOUSEBUTTONDOWN:
                click = event.pos

                if rect_icon1.collidepoint(click) and event.button==1:
                    flag=start_the_game1(FLAGPAUSE,VOLUMESETTATO)

                if rect_icon2.collidepoint(click) and event.button==1:
                     flag=start_the_game2(FLAGPAUSE,VOLUMESETTATO)

                if rect_icon3.collidepoint(click) and event.button==1:
                    flag = start_the_game3(FLAGPAUSE,VOLUMESETTATO)

                if rect_icon4.collidepoint(click) and event.button==1:
                    start_the_game4(FLAGPAUSE,VOLUMESETTATO)

                if rect_icon5.collidepoint(click) and event.button==1:
                    print("Livello 5")
                    
                if rect_menu.collidepoint(click) and event.button==1:
                    flag=0
                    
                if rect_tutorial.collidepoint(click) and event.button == 1: 
                	#xxx =pygame.image.load("Immagini_Gioco/dialoghi/dialogo1.jpg").convert()
                	#screen.blit(xxx, (0, 0))
                	#pygame.display.flip()
                	flag = livello_tutorial.main(FLAGPAUSE,VOLUMESETTATO)
                	print(flag)
                	#pygame.display.flip()

        if flag==0:
            DONE=True
        elif flag == -1:
        	crea_mappa()
        	flag = 1

    return flag
